import { TrendingUp, TrendingDown } from "lucide-react";
import { cn } from "@/lib/utils";

interface DeviationIndicatorProps {
  value: number;
  threshold: number;
}

export function DeviationIndicator({ value, threshold }: DeviationIndicatorProps) {
  const isNegative = value < 0;
  const isCritical = Math.abs(value) >= threshold;
  
  return (
    <div className="flex items-center gap-2">
      {isNegative ? (
        <TrendingDown className={cn("h-4 w-4", isCritical ? "text-danger" : "text-warning")} />
      ) : (
        <TrendingUp className={cn("h-4 w-4", isCritical ? "text-success" : "text-warning")} />
      )}
      <span className={cn(
        "font-medium text-sm",
        isCritical && (isNegative ? "text-danger" : "text-success")
      )}>
        {value > 0 && "+"}{value.toFixed(1)}%
      </span>
    </div>
  );
}

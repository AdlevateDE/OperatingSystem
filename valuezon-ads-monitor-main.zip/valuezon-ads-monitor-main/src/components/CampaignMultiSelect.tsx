import { useState, useMemo, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Checkbox } from "@/components/ui/checkbox";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { Search, CheckSquare, XSquare, Loader2, Info, ChevronDown, Target } from "lucide-react";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { maskCampaignName } from "@/lib/demoMode";

interface CampaignMultiSelectProps {
  campaigns: string[];
  selectedCampaigns: string[];
  selectionMode: "all" | "include" | "exclude";
  onSelectedCampaignsChange: (campaigns: string[]) => void;
  onSelectionModeChange: (mode: "all" | "include" | "exclude") => void;
  isLoading?: boolean;
}

export function CampaignMultiSelect({
  campaigns,
  selectedCampaigns,
  selectionMode,
  onSelectedCampaignsChange,
  onSelectionModeChange,
  isLoading = false,
}: CampaignMultiSelectProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [hasUserInteracted, setHasUserInteracted] = useState(false);
  const { isDemoMode } = useDemoMode();
  const { language, t } = useLanguage();

  useEffect(() => {
    if (campaigns.length > 0 && selectedCampaigns.length === 0 && selectionMode === "include" && !hasUserInteracted) {
      onSelectedCampaignsChange([...campaigns]);
    }
  }, [campaigns, selectedCampaigns.length, selectionMode, onSelectedCampaignsChange, hasUserInteracted]);

  useEffect(() => {
    if (selectionMode === "all") {
      setHasUserInteracted(false);
    }
  }, [selectionMode]);

  const filteredCampaigns = useMemo(() => {
    if (!searchQuery) return campaigns;
    const lowerQuery = searchQuery.toLowerCase();
    return campaigns.filter((name) => name.toLowerCase().includes(lowerQuery));
  }, [campaigns, searchQuery]);

  const handleToggleCampaign = (campaignName: string) => {
    if (selectedCampaigns.includes(campaignName)) {
      onSelectedCampaignsChange(selectedCampaigns.filter((c) => c !== campaignName));
    } else {
      onSelectedCampaignsChange([...selectedCampaigns, campaignName]);
    }
  };

  const handleSelectAll = () => {
    setHasUserInteracted(true);
    onSelectedCampaignsChange([...campaigns]);
  };

  const handleClearAll = () => {
    setHasUserInteracted(true);
    onSelectedCampaignsChange([]);
  };

  const getSummaryText = () => {
    if (selectionMode === "all") return language === 'de' ? "Alle Kampagnen (inkl. neue)" : "All campaigns (incl. new)";
    if (selectedCampaigns.length === 0) return language === 'de' ? "Kampagnen wählen..." : "Select campaigns...";
    if (selectedCampaigns.length === campaigns.length) return t.allCampaigns;
    if (selectedCampaigns.length === 1) return isDemoMode ? maskCampaignName(selectedCampaigns[0]) : selectedCampaigns[0];
    return language === 'de' 
      ? `${selectedCampaigns.length} von ${campaigns.length} Kampagnen`
      : `${selectedCampaigns.length} of ${campaigns.length} campaigns`;
  };

  return (
    <div className="space-y-3">
      <div>
        <div className="flex items-center gap-2">
          <Label className="text-sm font-medium">{t.campaignSelection}</Label>
          <TooltipProvider>
            <Tooltip>
              <TooltipTrigger asChild>
                <Button variant="ghost" size="icon" className="h-5 w-5 text-muted-foreground hover:text-foreground">
                  <Info className="h-4 w-4" />
                </Button>
              </TooltipTrigger>
              <TooltipContent side="right" className="max-w-xs z-50">
                <p className="font-semibold mb-1">{language === 'de' ? 'Regel-Prioritäten:' : 'Rule Priorities:'}</p>
                <ul className="text-xs space-y-1">
                  <li>• <strong>{language === 'de' ? 'Kampagnenspezifische Regeln' : 'Campaign-specific rules'}</strong> {language === 'de' ? 'haben höhere Priorität als Account-weite Regeln' : 'have higher priority than account-wide rules'}</li>
                  <li>• {language === 'de' ? 'Wenn für dieselbe Kampagne UND dieselbe Metrik mehrere Regeln existieren, wird die spezifischere angewendet' : 'If multiple rules exist for the same campaign AND metric, the more specific one is applied'}</li>
                </ul>
              </TooltipContent>
            </Tooltip>
          </TooltipProvider>
        </div>
        <ToggleGroup
          type="single"
          value={selectionMode}
          onValueChange={(value: string) => {
            if (value) {
              const newMode = value as "all" | "include" | "exclude";
              onSelectionModeChange(newMode);
              if (newMode === "include" && selectedCampaigns.length === 0) {
                onSelectedCampaignsChange([...campaigns]);
              }
            }
          }}
          className="justify-start mt-2 gap-2 flex-wrap"
        >
          <ToggleGroupItem
            value="all"
            variant="outline"
            className="border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
          >
            {t.allCampaigns}
          </ToggleGroupItem>
          <ToggleGroupItem
            value="include"
            variant="outline"
            className="border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
          >
            {t.onlySelected}
          </ToggleGroupItem>
          <ToggleGroupItem
            value="exclude"
            variant="outline"
            className="border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
          >
            {t.excludeSelected}
          </ToggleGroupItem>
        </ToggleGroup>
        <p className="text-xs text-muted-foreground mt-1">
          {selectionMode === "all" && (language === 'de' ? "Alle Kampagnen werden geprüft, inklusive neu hinzugefügter" : "All campaigns are checked, including newly added ones")}
          {selectionMode === "include" && (language === 'de' ? "Nur die ausgewählten Kampagnen werden geprüft" : "Only selected campaigns are checked")}
          {selectionMode === "exclude" && (language === 'de' ? "Alle Kampagnen AUSSER den ausgewählten werden geprüft" : "All campaigns EXCEPT the selected ones are checked")}
        </p>
      </div>

      {selectionMode !== "all" && (
      <Popover>
        <PopoverTrigger asChild>
          <Button
            variant="outline"
            role="combobox"
            className="w-full justify-between font-normal"
          >
            <div className="flex items-center gap-2 truncate">
              <Target className="h-4 w-4 text-muted-foreground shrink-0" />
              <span className={selectedCampaigns.length === 0 ? "text-muted-foreground" : ""}>
                {getSummaryText()}
              </span>
            </div>
            <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
          </Button>
        </PopoverTrigger>
        <PopoverContent className="w-[400px] p-0 z-50 bg-popover" align="start">
          <div className="p-2 border-b">
            <div className="relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder={t.searchCampaigns}
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="pl-9"
              />
            </div>
          </div>

          <div className="p-2 border-b flex justify-between items-center">
            <span className="text-xs text-muted-foreground">
              {language === 'de' 
                ? `${selectedCampaigns.length} von ${campaigns.length} ausgewählt`
                : `${selectedCampaigns.length} of ${campaigns.length} selected`}
            </span>
            <div className="flex gap-1">
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleSelectAll}
                className="h-7 text-xs gap-1"
              >
                <CheckSquare className="h-3 w-3" />
                {t.all}
              </Button>
              <Button
                type="button"
                variant="ghost"
                size="sm"
                onClick={handleClearAll}
                className="h-7 text-xs gap-1"
              >
                <XSquare className="h-3 w-3" />
                {t.none}
              </Button>
            </div>
          </div>

          {isLoading ? (
            <div className="flex items-center justify-center py-8 text-muted-foreground">
              <Loader2 className="h-5 w-5 animate-spin mr-2" />
              {language === 'de' ? 'Kampagnen werden geladen...' : 'Loading campaigns...'}
            </div>
          ) : campaigns.length === 0 ? (
            <div className="text-center py-8 text-muted-foreground text-sm">
              {language === 'de' ? 'Keine Kampagnen für diesen Account gefunden' : 'No campaigns found for this account'}
            </div>
          ) : (
            <ScrollArea className="h-[250px]">
              <div className="p-2 space-y-1">
                {filteredCampaigns.map((campaignName) => (
                  <div
                    key={campaignName}
                    className={`flex items-center gap-2 py-1.5 px-2 rounded cursor-pointer transition-colors ${
                      selectedCampaigns.includes(campaignName) ? 'bg-primary/10' : 'hover:bg-muted'
                    }`}
                    onClick={() => handleToggleCampaign(campaignName)}
                  >
                    <Checkbox
                      checked={selectedCampaigns.includes(campaignName)}
                      onCheckedChange={() => handleToggleCampaign(campaignName)}
                      onClick={(e) => e.stopPropagation()}
                    />
                    <span className="text-sm truncate flex-1" title={isDemoMode ? maskCampaignName(campaignName) : campaignName}>
                      {isDemoMode ? maskCampaignName(campaignName) : campaignName}
                    </span>
                  </div>
                ))}
                {filteredCampaigns.length === 0 && searchQuery && (
                  <div className="text-center py-4 text-muted-foreground text-sm">
                    {language === 'de' ? `Keine Kampagnen gefunden für "${searchQuery}"` : `No campaigns found for "${searchQuery}"`}
                  </div>
                )}
              </div>
            </ScrollArea>
          )}
        </PopoverContent>
      </Popover>
      )}
    </div>
  );
}

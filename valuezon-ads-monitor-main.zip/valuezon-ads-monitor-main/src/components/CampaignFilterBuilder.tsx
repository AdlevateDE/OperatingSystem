import { useMemo } from "react";
import { Plus, X } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { useLanguage } from "@/contexts/LanguageContext";

export interface CampaignFilter {
  metric: string;
  operator: string;
  value: number;
  period_days: number;
}

interface CampaignFilterBuilderProps {
  filters: CampaignFilter[];
  filtersLogic: 'AND' | 'OR';
  onFiltersChange: (filters: CampaignFilter[]) => void;
  onFiltersLogicChange: (logic: 'AND' | 'OR') => void;
}

const OPERATORS = [
  { id: '<', name: '<' },
  { id: '<=', name: '≤' },
  { id: '>', name: '>' },
  { id: '>=', name: '≥' },
  { id: '=', name: '=' },
];

export function CampaignFilterBuilder({
  filters,
  filtersLogic,
  onFiltersChange,
  onFiltersLogicChange,
}: CampaignFilterBuilderProps) {
  const { language, t } = useLanguage();

  const FILTER_METRICS = useMemo(() => [
    { id: 'cost', name: t.cost, unit: '€' },
    { id: 'clicks', name: t.clicks, unit: '' },
    { id: 'impressions', name: t.impressions, unit: '' },
    { id: 'cpc', name: t.cpc, unit: '€' },
    { id: 'ctr', name: t.ctr, unit: '%' },
    { id: 'acos', name: t.acos, unit: '%' },
    { id: 'roas', name: 'ROAS', unit: '' },
  ], [t]);

  const PERIODS = useMemo(() => [
    { days: 1, name: t.yesterday },
    { days: 7, name: language === 'de' ? 'Letzte 7 Tage' : 'Last 7 days' },
    { days: 14, name: language === 'de' ? 'Letzte 14 Tage' : 'Last 14 days' },
    { days: 30, name: language === 'de' ? 'Letzte 30 Tage' : 'Last 30 days' },
  ], [t, language]);

  const addFilter = () => {
    onFiltersChange([
      ...filters,
      { metric: 'cost', operator: '>', value: 0, period_days: 7 },
    ]);
  };

  const removeFilter = (index: number) => {
    onFiltersChange(filters.filter((_, i) => i !== index));
  };

  const updateFilter = (index: number, updates: Partial<CampaignFilter>) => {
    onFiltersChange(
      filters.map((filter, i) =>
        i === index ? { ...filter, ...updates } : filter
      )
    );
  };

  const getMetricUnit = (metricId: string) => {
    return FILTER_METRICS.find((m) => m.id === metricId)?.unit || '';
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">
          {language === 'de' ? 'Kampagnen-Vorfilter (optional)' : 'Campaign Pre-filters (optional)'}
        </Label>
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addFilter}
          className="h-8"
        >
          <Plus className="h-4 w-4 mr-1" />
          {language === 'de' ? 'Filter hinzufügen' : 'Add filter'}
        </Button>
      </div>

      {filters.length === 0 && (
        <p className="text-sm text-muted-foreground">
          {language === 'de' 
            ? 'Keine Vorfilter aktiv. Alle Kampagnen werden geprüft.'
            : 'No pre-filters active. All campaigns will be checked.'}
        </p>
      )}

      {filters.length > 0 && (
        <div className="space-y-3">
          {filters.map((filter, index) => (
            <div key={index} className="flex items-center gap-2 p-3 bg-muted/50 rounded-lg">
              {index > 0 && (
                <span className="text-xs font-medium text-muted-foreground w-10">
                  {filtersLogic}
                </span>
              )}
              {index === 0 && <span className="w-10" />}
              
              <Select
                value={filter.metric}
                onValueChange={(value) => updateFilter(index, { metric: value })}
              >
                <SelectTrigger className="w-[130px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {FILTER_METRICS.map((metric) => (
                    <SelectItem key={metric.id} value={metric.id}>
                      {metric.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Select
                value={filter.operator}
                onValueChange={(value) => updateFilter(index, { operator: value })}
              >
                <SelectTrigger className="w-[70px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {OPERATORS.map((op) => (
                    <SelectItem key={op.id} value={op.id}>
                      {op.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <div className="relative w-[100px]">
                <Input
                  type="number"
                  value={filter.value}
                  onChange={(e) =>
                    updateFilter(index, { value: parseFloat(e.target.value) || 0 })
                  }
                  className="pr-6"
                />
                <span className="absolute right-2 top-1/2 -translate-y-1/2 text-xs text-muted-foreground">
                  {getMetricUnit(filter.metric)}
                </span>
              </div>

              <Select
                value={(filter.period_days ?? 7).toString()}
                onValueChange={(value) =>
                  updateFilter(index, { period_days: parseInt(value) })
                }
              >
                <SelectTrigger className="w-[140px]">
                  <SelectValue />
                </SelectTrigger>
                <SelectContent>
                  {PERIODS.map((period) => (
                    <SelectItem key={period.days} value={period.days.toString()}>
                      {period.name}
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>

              <Button
                type="button"
                variant="ghost"
                size="icon"
                onClick={() => removeFilter(index)}
                className="h-8 w-8 text-muted-foreground hover:text-destructive"
              >
                <X className="h-4 w-4" />
              </Button>
            </div>
          ))}

          {filters.length > 1 && (
            <div className="flex items-center gap-3 pt-2">
              <Label className="text-sm text-muted-foreground">
                {language === 'de' ? 'Filter-Logik:' : 'Filter logic:'}
              </Label>
              <ToggleGroup
                type="single"
                value={filtersLogic}
                onValueChange={(value) => {
                  if (value) onFiltersLogicChange(value as 'AND' | 'OR');
                }}
                className="justify-start"
              >
                <ToggleGroupItem value="AND" className="text-xs px-3">
                  {language === 'de' ? 'UND (alle erfüllt)' : 'AND (all met)'}
                </ToggleGroupItem>
                <ToggleGroupItem value="OR" className="text-xs px-3">
                  {language === 'de' ? 'ODER (mind. einer)' : 'OR (at least one)'}
                </ToggleGroupItem>
              </ToggleGroup>
            </div>
          )}

          <p className="text-xs text-muted-foreground pt-1">
            {filtersLogic === 'AND' 
              ? (language === 'de' ? 'Nur Kampagnen, die ALLE Filter erfüllen, werden geprüft.' : 'Only campaigns that meet ALL filters will be checked.')
              : (language === 'de' ? 'Kampagnen, die MINDESTENS EINEN Filter erfüllen, werden geprüft.' : 'Campaigns that meet AT LEAST ONE filter will be checked.')}
          </p>
        </div>
      )}
    </div>
  );
}

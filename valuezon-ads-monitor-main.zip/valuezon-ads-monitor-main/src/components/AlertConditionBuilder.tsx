import { useState, useMemo } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Card, CardContent } from "@/components/ui/card";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Badge } from "@/components/ui/badge";
import { Plus, Trash2, DollarSign, MousePointer, Eye, Percent, TrendingUp, AlertTriangle } from "lucide-react";
import { useLanguage } from "@/contexts/LanguageContext";

export interface AlertCondition {
  id: string;
  metric_name: string;
  threshold_value: number;
  threshold_type: "percentage" | "absolute";
  alert_direction: string;
  comparison_period: string;
}

interface AlertConditionBuilderProps {
  conditions: AlertCondition[];
  conditionsLogic: "AND" | "OR";
  onConditionsChange: (conditions: AlertCondition[]) => void;
  onConditionsLogicChange: (logic: "AND" | "OR") => void;
}

export function AlertConditionBuilder({
  conditions,
  conditionsLogic,
  onConditionsChange,
  onConditionsLogicChange,
}: AlertConditionBuilderProps) {
  const { language, t } = useLanguage();

  const metrics = useMemo(() => [
    { id: "cost", name: t.cost, icon: DollarSign, unit: "€", allowsAbsolute: true, allowsPercentage: true },
    { id: "cost_no_conversions", name: t.costNoConversions, icon: AlertTriangle, unit: "€", allowsAbsolute: true, allowsPercentage: false },
    { id: "clicks", name: t.clicks, icon: MousePointer, unit: t.clicks, allowsAbsolute: true, allowsPercentage: true },
    { id: "impressions", name: t.impressions, icon: Eye, unit: t.impressions, allowsAbsolute: true, allowsPercentage: true },
    { id: "cpc", name: t.cpc, icon: DollarSign, unit: "€", allowsAbsolute: true, allowsPercentage: true },
    { id: "ctr", name: t.ctr, icon: Percent, unit: "%", allowsAbsolute: true, allowsPercentage: true },
    { id: "acos", name: t.acos, icon: TrendingUp, unit: "%", allowsAbsolute: true, allowsPercentage: true },
  ], [t]);

  const comparisonPeriods = useMemo(() => [
    { id: "yesterday", name: t.yesterday },
    { id: "same_day_last_week", name: t.sameDayLastWeek },
    { id: "last_7_days", name: t.last7Days },
    { id: "last_14_days", name: t.last14Days },
    { id: "last_30_days", name: t.last30Days },
  ], [t]);

  const generateId = () => Math.random().toString(36).substring(2, 9);

  const addCondition = () => {
    if (conditions.length >= 3) return;
    onConditionsChange([
      ...conditions,
      {
        id: generateId(),
        metric_name: "",
        threshold_value: 30,
        threshold_type: "percentage",
        alert_direction: "decreases",
        comparison_period: "last_7_days",
      },
    ]);
  };

  const removeCondition = (id: string) => {
    if (conditions.length <= 1) return;
    onConditionsChange(conditions.filter((c) => c.id !== id));
  };

  const updateCondition = (id: string, updates: Partial<AlertCondition>) => {
    onConditionsChange(
      conditions.map((c) => (c.id === id ? { ...c, ...updates } : c))
    );
  };

  const getMetricConfig = (metricId: string) => {
    return metrics.find((m) => m.id === metricId);
  };

  return (
    <div className="space-y-4">
      <div className="flex items-center justify-between">
        <Label className="text-sm font-medium">{t.alertConditions}</Label>
        {conditions.length > 1 && (
          <ToggleGroup
            type="single"
            value={conditionsLogic}
            onValueChange={(value) => {
              if (value) onConditionsLogicChange(value as "AND" | "OR");
            }}
            className="h-8"
          >
            <ToggleGroupItem
              value="AND"
              className="h-7 px-3 text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground"
            >
              {language === 'de' ? 'UND' : 'AND'}
            </ToggleGroupItem>
            <ToggleGroupItem
              value="OR"
              className="h-7 px-3 text-xs data-[state=on]:bg-primary data-[state=on]:text-primary-foreground"
            >
              {language === 'de' ? 'ODER' : 'OR'}
            </ToggleGroupItem>
          </ToggleGroup>
        )}
      </div>

      <div className="space-y-3">
        {conditions.map((condition, index) => {
          const metricConfig = getMetricConfig(condition.metric_name);
          const isAbsoluteOnly = metricConfig && !metricConfig.allowsPercentage;
          const needsComparisonPeriod = !isAbsoluteOnly;

          return (
            <div key={condition.id}>
              {index > 0 && (
                <div className="flex items-center justify-center py-2">
                  <Badge
                    variant="secondary"
                    className="bg-primary/10 text-primary font-medium"
                  >
                    {conditionsLogic === "AND" ? (language === 'de' ? 'UND' : 'AND') : (language === 'de' ? 'ODER' : 'OR')}
                  </Badge>
                </div>
              )}

              <Card className="border-2">
                <CardContent className="p-4 space-y-3">
                  <div className="flex items-center justify-between">
                    <span className="text-xs font-medium text-muted-foreground">
                      {language === 'de' ? 'Bedingung' : 'Condition'} {index + 1}
                    </span>
                    {conditions.length > 1 && (
                      <Button
                        type="button"
                        variant="ghost"
                        size="sm"
                        onClick={() => removeCondition(condition.id)}
                        className="h-7 w-7 p-0 text-destructive hover:text-destructive"
                      >
                        <Trash2 className="h-4 w-4" />
                      </Button>
                    )}
                  </div>

                  <div className="grid grid-cols-2 gap-3">
                    <div>
                      <Label className="text-xs">{t.metric}</Label>
                      <Select
                        value={condition.metric_name}
                        onValueChange={(v) => {
                          const newMetric = getMetricConfig(v);
                          const updates: Partial<AlertCondition> = { metric_name: v };
                          if (newMetric && !newMetric.allowsPercentage) {
                            updates.threshold_type = "absolute";
                            updates.comparison_period = "none";
                          }
                          updateCondition(condition.id, updates);
                        }}
                      >
                        <SelectTrigger className="h-9">
                          <SelectValue placeholder={language === 'de' ? 'Metrik wählen' : 'Select metric'} />
                        </SelectTrigger>
                        <SelectContent>
                          {metrics.map((metric) => (
                            <SelectItem key={metric.id} value={metric.id}>
                              <div className="flex items-center gap-2">
                                <metric.icon className="h-3 w-3" />
                                {metric.name}
                              </div>
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>

                    {metricConfig &&
                      metricConfig.allowsAbsolute &&
                      metricConfig.allowsPercentage && (
                        <div>
                          <Label className="text-xs">{language === 'de' ? 'Typ' : 'Type'}</Label>
                          <Select
                            value={condition.threshold_type}
                            onValueChange={(v) =>
                              updateCondition(condition.id, {
                                threshold_type: v as "percentage" | "absolute",
                                comparison_period: condition.comparison_period === "none" ? "last_7_days" : condition.comparison_period,
                              })
                            }
                          >
                            <SelectTrigger className="h-9">
                              <SelectValue />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="percentage">{t.percentage}</SelectItem>
                              <SelectItem value="absolute">{t.absolute}</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      )}
                  </div>

                  <div className="flex items-center gap-2">
                    <Select
                      value={condition.alert_direction}
                      onValueChange={(v) =>
                        updateCondition(condition.id, { alert_direction: v })
                      }
                    >
                      <SelectTrigger className="w-[140px] h-9">
                        <SelectValue />
                      </SelectTrigger>
                      <SelectContent>
                        {isAbsoluteOnly ? (
                          <>
                            <SelectItem value="increases">{language === 'de' ? 'größer als' : 'greater than'}</SelectItem>
                            <SelectItem value="decreases">{language === 'de' ? 'kleiner als' : 'less than'}</SelectItem>
                          </>
                        ) : condition.threshold_type === "absolute" ? (
                          <>
                            <SelectItem value="increases">{language === 'de' ? 'Steigt um mehr als' : 'Increases by more than'}</SelectItem>
                            <SelectItem value="decreases">{language === 'de' ? 'Sinkt um mehr als' : 'Decreases by more than'}</SelectItem>
                            <SelectItem value="both">{language === 'de' ? 'Ändert sich um mehr als' : 'Changes by more than'}</SelectItem>
                          </>
                        ) : (
                          <>
                            <SelectItem value="increases">{language === 'de' ? 'Steigt um' : 'Increases by'}</SelectItem>
                            <SelectItem value="decreases">{language === 'de' ? 'Sinkt um' : 'Decreases by'}</SelectItem>
                            <SelectItem value="both">{language === 'de' ? 'Ändert sich um' : 'Changes by'}</SelectItem>
                          </>
                        )}
                      </SelectContent>
                    </Select>

                    <div className="flex items-center gap-1 flex-1">
                      <Input
                        type="number"
                        value={condition.threshold_value}
                        onChange={(e) =>
                          updateCondition(condition.id, {
                            threshold_value: Number(e.target.value),
                          })
                        }
                        className="h-9"
                      />
                      <span className="text-sm text-muted-foreground whitespace-nowrap">
                        {condition.threshold_type === "percentage" && !isAbsoluteOnly
                          ? "%"
                          : metricConfig?.unit || ""}
                      </span>
                    </div>
                  </div>

                  {needsComparisonPeriod && (
                    <div>
                      <Label className="text-xs">{language === 'de' ? 'Vergleich mit' : 'Compare to'}</Label>
                      <Select
                        value={condition.comparison_period || "last_7_days"}
                        onValueChange={(v) =>
                          updateCondition(condition.id, { comparison_period: v })
                        }
                      >
                        <SelectTrigger className="h-9">
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {comparisonPeriods.map((period) => (
                            <SelectItem key={period.id} value={period.id}>
                              {period.name}
                            </SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </div>
                  )}
                </CardContent>
              </Card>
            </div>
          );
        })}
      </div>

      {conditions.length < 3 && (
        <Button
          type="button"
          variant="outline"
          size="sm"
          onClick={addCondition}
          className="w-full"
        >
          <Plus className="h-4 w-4 mr-2" />
          {t.addCondition}
        </Button>
      )}

      {conditions.length >= 3 && (
        <p className="text-xs text-muted-foreground text-center">
          {t.maxConditions}
        </p>
      )}

      {conditions.length > 1 && (
        <p className="text-xs text-muted-foreground">
          {conditionsLogic === "AND"
            ? (language === 'de' ? "Alert wird nur ausgelöst, wenn ALLE Bedingungen erfüllt sind" : "Alert is only triggered when ALL conditions are met")
            : (language === 'de' ? "Alert wird ausgelöst, wenn MINDESTENS EINE Bedingung erfüllt ist" : "Alert is triggered when AT LEAST ONE condition is met")}
        </p>
      )}
    </div>
  );
}

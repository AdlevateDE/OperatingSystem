import { useState, useEffect } from "react";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
  DialogFooter,
} from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from "@/components/ui/select";
import { useLanguage } from "@/contexts/LanguageContext";
import { Tables } from "@/integrations/supabase/types";

type Account = Tables<"amazon_accounts">;

interface AccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  account?: Account | null;
  onSave: (data: {
    account_name: string;
    profile_id: string;
    marketplace: string;
    currency_code: string;
  }) => Promise<void>;
  isSaving?: boolean;
}

const MARKETPLACES = [
  { value: "DE", label: "Germany (DE)" },
  { value: "US", label: "United States (US)" },
  { value: "UK", label: "United Kingdom (UK)" },
  { value: "FR", label: "France (FR)" },
  { value: "IT", label: "Italy (IT)" },
  { value: "ES", label: "Spain (ES)" },
  { value: "NL", label: "Netherlands (NL)" },
  { value: "SE", label: "Sweden (SE)" },
  { value: "PL", label: "Poland (PL)" },
  { value: "CA", label: "Canada (CA)" },
  { value: "MX", label: "Mexico (MX)" },
  { value: "JP", label: "Japan (JP)" },
  { value: "AU", label: "Australia (AU)" },
];

const CURRENCIES = [
  { value: "EUR", label: "Euro (EUR)" },
  { value: "USD", label: "US Dollar (USD)" },
  { value: "GBP", label: "British Pound (GBP)" },
  { value: "SEK", label: "Swedish Krona (SEK)" },
  { value: "PLN", label: "Polish Zloty (PLN)" },
  { value: "CAD", label: "Canadian Dollar (CAD)" },
  { value: "MXN", label: "Mexican Peso (MXN)" },
  { value: "JPY", label: "Japanese Yen (JPY)" },
  { value: "AUD", label: "Australian Dollar (AUD)" },
];

export function AccountDialog({
  open,
  onOpenChange,
  account,
  onSave,
  isSaving = false,
}: AccountDialogProps) {
  const { t } = useLanguage();
  const [accountName, setAccountName] = useState("");
  const [profileId, setProfileId] = useState("");
  const [marketplace, setMarketplace] = useState("DE");
  const [currencyCode, setCurrencyCode] = useState("EUR");

  const isEditing = !!account;

  useEffect(() => {
    if (account) {
      setAccountName(account.account_name);
      setProfileId(account.profile_id);
      setMarketplace(account.marketplace);
      setCurrencyCode(account.currency_code);
    } else {
      setAccountName("");
      setProfileId("");
      setMarketplace("DE");
      setCurrencyCode("EUR");
    }
  }, [account, open]);

  const handleSave = async () => {
    await onSave({
      account_name: accountName,
      profile_id: profileId,
      marketplace,
      currency_code: currencyCode,
    });
  };

  const isValid = accountName.trim() && profileId.trim();

  return (
    <Dialog open={open} onOpenChange={onOpenChange}>
      <DialogContent>
        <DialogHeader>
          <DialogTitle>
            {isEditing ? t.editAccount : t.addAccount}
          </DialogTitle>
        </DialogHeader>

        <div className="space-y-4 py-4">
          <div className="space-y-2">
            <Label htmlFor="accountName">{t.accountName}</Label>
            <Input
              id="accountName"
              value={accountName}
              onChange={(e) => setAccountName(e.target.value)}
              placeholder="z.B. My Brand DE"
            />
          </div>

          <div className="space-y-2">
            <Label htmlFor="profileId">Profile ID</Label>
            <Input
              id="profileId"
              value={profileId}
              onChange={(e) => setProfileId(e.target.value)}
              placeholder="z.B. 1234567890"
              disabled={isEditing}
            />
            {isEditing && (
              <p className="text-xs text-muted-foreground">
                Profile ID kann nicht geändert werden
              </p>
            )}
          </div>

          <div className="space-y-2">
            <Label htmlFor="marketplace">{t.marketplace}</Label>
            <Select value={marketplace} onValueChange={setMarketplace}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {MARKETPLACES.map((mp) => (
                  <SelectItem key={mp.value} value={mp.value}>
                    {mp.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label htmlFor="currency">{t.currency}</Label>
            <Select value={currencyCode} onValueChange={setCurrencyCode}>
              <SelectTrigger>
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                {CURRENCIES.map((curr) => (
                  <SelectItem key={curr.value} value={curr.value}>
                    {curr.label}
                  </SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={() => onOpenChange(false)}>
            {t.cancel}
          </Button>
          <Button onClick={handleSave} disabled={!isValid || isSaving}>
            {isSaving ? t.saving : t.save}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

import { DollarSign, MousePointer, Eye, Percent, TrendingUp } from "lucide-react";
import { cn } from "@/lib/utils";

interface MetricIconProps {
  metric: string;
  size?: "sm" | "md" | "lg";
  className?: string;
}

const iconMap: Record<string, any> = {
  cost: DollarSign,
  clicks: MousePointer,
  impressions: Eye,
  cpc: DollarSign,
  ctr: Percent,
  acos: TrendingUp,
};

const sizeMap = {
  sm: "h-4 w-4",
  md: "h-5 w-5",
  lg: "h-6 w-6",
};

export function MetricIcon({ metric, size = "md", className }: MetricIconProps) {
  const Icon = iconMap[metric.toLowerCase()] || TrendingUp;
  
  return <Icon className={cn(sizeMap[size], className)} />;
}

import { useState, useEffect, useMemo } from "react";
import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group";
import { Checkbox } from "@/components/ui/checkbox";
import { Card, CardContent } from "@/components/ui/card";
import { Alert, AlertDescription } from "@/components/ui/alert";
import { ToggleGroup, ToggleGroupItem } from "@/components/ui/toggle-group";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { ScrollArea } from "@/components/ui/scroll-area";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { useAccounts } from "@/hooks/useAccounts";
import { useAlertRules } from "@/hooks/useAlertRules";
import { useCampaigns } from "@/hooks/useCampaigns";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { maskAccountName, maskCampaignName } from "@/lib/demoMode";
import { MetricIcon } from "./MetricIcon";
import { CampaignMultiSelect } from "./CampaignMultiSelect";
import { CampaignFilterBuilder, CampaignFilter } from "./CampaignFilterBuilder";
import { AlertConditionBuilder, AlertCondition } from "./AlertConditionBuilder";
import { DollarSign, MousePointer, Eye, Percent, TrendingUp, AlertTriangle, Package, Store, Monitor, Check, ChevronDown, Building2 } from "lucide-react";

interface RuleBuilderProps {
  open: boolean;
  onClose: () => void;
  editRule?: any;
}

const generateConditionId = () => Math.random().toString(36).substring(2, 9);

export function RuleBuilder({ open, onClose, editRule }: RuleBuilderProps) {
  const [step, setStep] = useState(1);
  const { language, t } = useLanguage();
  
  const metrics = useMemo(() => [
    { id: "cost", name: t.cost, icon: DollarSign, unit: "€", allowsAbsolute: true, allowsPercentage: true },
    { id: "cost_no_conversions", name: t.costNoConversions, icon: AlertTriangle, unit: "€", allowsAbsolute: true, allowsPercentage: false },
    { id: "clicks", name: t.clicks, icon: MousePointer, unit: t.clicks, allowsAbsolute: true, allowsPercentage: true },
    { id: "impressions", name: t.impressions, icon: Eye, unit: t.impressions, allowsAbsolute: true, allowsPercentage: true },
    { id: "cpc", name: t.cpc, icon: DollarSign, unit: "€", allowsAbsolute: true, allowsPercentage: true },
    { id: "ctr", name: t.ctr, icon: Percent, unit: "%", allowsAbsolute: true, allowsPercentage: true },
    { id: "acos", name: t.acos, icon: TrendingUp, unit: "%", allowsAbsolute: true, allowsPercentage: true },
  ], [t]);

  const comparisonPeriods = useMemo(() => [
    { id: "yesterday", name: t.yesterday },
    { id: "same_day_last_week", name: t.sameDayLastWeek },
    { id: "last_7_days", name: t.last7Days },
    { id: "last_14_days", name: t.last14Days },
    { id: "last_30_days", name: t.last30Days },
  ], [t]);
  
  const [formData, setFormData] = useState({
    ruleName: "",
    accountIds: [] as string[],
    metric: "",
    thresholdType: "percentage" as "percentage" | "absolute",
    alertDirection: "decreases",
    threshold: 30,
    comparisonPeriod: "",
    alertConditions: [{
      id: generateConditionId(),
      metric_name: "",
      threshold_value: 30,
      threshold_type: "percentage" as "percentage" | "absolute",
      alert_direction: "decreases",
      comparison_period: "last_7_days",
    }] as AlertCondition[],
    alertConditionsLogic: "AND" as "AND" | "OR",
    checkFrequency: "daily",
    checkSchedule: "both",
    slackEnabled: true,
    campaignTypes: ["sp"] as string[],
    selectedCampaigns: [] as string[],
    campaignSelectionMode: "all" as "all" | "include" | "exclude",
    campaignFilters: [] as CampaignFilter[],
    campaignFiltersLogic: "AND" as "AND" | "OR",
  });

  const { accounts } = useAccounts();
  const { createRule, updateRule } = useAlertRules();
  const { isDemoMode } = useDemoMode();
  
  const { data: availableCampaigns = [], isLoading: campaignsLoading } = useCampaigns({
    accountIds: formData.accountIds,
    enabled: formData.accountIds.length > 0,
  });
  
  const selectedAccountNames = useMemo(() => {
    return accounts
      .filter(a => formData.accountIds.includes(a.id))
      .map(a => isDemoMode ? maskAccountName(a.account_name) : a.account_name);
  }, [accounts, formData.accountIds, isDemoMode]);
  
  const toggleAccount = (accountId: string) => {
    setFormData(prev => ({
      ...prev,
      accountIds: prev.accountIds.includes(accountId)
        ? prev.accountIds.filter(id => id !== accountId)
        : [...prev.accountIds, accountId],
      selectedCampaigns: [],
    }));
  };
  
  const selectAllAccounts = () => {
    setFormData(prev => ({
      ...prev,
      accountIds: accounts.map(a => a.id),
      selectedCampaigns: [],
    }));
  };
  
  const clearAllAccounts = () => {
    setFormData(prev => ({
      ...prev,
      accountIds: [],
      selectedCampaigns: [],
    }));
  };

  useEffect(() => {
    if (editRule) {
      const accountIds = editRule.account_ids || (editRule.account_id ? [editRule.account_id] : []);
      
      let alertConditions: AlertCondition[];
      if (editRule.alert_conditions && Array.isArray(editRule.alert_conditions) && editRule.alert_conditions.length > 0) {
        // Normalize field names from old format (metric, direction, threshold) to new format (metric_name, alert_direction, threshold_value)
        alertConditions = editRule.alert_conditions.map((c: any) => ({
          id: c.id || generateConditionId(),
          metric_name: c.metric_name || c.metric || "",
          threshold_value: c.threshold_value ?? c.threshold ?? 30,
          threshold_type: c.threshold_type || c.thresholdType || "percentage",
          alert_direction: c.alert_direction || c.direction || "decreases",
          comparison_period: c.comparison_period || editRule.comparison_period || "last_7_days",
        }));
      } else {
        alertConditions = [{
          id: generateConditionId(),
          metric_name: editRule.metric_name || "",
          threshold_value: editRule.threshold_percent || 30,
          threshold_type: editRule.threshold_type || "percentage",
          alert_direction: editRule.alert_direction || "decreases",
          comparison_period: editRule.comparison_period || "last_7_days",
        }];
      }
      
      setFormData({
        ruleName: editRule.rule_name || "",
        accountIds: accountIds,
        metric: editRule.metric_name || "",
        thresholdType: editRule.threshold_type || "percentage",
        alertDirection: editRule.alert_direction || "decreases",
        threshold: editRule.threshold_percent || 30,
        comparisonPeriod: editRule.comparison_period || "",
        alertConditions: alertConditions,
        alertConditionsLogic: editRule.alert_conditions_logic || "AND",
        checkFrequency: editRule.check_frequency || "daily",
        checkSchedule: editRule.check_schedule || "both",
        slackEnabled: true,
        campaignTypes: editRule.campaign_types || ["sp"],
        selectedCampaigns: editRule.selected_campaigns || [],
        campaignSelectionMode: editRule.campaign_selection_mode || "all",
        campaignFilters: editRule.campaign_filters || [],
        campaignFiltersLogic: editRule.campaign_filters_logic || "AND",
      });
    }
  }, [editRule]);

  const handleNext = () => {
    if (step < 2) setStep(step + 1);
  };

  const handleBack = () => {
    if (step > 1) setStep(step - 1);
  };

  const resetForm = () => {
    setStep(1);
    setFormData({
      ruleName: "",
      accountIds: [],
      metric: "",
      thresholdType: "percentage",
      alertDirection: "decreases",
      threshold: 30,
      comparisonPeriod: "",
      alertConditions: [{
        id: generateConditionId(),
        metric_name: "",
        threshold_value: 30,
        threshold_type: "percentage",
        alert_direction: "decreases",
        comparison_period: "last_7_days",
      }],
      alertConditionsLogic: "AND",
      checkFrequency: "daily",
      checkSchedule: "both",
      slackEnabled: true,
      campaignTypes: ["sp"],
      selectedCampaigns: [],
      campaignSelectionMode: "all",
      campaignFilters: [],
      campaignFiltersLogic: "AND",
    });
  };

  const handleSubmit = () => {
    const filtersToSave = formData.campaignSelectionMode === 'all' && formData.campaignFilters.length > 0 
      ? formData.campaignFilters 
      : null;
    
    const conditionsToSave = formData.alertConditions.map(({ id, ...rest }) => rest);
    
    const firstCondition = formData.alertConditions[0];
    const legacyMetric = firstCondition?.metric_name || "";
    const legacyThreshold = firstCondition?.threshold_value || 30;
    const legacyThresholdType = firstCondition?.threshold_type || "percentage";
    const legacyAlertDirection = firstCondition?.alert_direction || "decreases";
    const metricConfig = metrics.find(m => m.id === legacyMetric);
    const isAbsoluteOnlyMetric = metricConfig && !metricConfig.allowsPercentage;
    const legacyComparisonPeriod = isAbsoluteOnlyMetric ? 'none' : (firstCondition?.comparison_period || "last_7_days");
    
    if (editRule) {
      const previousValues = {
        rule_name: editRule.rule_name,
        account_id: editRule.account_id,
        account_ids: editRule.account_ids,
        metric_name: editRule.metric_name,
        threshold_percent: editRule.threshold_percent,
        threshold_type: editRule.threshold_type,
        comparison_period: editRule.comparison_period,
        check_frequency: editRule.check_frequency,
        check_schedule: editRule.check_schedule,
        alert_direction: editRule.alert_direction,
        campaign_types: editRule.campaign_types,
        selected_campaigns: editRule.selected_campaigns,
        campaign_selection_mode: editRule.campaign_selection_mode,
        campaign_filters: editRule.campaign_filters,
        campaign_filters_logic: editRule.campaign_filters_logic,
        alert_conditions: editRule.alert_conditions,
        alert_conditions_logic: editRule.alert_conditions_logic,
      };

      updateRule.mutate(
        {
          id: editRule.id,
          updates: {
            rule_name: formData.ruleName,
            account_id: formData.accountIds[0] || null,
            account_ids: formData.accountIds,
            metric_name: legacyMetric,
            threshold_percent: legacyThreshold,
            threshold_type: legacyThresholdType,
            comparison_period: legacyComparisonPeriod,
            alert_direction: legacyAlertDirection,
            alert_conditions: conditionsToSave,
            alert_conditions_logic: formData.alertConditionsLogic,
            check_frequency: formData.checkFrequency,
            check_schedule: formData.checkSchedule,
            campaign_types: formData.campaignTypes,
            selected_campaigns: formData.selectedCampaigns,
            campaign_selection_mode: formData.campaignSelectionMode,
            campaign_filters: filtersToSave,
            campaign_filters_logic: formData.campaignFiltersLogic,
          } as any,
          previousValues,
        },
        {
          onSuccess: () => {
            onClose();
            resetForm();
          },
        }
      );
    } else {
      createRule.mutate(
        {
          rule_name: formData.ruleName,
          account_id: formData.accountIds[0] || null,
          account_ids: formData.accountIds,
          metric_name: legacyMetric,
          threshold_percent: legacyThreshold,
          threshold_type: legacyThresholdType,
          comparison_period: legacyComparisonPeriod,
          alert_direction: legacyAlertDirection,
          alert_conditions: conditionsToSave,
          alert_conditions_logic: formData.alertConditionsLogic,
          check_frequency: formData.checkFrequency,
          check_schedule: formData.checkSchedule,
          campaign_types: formData.campaignTypes,
          selected_campaigns: formData.selectedCampaigns,
          campaign_selection_mode: formData.campaignSelectionMode,
          campaign_filters: filtersToSave,
          campaign_filters_logic: formData.campaignFiltersLogic,
          is_active: true,
        } as any,
        {
          onSuccess: () => {
            onClose();
            resetForm();
          },
        }
      );
    }
  };

  const areConditionsValid = useMemo(() => {
    return formData.alertConditions.every(condition => {
      if (!condition.metric_name) return false;
      if (condition.threshold_value === undefined || condition.threshold_value === null) return false;
      
      const metricConfig = metrics.find(m => m.id === condition.metric_name);
      const isAbsolute = condition.threshold_type === 'absolute' || (metricConfig && !metricConfig.allowsPercentage);
      if (!isAbsolute && !condition.comparison_period) return false;
      
      return true;
    });
  }, [formData.alertConditions, metrics]);

  const canProceed = () => {
    switch (step) {
      case 1:
        return formData.ruleName && formData.accountIds.length > 0 && areConditionsValid;
      case 2:
        return formData.checkSchedule !== "";
      default:
        return false;
    }
  };

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-2xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>{editRule ? t.editRule : t.createRule}</DialogTitle>
        </DialogHeader>

        {/* Progress Bar */}
        <div className="flex items-center gap-2 mb-6">
          {[1, 2].map((s) => (
            <div
              key={s}
              className={`h-2 flex-1 rounded-full ${
                s <= step ? "bg-primary" : "bg-muted"
              }`}
            />
          ))}
        </div>

        {/* Step 1 */}
        {step === 1 && (
          <div className="space-y-4">
            <div>
              <Label htmlFor="ruleName">{t.ruleName} *</Label>
              <Input
                id="ruleName"
                value={formData.ruleName}
                onChange={(e) => setFormData({ ...formData, ruleName: e.target.value })}
                placeholder={t.ruleNamePlaceholder}
              />
            </div>
            
            <div>
              <Label className="mb-2 block">{t.selectAccounts} *</Label>
              <Popover>
                <PopoverTrigger asChild>
                  <Button
                    variant="outline"
                    role="combobox"
                    className="w-full justify-between font-normal"
                  >
                    <div className="flex items-center gap-2 truncate">
                      <Building2 className="h-4 w-4 text-muted-foreground shrink-0" />
                      {formData.accountIds.length === 0 ? (
                        <span className="text-muted-foreground">{t.selectAccountsPlaceholder}</span>
                      ) : formData.accountIds.length === 1 ? (
                        <span>{isDemoMode ? maskAccountName(accounts.find(a => a.id === formData.accountIds[0])?.account_name) : accounts.find(a => a.id === formData.accountIds[0])?.account_name}</span>
                      ) : (
                        <span>{formData.accountIds.length} {t.accountsSelected}</span>
                      )}
                    </div>
                    <ChevronDown className="h-4 w-4 shrink-0 opacity-50" />
                  </Button>
                </PopoverTrigger>
                <PopoverContent className="w-[400px] p-0 z-50 bg-popover" align="start">
                  <div className="p-2 border-b flex justify-between items-center">
                    <span className="text-sm font-medium">{t.accounts}</span>
                    <div className="flex gap-1">
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        onClick={selectAllAccounts}
                        className="h-7 text-xs"
                      >
                        {t.all}
                      </Button>
                      <Button 
                        type="button" 
                        variant="ghost" 
                        size="sm" 
                        onClick={clearAllAccounts}
                        className="h-7 text-xs"
                      >
                        {t.none}
                      </Button>
                    </div>
                  </div>
                  <ScrollArea className="h-[200px]">
                    <div className="p-2 space-y-1">
                      {accounts.map((account) => (
                        <div
                          key={account.id}
                          className={`flex items-center gap-2 p-2 rounded-md cursor-pointer transition-colors ${
                            formData.accountIds.includes(account.id)
                              ? 'bg-primary/10'
                              : 'hover:bg-muted'
                          }`}
                          onClick={() => toggleAccount(account.id)}
                        >
                          <Checkbox
                            checked={formData.accountIds.includes(account.id)}
                            onCheckedChange={() => toggleAccount(account.id)}
                            onClick={(e) => e.stopPropagation()}
                          />
                          <span className="text-sm">{isDemoMode ? maskAccountName(account.account_name) : account.account_name}</span>
                          <span className="text-xs text-muted-foreground">({account.marketplace})</span>
                        </div>
                      ))}
                    </div>
                  </ScrollArea>
                </PopoverContent>
              </Popover>
              {formData.accountIds.length > 0 && (
                <p className="text-xs text-muted-foreground mt-1">
                  {formData.accountIds.length} {formData.accountIds.length > 1 ? t.accountsSelected : (language === 'de' ? 'Account ausgewählt' : 'account selected')}
                </p>
              )}
            </div>

            {/* Campaign Selection */}
            {formData.accountIds.length > 0 && (
              <CampaignMultiSelect
                campaigns={availableCampaigns}
                selectedCampaigns={formData.selectedCampaigns}
                selectionMode={formData.campaignSelectionMode}
                onSelectedCampaignsChange={(campaigns) =>
                  setFormData({ ...formData, selectedCampaigns: campaigns })
                }
                onSelectionModeChange={(mode) =>
                  setFormData({ ...formData, campaignSelectionMode: mode, campaignFilters: mode !== 'all' ? [] : formData.campaignFilters })
                }
                isLoading={campaignsLoading}
              />
            )}

            {/* Campaign Pre-Filters */}
            {formData.accountIds.length > 0 && formData.campaignSelectionMode === 'all' && (
              <>
                <CampaignFilterBuilder
                  filters={formData.campaignFilters}
                  filtersLogic={formData.campaignFiltersLogic}
                  onFiltersChange={(filters) => setFormData({ ...formData, campaignFilters: filters })}
                  onFiltersLogicChange={(logic) => setFormData({ ...formData, campaignFiltersLogic: logic })}
                />
                {formData.accountIds.length > 1 && formData.campaignFilters.length > 0 && (
                  <p className="text-xs text-muted-foreground -mt-2">
                    {language === 'de' 
                      ? 'Pre-Filter werden auf alle ausgewählten Accounts angewendet.'
                      : 'Pre-filters are applied to all selected accounts.'}
                  </p>
                )}
              </>
            )}

            <div className="space-y-3">
              <Label className="text-sm font-medium">{t.campaignTypes} *</Label>
              <ToggleGroup 
                type="multiple" 
                value={formData.campaignTypes}
                onValueChange={(value) => {
                  if (value.length > 0) {
                    setFormData({ ...formData, campaignTypes: value })
                  }
                }}
                className="justify-start flex-wrap gap-2"
              >
                <ToggleGroupItem 
                  value="sp" 
                  aria-label={t.sponsoredProducts}
                  variant="outline"
                  className="gap-2 border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
                >
                  <Package className="h-4 w-4" />
                  {t.sponsoredProducts}
                </ToggleGroupItem>
                <ToggleGroupItem 
                  value="sb" 
                  aria-label={t.sponsoredBrands}
                  variant="outline"
                  className="gap-2 border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
                >
                  <Store className="h-4 w-4" />
                  {t.sponsoredBrands}
                </ToggleGroupItem>
                <ToggleGroupItem 
                  value="sd" 
                  aria-label={t.sponsoredDisplay}
                  variant="outline"
                  className="gap-2 border-2 data-[state=on]:bg-primary data-[state=on]:text-primary-foreground data-[state=on]:border-primary"
                >
                  <Monitor className="h-4 w-4" />
                  {t.sponsoredDisplay}
                </ToggleGroupItem>
              </ToggleGroup>
              <p className="text-xs text-muted-foreground">
                {t.atLeastOneCampaignType}
              </p>
            </div>

            {/* Alert Conditions */}
            <AlertConditionBuilder
              conditions={formData.alertConditions}
              conditionsLogic={formData.alertConditionsLogic}
              onConditionsChange={(conditions) => setFormData({ ...formData, alertConditions: conditions })}
              onConditionsLogicChange={(logic) => setFormData({ ...formData, alertConditionsLogic: logic })}
            />
          </div>
        )}

        {/* Step 2 */}
        {step === 2 && (
          <div className="space-y-4">
            <Card className="bg-blue-50 dark:bg-blue-950 border-blue-200 dark:border-blue-800">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">{t.automaticCheck}</h4>
                <p className="text-sm text-muted-foreground">
                  {t.automaticCheckDesc}
                </p>
                <ul className="text-sm text-muted-foreground mt-2 space-y-1 ml-4">
                  <li>• {t.morning}: <strong>{language === 'de' ? '11:00 Uhr' : '11:00 AM'}</strong></li>
                  <li>• {t.evening}: <strong>{language === 'de' ? '17:00 Uhr' : '5:00 PM'}</strong></li>
                </ul>
              </CardContent>
            </Card>
            
            <div>
              <Label>{t.checkTime} *</Label>
              <RadioGroup
                value={formData.checkSchedule}
                onValueChange={(v) => setFormData({ ...formData, checkSchedule: v })}
                className="mt-2 space-y-2"
              >
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="morning" id="morning" />
                  <Label htmlFor="morning" className="cursor-pointer font-normal">
                    {t.onlyMorning}
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="evening" id="evening" />
                  <Label htmlFor="evening" className="cursor-pointer font-normal">
                    {t.onlyEvening}
                  </Label>
                </div>
                <div className="flex items-center space-x-2">
                  <RadioGroupItem value="both" id="both" />
                  <Label htmlFor="both" className="cursor-pointer font-normal">
                    {t.twiceDaily}
                  </Label>
                </div>
              </RadioGroup>
              <p className="text-xs text-muted-foreground mt-2">
                {t.tipHighBudget}
              </p>
            </div>
            
            <div>
              <Label>{t.notificationChannels}</Label>
              <div className="space-y-2 mt-2">
                <div className="flex items-center gap-2">
                  <Checkbox
                    id="slack"
                    checked={formData.slackEnabled}
                    onCheckedChange={(checked) => setFormData({ ...formData, slackEnabled: !!checked })}
                  />
                  <Label htmlFor="slack" className="cursor-pointer">Slack</Label>
                </div>
              </div>
            </div>
            
            <Card className="bg-muted/50">
              <CardContent className="p-4">
                <h4 className="font-medium mb-2">{t.summary}</h4>
                <div className="text-sm space-y-1 text-muted-foreground">
                  <p><strong>{t.rule}:</strong> {formData.ruleName}</p>
                  <p><strong>{t.accounts}:</strong> {selectedAccountNames.length > 2 
                    ? `${selectedAccountNames.slice(0, 2).join(', ')} +${selectedAccountNames.length - 2}` 
                    : selectedAccountNames.join(', ')}</p>
                  <p><strong>{t.campaignTypes}:</strong> {formData.campaignTypes.map(ct => ct.toUpperCase()).join(', ')}</p>
                  <p><strong>{t.campaignSelection}:</strong> {
                    formData.campaignSelectionMode === 'include' 
                      ? (formData.selectedCampaigns.length === availableCampaigns.length 
                          ? t.allCampaigns 
                          : `${formData.selectedCampaigns.length} ${t.campaignsIncluded}`)
                      : formData.campaignSelectionMode === 'exclude'
                        ? `${formData.selectedCampaigns.length} ${t.campaignsExcluded}`
                        : t.allCampaigns
                  }</p>
                  <div>
                    <strong>{t.conditions}:</strong>
                    <ul className="ml-4 mt-1 space-y-0.5">
                      {formData.alertConditions.map((condition, idx) => {
                        const metricConfig = metrics.find(m => m.id === condition.metric_name);
                        const isAbsolute = condition.threshold_type === 'absolute' || (metricConfig && !metricConfig.allowsPercentage);
                        const periodName = comparisonPeriods.find(p => p.id === condition.comparison_period)?.name;
                        
                        let conditionText = "";
                        if (isAbsolute) {
                          conditionText = `${metricConfig?.name || condition.metric_name} ${condition.alert_direction === 'increases' ? '>' : '<'} ${condition.threshold_value} ${metricConfig?.unit || ''}`;
                        } else {
                          const dirText = condition.alert_direction === 'increases' ? t.increases : condition.alert_direction === 'decreases' ? t.decreases : t.both;
                          conditionText = `${metricConfig?.name || condition.metric_name} ${dirText} ${language === 'de' ? 'um' : 'by'} >${condition.threshold_value}% vs. ${periodName}`;
                        }
                        
                        return (
                          <li key={condition.id || idx}>
                            {idx > 0 && <span className="text-primary font-medium">{formData.alertConditionsLogic} </span>}
                            {conditionText}
                          </li>
                        );
                      })}
                    </ul>
                  </div>
                  <p><strong>{t.checkTime}:</strong> {
                    formData.checkSchedule === 'morning' ? t.onlyMorning :
                    formData.checkSchedule === 'evening' ? t.onlyEvening :
                    t.twiceDaily
                  }</p>
                </div>
              </CardContent>
            </Card>
          </div>
        )}

        {/* Footer Buttons */}
        <div className="flex justify-between pt-4 border-t">
          <Button variant="outline" onClick={step === 1 ? onClose : handleBack}>
            {step === 1 ? t.cancel : t.back}
          </Button>
          <Button onClick={step === 2 ? handleSubmit : handleNext} disabled={!canProceed()}>
            {step === 2 ? t.saveRule : t.next}
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { Dialog, DialogContent, DialogHeader, DialogTitle } from "@/components/ui/dialog";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Download, Send } from "lucide-react";
import { format } from "date-fns";
import { DeviationIndicator } from "./DeviationIndicator";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskAccountName, maskCampaignName, maskRuleName } from "@/lib/demoMode";

interface AlertDetailsModalProps {
  alert: any;
  open: boolean;
  onClose: () => void;
}

export function AlertDetailsModal({ alert, open, onClose }: AlertDetailsModalProps) {
  const { isDemoMode } = useDemoMode();
  const alertItems = alert.alert_items || [];
  
  // Calculate summary metrics
  const totalDeviation = alertItems.reduce((sum: number, item: any) => 
    sum + Math.abs(item.deviation_percent), 0
  ) / (alertItems.length || 1);
  
  const biggestDrop = alertItems.reduce((max: any, item: any) => 
    !max || Math.abs(item.deviation_percent) > Math.abs(max.deviation_percent) ? item : max
  , null);

  return (
    <Dialog open={open} onOpenChange={onClose}>
      <DialogContent className="max-w-4xl max-h-[90vh] overflow-y-auto">
        <DialogHeader>
          <DialogTitle>
            Alert for {isDemoMode 
              ? maskAccountName(alert.amazon_accounts?.account_name)
              : (alert.amazon_accounts?.account_name || "Unknown Account")}
          </DialogTitle>
          <p className="text-sm text-muted-foreground">
            Triggered: {format(new Date(alert.created_at), "MMM d, yyyy 'at' h:mm a")}
          </p>
          {alert.alert_rules && (
            <p className="text-sm text-muted-foreground">
              Rule: {isDemoMode 
                ? maskRuleName(alert.alert_rules.rule_name)
                : alert.alert_rules.rule_name}
            </p>
          )}
        </DialogHeader>

        {/* Summary Cards */}
        <div className="grid grid-cols-3 gap-4">
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground mb-1">Total Deviation</p>
              <p className="text-2xl font-bold text-danger">
                {totalDeviation.toFixed(1)}%
              </p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground mb-1">Campaigns Affected</p>
              <p className="text-2xl font-bold">{alertItems.length}</p>
            </CardContent>
          </Card>
          <Card>
            <CardContent className="p-4 text-center">
              <p className="text-sm text-muted-foreground mb-1">Biggest Drop</p>
              <p className="text-2xl font-bold text-danger">
                {biggestDrop ? `${biggestDrop.deviation_percent.toFixed(1)}%` : "N/A"}
              </p>
            </CardContent>
          </Card>
        </div>

        {/* Affected Campaigns Table */}
        <div>
          <h3 className="font-semibold mb-3">Affected Campaigns</h3>
          <div className="border rounded-lg overflow-hidden">
            <table className="w-full">
              <thead className="bg-muted">
                <tr>
                  <th className="p-3 text-left text-sm font-medium">Campaign</th>
                  <th className="p-3 text-left text-sm font-medium">Metric</th>
                  <th className="p-3 text-right text-sm font-medium">Current</th>
                  <th className="p-3 text-right text-sm font-medium">Previous</th>
                  <th className="p-3 text-right text-sm font-medium">Change</th>
                  <th className="p-3 text-left text-sm font-medium">Deviation</th>
                </tr>
              </thead>
              <tbody>
                {alertItems.map((item: any, index: number) => (
                  <tr key={item.id} className={index % 2 === 0 ? "bg-background" : "bg-muted/30"}>
                    <td className="p-3 text-sm font-medium">
                      {isDemoMode 
                        ? maskCampaignName(item.campaign_name || item.external_campaign_id)
                        : (item.campaign_name || item.external_campaign_id || "Unknown")}
                    </td>
                    <td className="p-3 text-sm capitalize">{item.metric_name}</td>
                    <td className="p-3 text-sm text-right">{item.current_value.toFixed(2)}</td>
                    <td className="p-3 text-sm text-right">{item.reference_value.toFixed(2)}</td>
                    <td className="p-3 text-sm text-right">
                      {(item.current_value - item.reference_value).toFixed(2)}
                    </td>
                    <td className="p-3">
                      <DeviationIndicator 
                        value={item.deviation_percent} 
                        threshold={item.threshold_percent} 
                      />
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>

        {/* Actions */}
        <div className="flex gap-2 pt-4 border-t">
          <Button variant="outline" className="flex-1">
            <Download className="h-4 w-4 mr-2" />
            Export to CSV
          </Button>
          <Button variant="outline" className="flex-1">
            <Send className="h-4 w-4 mr-2" />
            Send to Slack
          </Button>
        </div>
      </DialogContent>
    </Dialog>
  );
}

import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import { Loader2, Copy, ChevronDown, Search, X } from "lucide-react";
import { Badge } from "@/components/ui/badge";
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskAccountName } from "@/lib/demoMode";
import { useLanguage } from "@/contexts/LanguageContext";

interface Account {
  id: string;
  account_name: string;
}

interface DuplicateRuleDialogProps {
  rule: any;
  accounts: Account[];
  open: boolean;
  onClose: () => void;
  onDuplicate: (ruleName: string, accountIds: string[]) => Promise<void>;
}

export function DuplicateRuleDialog({
  rule,
  accounts,
  open,
  onClose,
  onDuplicate,
}: DuplicateRuleDialogProps) {
  const [ruleName, setRuleName] = useState("");
  const [selectedAccountIds, setSelectedAccountIds] = useState<string[]>([]);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [accountDropdownOpen, setAccountDropdownOpen] = useState(false);
  const [searchQuery, setSearchQuery] = useState("");
  const { isDemoMode } = useDemoMode();
  const { t, language } = useLanguage();

  // Initialize state when dialog opens
  useEffect(() => {
    if (open && rule) {
      const copySuffix = language === 'de' ? '(Kopie)' : '(Copy)';
      setRuleName(`${rule.rule_name} ${copySuffix}`);
      const originalAccountIds = rule.account_ids || (rule.account_id ? [rule.account_id] : []);
      setSelectedAccountIds(originalAccountIds);
      setSearchQuery("");
    }
  }, [open, rule, language]);

  const handleAccountToggle = (accountId: string) => {
    setSelectedAccountIds(prev =>
      prev.includes(accountId)
        ? prev.filter(id => id !== accountId)
        : [...prev, accountId]
    );
  };

  const handleSelectAll = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedAccountIds(accounts.map(a => a.id));
  };

  const handleSelectNone = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    setSelectedAccountIds([]);
  };

  const handleSelectOthers = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    const originalAccountIds = rule?.account_ids || (rule?.account_id ? [rule.account_id] : []);
    setSelectedAccountIds(accounts.filter(a => !originalAccountIds.includes(a.id)).map(a => a.id));
  };

  const handleSubmit = async () => {
    if (!ruleName.trim() || selectedAccountIds.length === 0) return;
    
    setIsSubmitting(true);
    try {
      await onDuplicate(ruleName.trim(), selectedAccountIds);
      onClose();
    } finally {
      setIsSubmitting(false);
    }
  };

  const removeAccount = (accountId: string) => {
    setSelectedAccountIds(prev => prev.filter(id => id !== accountId));
  };

  const originalAccountIds = rule?.account_ids || (rule?.account_id ? [rule?.account_id] : []);
  
  const filteredAccounts = accounts.filter(account =>
    account.account_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const selectedAccounts = accounts.filter(a => selectedAccountIds.includes(a.id));

  return (
    <Dialog open={open} onOpenChange={(isOpen) => !isOpen && onClose()}>
      <DialogContent className="sm:max-w-[500px]">
        <DialogHeader>
          <DialogTitle className="flex items-center gap-2">
            <Copy className="h-5 w-5" />
            {t.duplicateRule}
          </DialogTitle>
          <DialogDescription>{t.duplicateRuleDesc}</DialogDescription>
        </DialogHeader>

        <div className="space-y-6 py-4">
          {/* Rule Name */}
          <div className="space-y-2">
            <Label htmlFor="ruleName">{t.ruleName}</Label>
            <Input
              id="ruleName"
              value={ruleName}
              onChange={(e) => setRuleName(e.target.value)}
              placeholder={language === 'de' ? "Name der duplizierten Regel" : "Name of duplicated rule"}
            />
          </div>

          {/* Account Selection Dropdown */}
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <Label>{t.targetAccounts}</Label>
              <div className="flex gap-1">
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={handleSelectAll}
                  className="h-6 text-xs px-2"
                >
                  {t.all}
                </Button>
                <Button
                  type="button"
                  variant="ghost"
                  size="sm"
                  onClick={handleSelectNone}
                  className="h-6 text-xs px-2"
                >
                  {t.none}
                </Button>
                {accounts.length > 1 && (
                  <Button
                    type="button"
                    variant="ghost"
                    size="sm"
                    onClick={handleSelectOthers}
                    className="h-6 text-xs px-2"
                  >
                    {t.others}
                  </Button>
                )}
              </div>
            </div>

            <Popover open={accountDropdownOpen} onOpenChange={setAccountDropdownOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  role="combobox"
                  aria-expanded={accountDropdownOpen}
                  className="w-full justify-between h-auto min-h-10 py-2"
                >
                  <span className="text-muted-foreground">
                    {selectedAccountIds.length === 0
                      ? t.selectAccountsDropdown
                      : `${selectedAccountIds.length} ${selectedAccountIds.length > 1 ? t.accountsSelectedPlural : t.accountSelected}`}
                  </span>
                  <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-[--radix-popover-trigger-width] p-0 z-50 bg-popover" align="start">
                <div className="p-2 border-b">
                  <div className="relative">
                    <Search className="absolute left-2.5 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder={t.searchAccount}
                      value={searchQuery}
                      onChange={(e) => setSearchQuery(e.target.value)}
                      className="pl-8 h-8"
                    />
                  </div>
                </div>
                <div className="max-h-[280px] overflow-y-auto">
                  {filteredAccounts.length === 0 ? (
                    <div className="p-4 text-center text-sm text-muted-foreground">
                      {t.noAccountsFound}
                    </div>
                  ) : (
                    filteredAccounts.map((account) => {
                      const isOriginal = originalAccountIds.includes(account.id);
                      const isSelected = selectedAccountIds.includes(account.id);
                      return (
                        <div
                          key={account.id}
                          className="flex items-center gap-3 px-3 py-2 hover:bg-muted/50 cursor-pointer"
                          onClick={() => handleAccountToggle(account.id)}
                        >
                          <Checkbox
                            checked={isSelected}
                            onCheckedChange={() => handleAccountToggle(account.id)}
                          />
                          <span className="flex-1 text-sm">
                            {isDemoMode ? maskAccountName(account.account_name) : account.account_name}
                          </span>
                          {isOriginal && (
                            <span className="text-xs text-muted-foreground bg-muted px-1.5 py-0.5 rounded">
                              {t.original}
                            </span>
                          )}
                        </div>
                      );
                    })
                  )}
                </div>
              </PopoverContent>
            </Popover>

            {/* Selected accounts as badges */}
            {selectedAccounts.length > 0 && (
              <div className="flex flex-wrap gap-1.5">
                {selectedAccounts.map((account) => (
                  <Badge
                    key={account.id}
                    variant="secondary"
                    className="gap-1 pr-1"
                  >
                    {isDemoMode ? maskAccountName(account.account_name) : account.account_name}
                    <button
                      type="button"
                      onClick={() => removeAccount(account.id)}
                      className="ml-1 rounded-full hover:bg-muted p-0.5"
                    >
                      <X className="h-3 w-3" />
                    </button>
                  </Badge>
                ))}
              </div>
            )}

            {selectedAccountIds.length === 0 && (
              <p className="text-sm text-destructive">{t.selectAtLeastOneAccount}</p>
            )}
          </div>
        </div>

        <DialogFooter>
          <Button variant="outline" onClick={onClose} disabled={isSubmitting}>
            {t.cancel}
          </Button>
          <Button
            onClick={handleSubmit}
            disabled={isSubmitting || !ruleName.trim() || selectedAccountIds.length === 0}
          >
            {isSubmitting ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {t.duplicating}
              </>
            ) : (
              <>
                <Copy className="h-4 w-4 mr-2" />
                {t.duplicate}
              </>
            )}
          </Button>
        </DialogFooter>
      </DialogContent>
    </Dialog>
  );
}

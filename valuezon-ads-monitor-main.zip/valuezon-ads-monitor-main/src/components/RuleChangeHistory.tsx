import { useRuleChanges, RuleChange } from "@/hooks/useRuleChanges";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { format } from "date-fns";
import { de } from "date-fns/locale";
import { FileEdit, Plus, Trash2, User, ChevronDown, ChevronRight } from "lucide-react";
import { useState } from "react";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskRuleName, maskEmail } from "@/lib/demoMode";

interface RuleChangeHistoryProps {
  ruleId?: string;
  maxHeight?: string;
}

const changeTypeConfig = {
  created: {
    label: "Erstellt",
    icon: Plus,
    variant: "default" as const,
    className: "bg-success/10 text-success border-success/30",
  },
  updated: {
    label: "Bearbeitet",
    icon: FileEdit,
    variant: "secondary" as const,
    className: "bg-warning/10 text-warning border-warning/30",
  },
  deleted: {
    label: "Gelöscht",
    icon: Trash2,
    variant: "destructive" as const,
    className: "bg-destructive/10 text-destructive border-destructive/30",
  },
};

const fieldLabels: Record<string, string> = {
  rule_name: "Regelname",
  metric_name: "Metrik",
  threshold_percent: "Schwellenwert",
  threshold_type: "Schwellenwert-Typ",
  comparison_period: "Vergleichszeitraum",
  alert_direction: "Richtung",
  check_schedule: "Prüfzeitpunkt",
  check_frequency: "Prüfhäufigkeit",
  is_active: "Status",
  campaign_types: "Kampagnentypen",
  campaign_selection_mode: "Kampagnenauswahl-Modus",
  selected_campaigns: "Ausgewählte Kampagnen",
  account_ids: "Accounts",
  account_id: "Account",
  last_edited_by: "Bearbeitet von",
  last_edited_at: "Bearbeitet am",
  created_by: "Erstellt von",
};

const directionLabels: Record<string, string> = {
  increases: "Nur Anstiege",
  decreases: "Nur Rückgänge", 
  both: "Beides",
};

const scheduleLabels: Record<string, string> = {
  morning: "Morgens (11:00)",
  evening: "Abends (17:00)",
  both: "2x täglich",
};

const selectionModeLabels: Record<string, string> = {
  all: "Alle Kampagnen",
  include: "Nur ausgewählte",
  exclude: "Alle außer ausgewählte",
};

function formatValue(key: string, value: any): string {
  if (value === null || value === undefined) return "-";
  if (typeof value === "boolean") return value ? "Aktiv" : "Inaktiv";
  
  // Special formatting for known fields
  if (key === "alert_direction" && directionLabels[value]) {
    return directionLabels[value];
  }
  if (key === "check_schedule" && scheduleLabels[value]) {
    return scheduleLabels[value];
  }
  if (key === "campaign_selection_mode" && selectionModeLabels[value]) {
    return selectionModeLabels[value];
  }
  if (key === "threshold_percent") return `${value}%`;
  if (key === "threshold_type") return value === "absolute" ? "Absolut" : "Prozentual";
  
  // Special formatting for alert_conditions (array of condition objects)
  if (key === "alert_conditions" && Array.isArray(value)) {
    if (value.length === 0) return "-";
    return value.map((condition: any) => {
      const metric = condition.metric_name || "?";
      const threshold = condition.threshold_percent ?? "?";
      const direction = directionLabels[condition.alert_direction] || condition.alert_direction || "?";
      return `${metric} ${threshold}% (${direction})`;
    }).join(", ");
  }

  // Special formatting for campaign_filters (array of filter objects)
  if (key === "campaign_filters" && Array.isArray(value)) {
    if (value.length === 0) return "-";
    return value.map((filter: any) => {
      const field = filter.field || "?";
      const operator = filter.operator || "?";
      const filterValue = filter.value || "?";
      return `${field} ${operator} "${filterValue}"`;
    }).join(", ");
  }
  
  if (Array.isArray(value)) {
    if (value.length === 0) return "-";
    if (key === "campaign_types") {
      return value.map(v => v.toUpperCase()).join(", ");
    }
    // Check if array contains objects
    if (value.length > 0 && typeof value[0] === "object") {
      return `${value.length} Einträge`;
    }
    if (value.length > 3) return `${value.slice(0, 3).join(", ")} (+${value.length - 3} weitere)`;
    return value.join(", ");
  }

  // Fallback for other objects
  if (typeof value === "object") {
    try {
      return JSON.stringify(value);
    } catch {
      return "[Komplexer Wert]";
    }
  }
  
  return String(value);
}

// Fields to skip in display (internal fields)
const skipFields = ["last_edited_by", "last_edited_at", "created_by", "updated_at", "created_at"];

function ChangeDetails({ change }: { change: RuleChange }) {
  const hasChanges = change.changes && Object.keys(change.changes).length > 0;
  const hasNewValues = change.new_values && Object.keys(change.new_values).length > 0;
  
  if (!hasChanges && !hasNewValues) {
    return null;
  }

  // For updates, show the diff
  if (change.change_type === "updated" && hasChanges) {
    const filteredChanges = Object.entries(change.changes!).filter(
      ([key]) => !skipFields.includes(key)
    );
    
    if (filteredChanges.length === 0) return null;

    return (
      <div className="mt-3 bg-muted/30 rounded-lg p-3 space-y-2">
        <div className="text-xs font-medium text-muted-foreground mb-2">Änderungen:</div>
        {filteredChanges.map(([key, diff]: [string, any]) => (
          <div key={key} className="flex flex-col sm:flex-row sm:items-center gap-1 sm:gap-3 text-sm border-l-2 border-muted-foreground/20 pl-3">
            <span className="font-medium text-foreground min-w-[140px]">
              {fieldLabels[key] || key}
            </span>
            <div className="flex items-center gap-2 flex-wrap">
              <span className="bg-destructive/10 text-destructive px-2 py-0.5 rounded text-xs line-through">
                {formatValue(key, diff.from)}
              </span>
              <span className="text-muted-foreground">→</span>
              <span className="bg-success/10 text-success px-2 py-0.5 rounded text-xs font-medium">
                {formatValue(key, diff.to)}
              </span>
            </div>
          </div>
        ))}
      </div>
    );
  }

  // For created, show the initial values
  if (change.change_type === "created" && hasNewValues) {
    const filteredValues = Object.entries(change.new_values!).filter(
      ([key]) => !skipFields.includes(key) && change.new_values![key] !== null
    );
    
    if (filteredValues.length === 0) return null;

    return (
      <div className="mt-3 bg-muted/30 rounded-lg p-3">
        <div className="text-xs font-medium text-muted-foreground mb-2">Initiale Werte:</div>
        <div className="grid grid-cols-1 sm:grid-cols-2 gap-2">
          {filteredValues.slice(0, 8).map(([key, value]) => (
            <div key={key} className="flex items-center gap-2 text-sm">
              <span className="text-muted-foreground min-w-[100px]">
                {fieldLabels[key] || key}:
              </span>
              <span className="font-medium text-foreground">
                {formatValue(key, value)}
              </span>
            </div>
          ))}
        </div>
        {filteredValues.length > 8 && (
          <div className="text-xs text-muted-foreground mt-2">
            +{filteredValues.length - 8} weitere Felder
          </div>
        )}
      </div>
    );
  }

  return null;
}

function ChangeItem({ change }: { change: RuleChange }) {
  const [isOpen, setIsOpen] = useState(false);
  const { isDemoMode } = useDemoMode();
  const config = changeTypeConfig[change.change_type];
  const Icon = config.icon;
  
  const hasDetails = (change.change_type === "updated" && change.changes && Object.keys(change.changes).filter(k => !skipFields.includes(k)).length > 0) ||
                     (change.change_type === "created" && change.new_values && Object.keys(change.new_values).filter(k => !skipFields.includes(k)).length > 0);

  return (
    <Collapsible open={isOpen} onOpenChange={setIsOpen}>
      <div className="p-4 hover:bg-muted/50">
        <CollapsibleTrigger className="w-full text-left">
          <div className="flex items-start justify-between gap-4">
            <div className="flex-1 min-w-0">
              <div className="flex items-center gap-2 flex-wrap">
                <Badge variant={config.variant} className={config.className}>
                  <Icon className="h-3 w-3 mr-1" />
                  {config.label}
                </Badge>
                <span className="font-medium truncate">
                  {isDemoMode ? maskRuleName(change.rule_name) : change.rule_name}
                </span>
                {hasDetails && (
                  <span className="text-muted-foreground">
                    {isOpen ? (
                      <ChevronDown className="h-4 w-4" />
                    ) : (
                      <ChevronRight className="h-4 w-4" />
                    )}
                  </span>
                )}
              </div>
              
              <div className="flex items-center gap-2 mt-2 text-sm text-muted-foreground">
                <User className="h-3 w-3" />
                <span>{isDemoMode ? maskEmail(change.changed_by_email) : (change.changed_by_email || "Unbekannt")}</span>
                <span>•</span>
                <span>
                  {format(new Date(change.changed_at), "dd. MMM yyyy, HH:mm", {
                    locale: de,
                  })}
                </span>
              </div>
            </div>
          </div>
        </CollapsibleTrigger>
        
        <CollapsibleContent>
          <ChangeDetails change={change} />
        </CollapsibleContent>
      </div>
    </Collapsible>
  );
}

export function RuleChangeHistory({ ruleId, maxHeight = "400px" }: RuleChangeHistoryProps) {
  const { changes, isLoading } = useRuleChanges(ruleId);

  if (isLoading) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Änderungshistorie</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            Wird geladen...
          </div>
        </CardContent>
      </Card>
    );
  }

  if (changes.length === 0) {
    return (
      <Card>
        <CardHeader>
          <CardTitle className="text-lg">Änderungshistorie</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="text-center py-8 text-muted-foreground">
            Noch keine Änderungen protokolliert
          </div>
        </CardContent>
      </Card>
    );
  }

  return (
    <Card>
      <CardHeader className="pb-2">
        <CardTitle className="text-lg flex items-center justify-between">
          Änderungshistorie
          <span className="text-sm font-normal text-muted-foreground">
            {changes.length} {changes.length === 1 ? "Eintrag" : "Einträge"}
          </span>
        </CardTitle>
      </CardHeader>
      <CardContent className="p-0">
        <ScrollArea style={{ maxHeight }}>
          <div className="divide-y">
            {changes.map((change) => (
              <ChangeItem key={change.id} change={change} />
            ))}
          </div>
        </ScrollArea>
      </CardContent>
    </Card>
  );
}

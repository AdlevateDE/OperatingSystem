import { Outlet, useLocation, useNavigate } from "react-router-dom";
import { NavLink } from "@/components/NavLink";
import { Home, Bell, Settings, Activity, RefreshCw, LogOut, PanelLeftClose, PanelLeft, Eye, EyeOff, Globe, FileBarChart } from "lucide-react";
import { Button } from "@/components/ui/button";
import { useAccounts } from "@/hooks/useAccounts";
import { formatDistanceToNow } from "date-fns";
import { de, enUS } from "date-fns/locale";
import { useEffect, useState, useMemo, memo } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { cn } from "@/lib/utils";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { maskEmail } from "@/lib/demoMode";
import { Badge } from "@/components/ui/badge";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

// Memoized Outlet to prevent child re-renders when sidebar toggles
const MemoizedOutlet = memo(Outlet);

export default function Layout() {
  const location = useLocation();
  const navigate = useNavigate();
  const { toast } = useToast();
  const { refetch, lastSync } = useAccounts();
  const [user, setUser] = useState<any>(null);
  const [loading, setLoading] = useState(true);
  const [sidebarCollapsed, setSidebarCollapsed] = useState(false);
  const { isDemoMode, toggleDemoMode } = useDemoMode();
  const { language, setLanguage, t } = useLanguage();

  // Memoize navigation items to prevent recreation on every render
  const navigationItems = useMemo(() => [
    { name: t.dashboard, href: "/", icon: Home },
    { name: t.alertRules, href: "/rules", icon: Bell },
    { name: language === 'de' ? 'Report-Status' : 'Report Status', href: "/status", icon: FileBarChart },
    { name: t.settings, href: "/settings", icon: Settings },
  ], [t, language]);

  // Memoize page titles
  const pageTitle = useMemo<Record<string, string>>(() => ({
    "/": t.dashboard,
    "/rules": t.alertRules,
    "/status": language === 'de' ? 'Report-Status' : 'Report Status',
    "/settings": t.settings,
  }), [t, language]);

  useEffect(() => {
    const { data: { subscription } } = supabase.auth.onAuthStateChange(
      (event, session) => {
        setUser(session?.user ?? null);
        setLoading(false);
        
        if (!session?.user) {
          navigate('/auth');
        }
      }
    );

    supabase.auth.getSession().then(({ data: { session } }) => {
      setUser(session?.user ?? null);
      setLoading(false);
      
      if (!session?.user) {
        navigate('/auth');
      }
    });

    return () => subscription.unsubscribe();
  }, [navigate]);

  const handleRefresh = () => {
    refetch();
  };

  const handleLogout = async () => {
    try {
      await supabase.auth.signOut();
      toast({
        title: t.loggedOut,
        description: t.loggedOutDesc,
      });
      navigate('/auth');
    } catch (error: any) {
      toast({
        title: t.logoutError,
        description: error.message,
        variant: "destructive",
      });
    }
  };

  if (loading) {
    return (
      <div className="flex h-screen w-full items-center justify-center bg-background">
        <div className="text-lg text-muted-foreground">{t.loading}</div>
      </div>
    );
  }

  if (!user) {
    return null;
  }

  return (
    <div className="flex h-screen w-full bg-background">
      {/* Sidebar */}
      <aside 
        className={cn(
          "bg-card border-r border-border flex flex-col transition-[width] duration-200 ease-out will-change-[width]",
          sidebarCollapsed ? "w-16" : "w-64"
        )}
      >
        {/* Logo */}
        <div className="h-16 flex items-center px-4 border-b border-border">
          <Activity className="h-6 w-6 text-primary flex-shrink-0" />
          {!sidebarCollapsed && !isDemoMode && (
            <h1 className="text-xl font-semibold ml-3 text-foreground">Valuezon</h1>
          )}
          {!sidebarCollapsed && isDemoMode && (
            <h1 className="text-xl font-semibold ml-3 text-foreground">Ad Alerts</h1>
          )}
        </div>

        {/* Navigation */}
        <nav className="flex-1 px-3 py-4 space-y-1">
          {navigationItems.map((item) => (
            <NavLink
              key={item.href}
              to={item.href}
              end={item.href === "/"}
              className={cn(
                "flex items-center rounded-lg text-muted-foreground hover:bg-accent hover:text-foreground transition-colors",
                sidebarCollapsed ? "px-3 py-2.5 justify-center" : "px-3 py-2.5"
              )}
              activeClassName="bg-sidebar-accent text-sidebar-accent-foreground font-medium"
            >
              <item.icon className={cn("h-5 w-5 flex-shrink-0", !sidebarCollapsed && "mr-3")} />
              {!sidebarCollapsed && <span>{item.name}</span>}
            </NavLink>
          ))}
        </nav>

        {/* User Section */}
        <div className="p-3 border-t border-border">
          {user && (
            <div className="space-y-2">
              {!sidebarCollapsed && (
                <div className="text-xs text-muted-foreground px-2 truncate">
                  {isDemoMode ? maskEmail(user.email) : user.email}
                </div>
              )}
              <Button 
                variant="ghost" 
                size="sm" 
                className={cn(
                  "text-muted-foreground hover:bg-accent hover:text-foreground",
                  sidebarCollapsed ? "w-full justify-center px-2" : "w-full justify-start"
                )}
                onClick={handleLogout}
                title={sidebarCollapsed ? t.logout : undefined}
              >
                <LogOut className={cn("h-4 w-4", !sidebarCollapsed && "mr-2")} />
                {!sidebarCollapsed && t.logout}
              </Button>
            </div>
          )}
        </div>

        {/* Demo Mode Toggle */}
        <div className="p-3 border-t border-border">
          <Button
            variant={isDemoMode ? "default" : "ghost"}
            size="sm"
            className={cn(
              isDemoMode 
                ? "w-full bg-amber-500 hover:bg-amber-600 text-white" 
                : "text-muted-foreground hover:bg-accent hover:text-foreground",
              sidebarCollapsed ? "justify-center px-2" : "justify-start"
            )}
            onClick={toggleDemoMode}
            title={sidebarCollapsed ? (isDemoMode ? t.demoOff : t.demoMode) : undefined}
          >
            {isDemoMode ? (
              <>
                <EyeOff className={cn("h-4 w-4", !sidebarCollapsed && "mr-2")} />
                {!sidebarCollapsed && t.demoOff}
              </>
            ) : (
              <>
                <Eye className={cn("h-4 w-4", !sidebarCollapsed && "mr-2")} />
                {!sidebarCollapsed && t.demoMode}
              </>
            )}
          </Button>
        </div>

        {/* Collapse Toggle */}
        <div className="p-3 border-t border-border">
          <Button
            variant="ghost"
            size="sm"
            className={cn(
              "text-muted-foreground hover:bg-accent hover:text-foreground",
              sidebarCollapsed ? "w-full justify-center px-2" : "w-full justify-start"
            )}
            onClick={() => setSidebarCollapsed(!sidebarCollapsed)}
          >
            {sidebarCollapsed ? (
              <PanelLeft className="h-4 w-4" />
            ) : (
              <>
                <PanelLeftClose className="h-4 w-4 mr-2" />
                {t.collapse}
              </>
            )}
          </Button>
        </div>
      </aside>

      {/* Main Content */}
      <div className="flex-1 flex flex-col overflow-hidden">
        {/* Header */}
        <header className="h-16 bg-card border-b border-border flex items-center justify-between px-6">
          <div className="flex items-center gap-3">
            <h2 className="text-xl font-semibold text-foreground">
              {pageTitle[location.pathname] || t.dashboard}
            </h2>
            {isDemoMode && (
              <Badge variant="outline" className="bg-amber-500/10 text-amber-600 border-amber-500/30">
                {t.demo}
              </Badge>
            )}
          </div>
          <div className="flex items-center gap-4">
            {lastSync && (
              <span className="text-sm text-muted-foreground">
                {t.lastSync}: {formatDistanceToNow(new Date(lastSync), { 
                  addSuffix: true,
                  locale: language === 'de' ? de : enUS 
                })}
              </span>
            )}
            
            {/* Language Dropdown */}
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="outline" size="sm" className="border-border gap-2">
                  <Globe className="h-4 w-4" />
                  {language === 'de' ? 'DE' : 'EN'}
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="bg-popover">
                <DropdownMenuItem 
                  onClick={() => setLanguage('de')}
                  className={cn(language === 'de' && "bg-accent")}
                >
                  🇩🇪 {t.german}
                </DropdownMenuItem>
                <DropdownMenuItem 
                  onClick={() => setLanguage('en')}
                  className={cn(language === 'en' && "bg-accent")}
                >
                  🇬🇧 {t.english}
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
            
            <Button variant="outline" size="sm" onClick={handleRefresh} className="border-border">
              <RefreshCw className="h-4 w-4" />
            </Button>
          </div>
        </header>

        {/* Page Content */}
        <main className="flex-1 overflow-auto p-6">
          <MemoizedOutlet />
        </main>
      </div>
    </div>
  );
}

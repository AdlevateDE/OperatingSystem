import { useState, useMemo, useRef, useCallback, memo } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { Download, ArrowUpDown, Filter, Search, GripVertical, ChevronLeft, ChevronRight, ChevronsLeft, ChevronsRight, CalendarIcon, X } from "lucide-react";
import { format, startOfDay, endOfDay } from "date-fns";
import { de } from "date-fns/locale";
import { DateRange } from "react-day-picker";
import { DeviationIndicator } from "./DeviationIndicator";
import { useAlerts } from "@/hooks/useAlerts";
import { useAccounts } from "@/hooks/useAccounts";
import * as XLSX from "xlsx";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskAccountName, maskCampaignName, maskRuleName, maskEmail } from "@/lib/demoMode";
import { cn } from "@/lib/utils";

// Resizable column header component - uses CSS-only updates during drag for performance
function ResizableHeader({ 
  children, 
  width, 
  onResize, 
  className = "",
  onClick
}: { 
  children: React.ReactNode; 
  width: number; 
  onResize: (width: number) => void;
  className?: string;
  onClick?: () => void;
}) {
  const headerRef = useRef<HTMLTableCellElement>(null);
  const startXRef = useRef(0);
  const startWidthRef = useRef(0);
  const currentWidthRef = useRef(width);
  const isDraggingRef = useRef(false);
  const wasDraggingRef = useRef(false);

  // Update ref when width prop changes
  currentWidthRef.current = width;

  const handleMouseDown = useCallback((e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    
    isDraggingRef.current = true;
    wasDraggingRef.current = false;
    startXRef.current = e.clientX;
    startWidthRef.current = currentWidthRef.current;

    // Get all cells in this column for direct DOM manipulation
    const table = headerRef.current?.closest('table');
    const columnIndex = headerRef.current?.cellIndex ?? 0;
    const allCells = table?.querySelectorAll(`tr > :nth-child(${columnIndex + 1})`) as NodeListOf<HTMLElement> | undefined;

    const handleMouseMove = (e: MouseEvent) => {
      if (!isDraggingRef.current) return;
      
      wasDraggingRef.current = true; // Mark that actual dragging occurred
      const diff = e.clientX - startXRef.current;
      const newWidth = Math.max(60, startWidthRef.current + diff);
      currentWidthRef.current = newWidth;
      
      // Direct DOM manipulation - no React state update during drag
      allCells?.forEach(cell => {
        cell.style.width = `${newWidth}px`;
        cell.style.minWidth = `${newWidth}px`;
      });
    };

    const handleMouseUp = () => {
      isDraggingRef.current = false;
      document.removeEventListener("mousemove", handleMouseMove);
      document.removeEventListener("mouseup", handleMouseUp);
      document.body.style.cursor = '';
      document.body.style.userSelect = '';
      
      // Only update React state once at the end
      if (currentWidthRef.current !== startWidthRef.current) {
        onResize(currentWidthRef.current);
      }
    };

    document.body.style.cursor = 'col-resize';
    document.body.style.userSelect = 'none';
    document.addEventListener("mousemove", handleMouseMove);
    document.addEventListener("mouseup", handleMouseUp);
  }, [onResize]);

  const handleHeaderClick = useCallback(() => {
    // Only trigger sort if we weren't dragging
    if (wasDraggingRef.current) {
      wasDraggingRef.current = false;
      return;
    }
    onClick?.();
  }, [onClick]);

  return (
    <TableHead 
      ref={headerRef}
      style={{ width: `${width}px`, minWidth: `${width}px`, willChange: 'width' }}
      className={`relative ${className}`}
      onClick={handleHeaderClick}
    >
      <div className="flex items-center gap-1 pr-4">
        {children}
      </div>
      <div
        className="absolute right-0 top-0 h-full w-4 cursor-col-resize flex items-center justify-center hover:bg-muted/50 group"
        onMouseDown={handleMouseDown}
        onClick={(e) => e.stopPropagation()}
      >
        <GripVertical className="h-3 w-3 text-muted-foreground/50 group-hover:text-muted-foreground" />
      </div>
    </TableHead>
  );
}

export function AlertResultsTable() {
  const { accounts } = useAccounts();
  const { isDemoMode } = useDemoMode();
  const [selectedAccount, setSelectedAccount] = useState<string>("all");
  const [dateRange, setDateRange] = useState<DateRange | undefined>(undefined);
  const [campaignFilter, setCampaignFilter] = useState<string>("");
  const [sortField, setSortField] = useState<string>("alert_created_at");
  const [sortDirection, setSortDirection] = useState<"asc" | "desc">("desc");
  
  // Pagination state
  const [pageSize, setPageSize] = useState<number>(20);
  const [currentPage, setCurrentPage] = useState(1);
  
  // Column widths state
  const [columnWidths, setColumnWidths] = useState({
    rule_name: 120,
    account_name: 120,
    campaign_name: 200,
    metric_name: 100,
    current_value: 80,
    reference_value: 80,
    deviation_percent: 100,
    comparison_period: 100,
    alert_created_at: 130,
    run_type: 90,
    triggered_by: 150,
  });
  
  const updateColumnWidth = useCallback((column: keyof typeof columnWidths, width: number) => {
    setColumnWidths(prev => ({ ...prev, [column]: width }));
  }, []);

  const { alerts, isLoading } = useAlerts({
    accountId: selectedAccount !== "all" ? selectedAccount : undefined,
  });

  // Flatten alert_items from all alerts and filter to only show actual deviations (is_today = true or unique per campaign)
  const alertItems = useMemo(() => {
    if (!alerts) return [];
    
    const items: any[] = [];
    const seenCampaigns = new Set<string>();
    
    for (const alert of alerts) {
      if (!alert.alert_items) continue;
      
      for (const item of alert.alert_items as any[]) {
        // Create a unique key for each campaign per alert
        const key = `${alert.id}-${item.external_campaign_id || item.campaign_id}`;
        
        // Only take the first (most recent/today) entry per campaign per alert
        if (!seenCampaigns.has(key)) {
          seenCampaigns.add(key);
          items.push({
            ...item,
            alert_date: alert.alert_date,
            alert_created_at: alert.created_at,
            run_type: alert.run_type,
            triggered_by_email: (alert as any).triggered_by_email,
          });
        }
      }
    }
    
    return items;
  }, [alerts]);

  // Filter items by date range and campaign name
  const filteredItems = useMemo(() => {
    return alertItems.filter((item) => {
      // Date range filter
      let matchesDate = true;
      if (dateRange?.from) {
        const itemDate = new Date(item.date);
        matchesDate = itemDate >= startOfDay(dateRange.from);
        if (dateRange.to) {
          matchesDate = matchesDate && itemDate <= endOfDay(dateRange.to);
        }
      }
      
      const matchesCampaign = !campaignFilter || 
        (item.campaign_name && item.campaign_name.toLowerCase().includes(campaignFilter.toLowerCase()));
      return matchesDate && matchesCampaign;
    });
  }, [alertItems, dateRange, campaignFilter]);

  // Sort items
  const sortedItems = useMemo(() => {
    return [...filteredItems].sort((a, b) => {
      let aVal = a[sortField];
      let bVal = b[sortField];
      
      // Handle numeric fields
      if (typeof aVal === "number" && typeof bVal === "number") {
        return sortDirection === "desc" ? Math.abs(bVal) - Math.abs(aVal) : Math.abs(aVal) - Math.abs(bVal);
      }
      
      // Handle string fields
      aVal = String(aVal || "").toLowerCase();
      bVal = String(bVal || "").toLowerCase();
      
      if (sortDirection === "desc") {
        return bVal.localeCompare(aVal);
      }
      return aVal.localeCompare(bVal);
    });
  }, [filteredItems, sortField, sortDirection]);

  // Paginated items - only render what's needed
  const paginatedItems = useMemo(() => {
    if (pageSize === -1) return sortedItems; // "All" option
    const startIndex = (currentPage - 1) * pageSize;
    return sortedItems.slice(startIndex, startIndex + pageSize);
  }, [sortedItems, currentPage, pageSize]);

  // Calculate total pages
  const totalPages = useMemo(() => {
    if (pageSize === -1) return 1;
    return Math.max(1, Math.ceil(sortedItems.length / pageSize));
  }, [sortedItems.length, pageSize]);

  // Reset to page 1 when filters change
  const handleAccountChange = (value: string) => {
    setSelectedAccount(value);
    setCurrentPage(1);
  };

  const handleDateRangeChange = (range: DateRange | undefined) => {
    setDateRange(range);
    setCurrentPage(1);
  };

  const clearDateRange = () => {
    setDateRange(undefined);
    setCurrentPage(1);
  };

  const handleCampaignFilterChange = (value: string) => {
    setCampaignFilter(value);
    setCurrentPage(1);
  };

  const handlePageSizeChange = (value: string) => {
    setPageSize(value === "all" ? -1 : parseInt(value));
    setCurrentPage(1);
  };

  const handleSort = (field: string) => {
    if (sortField === field) {
      setSortDirection(sortDirection === "asc" ? "desc" : "asc");
    } else {
      setSortField(field);
      setSortDirection("desc");
    }
    setCurrentPage(1);
  };

  const exportToExcel = () => {
    if (sortedItems.length === 0) return;

    const exportData = sortedItems.map((item) => ({
      "Regel": item.rule_name || "",
      "Account": item.account_name || "",
      "Kampagne": item.campaign_name || "",
      "Metrik": item.metric_name || "",
      "Aktueller Wert": item.current_value,
      "Referenzwert": item.reference_value,
      "Abweichung %": item.deviation_percent,
      "Threshold %": item.threshold_percent,
      "Vergleichszeitraum": item.comparison_period || "",
      "Richtung": item.alert_direction || "",
      "Datum": item.date || "",
      "Uhrzeit": item.alert_created_at ? format(new Date(item.alert_created_at), "HH:mm") : "",
      "Typ": item.run_type === "scheduled" ? "Geplant" : "Manuell",
      "Ausgelöst von": item.run_type === "scheduled" ? "System" : (item.triggered_by_email || "-"),
    }));

    const ws = XLSX.utils.json_to_sheet(exportData);
    const wb = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, "Alerts");
    
    const fileName = `alerts_${format(new Date(), "yyyy-MM-dd")}.xlsx`;
    XLSX.writeFile(wb, fileName);
  };

  const metricLabels: Record<string, string> = {
    cost: "Kosten",
    clicks: "Klicks",
    impressions: "Impressionen",
    cost_per_click: "CPC",
    click_through_rate: "CTR",
    acos_clicks_14d: "ACoS",
    roas_clicks_14d: "ROAS",
    sales_14d: "Umsatz",
    purchases_14d: "Conversions",
    cost_no_conversions: "Kosten ohne Conversions",
  };

  const comparisonLabels: Record<string, string> = {
    yesterday: "Gestern",
    last_7_days: "Letzte 7 Tage",
    last_14_days: "Letzte 14 Tage",
    last_30_days: "Letzte 30 Tage",
    none: "Absolut",
  };

  return (
    <Card>
      <CardHeader>
        <div className="flex items-center justify-between">
          <CardTitle className="flex items-center gap-2">
            <Filter className="h-5 w-5" />
            Alert Ergebnisse
          </CardTitle>
          <Button 
            variant="outline" 
            onClick={exportToExcel}
            disabled={sortedItems.length === 0}
          >
            <Download className="h-4 w-4 mr-2" />
            Export Excel
          </Button>
        </div>
        <div className="flex flex-wrap items-center gap-3 mt-4">
          <Select value={selectedAccount} onValueChange={handleAccountChange}>
            <SelectTrigger className="w-[180px]">
              <SelectValue placeholder="Alle Accounts" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">Alle Accounts</SelectItem>
              {accounts.map((account) => (
                <SelectItem key={account.id} value={account.id}>
                  {isDemoMode ? maskAccountName(account.account_name) : account.account_name}
                </SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex items-center gap-1">
            <Popover>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className={cn(
                    "w-[240px] justify-start text-left font-normal",
                    !dateRange && "text-muted-foreground"
                  )}
                >
                  <CalendarIcon className="mr-2 h-4 w-4" />
                  {dateRange?.from ? (
                    dateRange.to ? (
                      <>
                        {format(dateRange.from, "dd.MM.yy", { locale: de })} - {format(dateRange.to, "dd.MM.yy", { locale: de })}
                      </>
                    ) : (
                      format(dateRange.from, "dd.MM.yyyy", { locale: de })
                    )
                  ) : (
                    <span>Alle Daten</span>
                  )}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <Calendar
                  mode="range"
                  selected={dateRange}
                  onSelect={handleDateRangeChange}
                  numberOfMonths={2}
                  locale={de}
                  className="pointer-events-auto"
                />
              </PopoverContent>
            </Popover>
            {dateRange && (
              <Button
                variant="ghost"
                size="icon"
                onClick={clearDateRange}
                className="h-9 w-9"
              >
                <X className="h-4 w-4" />
              </Button>
            )}
          </div>
          <div className="relative flex-1 min-w-[200px] max-w-[300px]">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Kampagnenname enthält..."
              value={campaignFilter}
              onChange={(e) => handleCampaignFilterChange(e.target.value)}
              className="pl-9"
            />
          </div>
        </div>
      </CardHeader>
      <CardContent>
        {isLoading ? (
          <div className="text-center py-8 text-muted-foreground">Lade Alerts...</div>
        ) : sortedItems.length === 0 ? (
          <div className="text-center py-8 text-muted-foreground">
            Keine Alerts mit Abweichungen gefunden
          </div>
        ) : (
          <div className="border rounded-lg overflow-hidden">
            <div className="overflow-x-auto">
              <Table className="table-fixed">
                <TableHeader>
                  <TableRow className="bg-muted/50">
                    <ResizableHeader
                      width={columnWidths.rule_name}
                      onResize={(w) => updateColumnWidth("rule_name", w)}
                      className="cursor-pointer hover:bg-muted"
                      onClick={() => handleSort("rule_name")}
                    >
                      Regel
                      <ArrowUpDown className="h-3 w-3" />
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.account_name}
                      onResize={(w) => updateColumnWidth("account_name", w)}
                      className="cursor-pointer hover:bg-muted"
                      onClick={() => handleSort("account_name")}
                    >
                      Account
                      <ArrowUpDown className="h-3 w-3" />
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.campaign_name}
                      onResize={(w) => updateColumnWidth("campaign_name", w)}
                      className="cursor-pointer hover:bg-muted"
                      onClick={() => handleSort("campaign_name")}
                    >
                      Kampagne
                      <ArrowUpDown className="h-3 w-3" />
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.metric_name}
                      onResize={(w) => updateColumnWidth("metric_name", w)}
                    >
                      Metrik
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.current_value}
                      onResize={(w) => updateColumnWidth("current_value", w)}
                      className="text-right"
                    >
                      Aktuell
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.reference_value}
                      onResize={(w) => updateColumnWidth("reference_value", w)}
                      className="text-right"
                    >
                      Referenz
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.deviation_percent}
                      onResize={(w) => updateColumnWidth("deviation_percent", w)}
                      className="text-right cursor-pointer hover:bg-muted"
                      onClick={() => handleSort("deviation_percent")}
                    >
                      Abweichung
                      <ArrowUpDown className="h-3 w-3" />
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.comparison_period}
                      onResize={(w) => updateColumnWidth("comparison_period", w)}
                    >
                      Vergleich
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.alert_created_at}
                      onResize={(w) => updateColumnWidth("alert_created_at", w)}
                      className="cursor-pointer hover:bg-muted"
                      onClick={() => handleSort("alert_created_at")}
                    >
                      Datum/Uhrzeit
                      <ArrowUpDown className="h-3 w-3" />
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.run_type}
                      onResize={(w) => updateColumnWidth("run_type", w)}
                    >
                      Typ
                    </ResizableHeader>
                    <ResizableHeader
                      width={columnWidths.triggered_by}
                      onResize={(w) => updateColumnWidth("triggered_by", w)}
                    >
                      Ausgelöst von
                    </ResizableHeader>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {paginatedItems.map((item, index) => (
                    <TableRow 
                      key={item.id || index} 
                      className={index % 2 === 0 ? "bg-background" : "bg-muted/30"}
                    >
                      <TableCell style={{ width: columnWidths.rule_name, minWidth: columnWidths.rule_name }} className="font-medium truncate" title={isDemoMode ? maskRuleName(item.rule_name) : item.rule_name}>
                        {isDemoMode ? maskRuleName(item.rule_name) : (item.rule_name || "-")}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.account_name, minWidth: columnWidths.account_name }} className="truncate" title={isDemoMode ? maskAccountName(item.account_name) : item.account_name}>
                        {isDemoMode ? maskAccountName(item.account_name) : (item.account_name || "-")}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.campaign_name, minWidth: columnWidths.campaign_name }} className="truncate" title={isDemoMode ? maskCampaignName(item.campaign_name) : item.campaign_name}>
                        {isDemoMode ? maskCampaignName(item.campaign_name) : (item.campaign_name || item.external_campaign_id || "-")}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.metric_name, minWidth: columnWidths.metric_name }}>
                        {metricLabels[item.metric_name] || item.metric_name}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.current_value, minWidth: columnWidths.current_value }} className="text-right font-mono">
                        {typeof item.current_value === "number" ? item.current_value.toFixed(2) : "-"}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.reference_value, minWidth: columnWidths.reference_value }} className="text-right font-mono">
                        {typeof item.reference_value === "number" ? item.reference_value.toFixed(2) : "-"}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.deviation_percent, minWidth: columnWidths.deviation_percent }} className="text-right">
                        <DeviationIndicator 
                          value={item.deviation_percent} 
                          threshold={item.threshold_percent} 
                        />
                      </TableCell>
                      <TableCell style={{ width: columnWidths.comparison_period, minWidth: columnWidths.comparison_period }}>
                        {comparisonLabels[item.comparison_period] || item.comparison_period || "-"}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.alert_created_at, minWidth: columnWidths.alert_created_at }}>
                        {item.alert_created_at 
                          ? format(new Date(item.alert_created_at), "dd.MM.yyyy HH:mm") 
                          : item.date 
                            ? format(new Date(item.date), "dd.MM.yyyy") 
                            : "-"}
                      </TableCell>
                      <TableCell style={{ width: columnWidths.run_type, minWidth: columnWidths.run_type }}>
                        <span className={`inline-flex items-center px-2 py-0.5 rounded-full text-xs font-medium ${
                          item.run_type === "scheduled" 
                            ? "bg-blue-100 text-blue-800 dark:bg-blue-900/30 dark:text-blue-300" 
                            : "bg-amber-100 text-amber-800 dark:bg-amber-900/30 dark:text-amber-300"
                        }`}>
                          {item.run_type === "scheduled" ? "⏰ Geplant" : "👤 Manuell"}
                        </span>
                      </TableCell>
                      <TableCell style={{ width: columnWidths.triggered_by, minWidth: columnWidths.triggered_by }} className="text-muted-foreground text-sm truncate" title={isDemoMode ? maskEmail(item.triggered_by_email) : item.triggered_by_email}>
                        {item.run_type === "scheduled" ? "System" : (isDemoMode ? maskEmail(item.triggered_by_email) : (item.triggered_by_email || "-"))}
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </div>
          </div>
        )}
        {/* Pagination Controls */}
        <div className="mt-4 flex flex-wrap items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <span className="text-sm text-muted-foreground">Zeige</span>
            <Select 
              value={pageSize === -1 ? "all" : String(pageSize)} 
              onValueChange={handlePageSizeChange}
            >
              <SelectTrigger className="w-[80px] h-8">
                <SelectValue />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="20">20</SelectItem>
                <SelectItem value="50">50</SelectItem>
                <SelectItem value="100">100</SelectItem>
                <SelectItem value="200">200</SelectItem>
                <SelectItem value="all">Alle</SelectItem>
              </SelectContent>
            </Select>
            <span className="text-sm text-muted-foreground">
              {pageSize === -1 
                ? `${sortedItems.length} Alerts` 
                : `${Math.min((currentPage - 1) * pageSize + 1, sortedItems.length)}-${Math.min(currentPage * pageSize, sortedItems.length)} von ${sortedItems.length} Alerts`
              }
            </span>
          </div>
          
          {pageSize !== -1 && totalPages > 1 && (
            <div className="flex items-center gap-1">
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setCurrentPage(1)}
                disabled={currentPage === 1}
              >
                <ChevronsLeft className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setCurrentPage(p => Math.max(1, p - 1))}
                disabled={currentPage === 1}
              >
                <ChevronLeft className="h-4 w-4" />
              </Button>
              <span className="px-3 text-sm">
                Seite {currentPage} von {totalPages}
              </span>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setCurrentPage(p => Math.min(totalPages, p + 1))}
                disabled={currentPage === totalPages}
              >
                <ChevronRight className="h-4 w-4" />
              </Button>
              <Button
                variant="outline"
                size="icon"
                className="h-8 w-8"
                onClick={() => setCurrentPage(totalPages)}
                disabled={currentPage === totalPages}
              >
                <ChevronsRight className="h-4 w-4" />
              </Button>
            </div>
          )}
        </div>
      </CardContent>
    </Card>
  );
}

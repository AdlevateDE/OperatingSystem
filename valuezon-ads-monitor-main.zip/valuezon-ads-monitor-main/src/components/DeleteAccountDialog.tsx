import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import { useLanguage } from "@/contexts/LanguageContext";
import { Tables } from "@/integrations/supabase/types";

type Account = Tables<"amazon_accounts">;

interface DeleteAccountDialogProps {
  open: boolean;
  onOpenChange: (open: boolean) => void;
  account: Account | null;
  onConfirm: () => Promise<void>;
  isDeleting?: boolean;
}

export function DeleteAccountDialog({
  open,
  onOpenChange,
  account,
  onConfirm,
  isDeleting = false,
}: DeleteAccountDialogProps) {
  const { t } = useLanguage();

  if (!account) return null;

  return (
    <AlertDialog open={open} onOpenChange={onOpenChange}>
      <AlertDialogContent>
        <AlertDialogHeader>
          <AlertDialogTitle>{t.deleteAccount}</AlertDialogTitle>
          <AlertDialogDescription>
            {t.deleteAccountConfirm?.replace("{name}", account.account_name) ||
              `Sind Sie sicher, dass Sie den Account "${account.account_name}" löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.`}
          </AlertDialogDescription>
        </AlertDialogHeader>
        <AlertDialogFooter>
          <AlertDialogCancel>{t.cancel}</AlertDialogCancel>
          <AlertDialogAction
            onClick={onConfirm}
            disabled={isDeleting}
            className="bg-destructive text-destructive-foreground hover:bg-destructive/90"
          >
            {isDeleting ? t.deleting : t.delete}
          </AlertDialogAction>
        </AlertDialogFooter>
      </AlertDialogContent>
    </AlertDialog>
  );
}

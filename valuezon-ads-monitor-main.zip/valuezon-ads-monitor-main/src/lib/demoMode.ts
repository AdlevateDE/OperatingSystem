// Cache for consistent masking across re-renders
const accountCache = new Map<string, string>();
const campaignCache = new Map<string, string>();
const ruleCache = new Map<string, string>();
const emailCache = new Map<string, string>();

let accountCounter = 1;
let campaignCounter = 1;
let ruleCounter = 1;
let emailCounter = 1;

export function resetDemoCache() {
  accountCache.clear();
  campaignCache.clear();
  ruleCache.clear();
  emailCache.clear();
  accountCounter = 1;
  campaignCounter = 1;
  ruleCounter = 1;
  emailCounter = 1;
}

export function maskAccountName(name: string | null | undefined): string {
  if (!name) return "Demo Account";
  if (accountCache.has(name)) return accountCache.get(name)!;
  const masked = `Demo Account ${accountCounter++}`;
  accountCache.set(name, masked);
  return masked;
}

export function maskCampaignName(name: string | null | undefined): string {
  if (!name) return "Demo Kampagne";
  if (campaignCache.has(name)) return campaignCache.get(name)!;
  const letters = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
  const letter = letters[(campaignCounter - 1) % 26];
  const num = Math.floor((campaignCounter - 1) / 26);
  const masked = `Demo Kampagne ${letter}${num > 0 ? num : ""}`;
  campaignCounter++;
  campaignCache.set(name, masked);
  return masked;
}

export function maskRuleName(name: string | null | undefined): string {
  if (!name) return "Demo Regel";
  if (ruleCache.has(name)) return ruleCache.get(name)!;
  const masked = `Demo Regel ${ruleCounter++}`;
  ruleCache.set(name, masked);
  return masked;
}

export function maskEmail(email: string | null | undefined): string {
  if (!email) return "user@demo.com";
  if (emailCache.has(email)) return emailCache.get(email)!;
  const masked = `demo.user${emailCounter++}@example.com`;
  emailCache.set(email, masked);
  return masked;
}

export function maskProfileId(id: string | null | undefined): string {
  if (!id) return "XXXX-XXXX-XXXX";
  return "XXXX-" + id.slice(-4).padStart(4, "X");
}

export function maskUrl(url: string | null | undefined): string {
  if (!url) return "";
  return "https://••••••••••••••••";
}

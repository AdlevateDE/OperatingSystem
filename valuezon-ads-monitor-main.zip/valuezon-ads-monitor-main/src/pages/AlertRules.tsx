import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Plus, Search, MoreVertical, Package, Store, Monitor, Loader2, History, ChevronDown } from "lucide-react";
import { Card, CardContent } from "@/components/ui/card";
import { useAlertRules } from "@/hooks/useAlertRules";
import { useAccounts } from "@/hooks/useAccounts";
import { Switch } from "@/components/ui/switch";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { RuleBuilder } from "@/components/RuleBuilder";
import { MetricIcon } from "@/components/MetricIcon";
import { EmptyState } from "@/components/EmptyState";
import { useToast } from "@/hooks/use-toast";
import { supabase } from "@/integrations/supabase/client";
import { useQueryClient } from "@tanstack/react-query";
import { Badge } from "@/components/ui/badge";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Collapsible, CollapsibleContent, CollapsibleTrigger } from "@/components/ui/collapsible";
import { RuleChangeHistory } from "@/components/RuleChangeHistory";
import { DuplicateRuleDialog } from "@/components/DuplicateRuleDialog";
import { format } from "date-fns";
import { de, enUS } from "date-fns/locale";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { useLanguage } from "@/contexts/LanguageContext";
import { maskAccountName, maskRuleName, maskEmail } from "@/lib/demoMode";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
} from "@/components/ui/alert-dialog";
import {
  Dialog,
  DialogContent,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog";

export default function AlertRules() {
  const [isBuilderOpen, setIsBuilderOpen] = useState(false);
  const [editingRule, setEditingRule] = useState<any>(null);
  const [searchQuery, setSearchQuery] = useState("");
  const [selectedMetric, setSelectedMetric] = useState<string | undefined>();
  const [showActiveOnly, setShowActiveOnly] = useState(false);
  const [sendingAlert, setSendingAlert] = useState<string | null>(null);
  const [duplicateDialogRule, setDuplicateDialogRule] = useState<any>(null);
  const [showFreshnessDialog, setShowFreshnessDialog] = useState(false);
  interface AccountFreshness {
    profile_id: string;
    account_name: string;
    campaign_type: 'sp' | 'sb' | 'sd';
    is_fresh: boolean;
    last_sync_minutes_ago: number;
    last_sync_at: string;
    latest_data_date: string;
  }
  const [freshnessData, setFreshnessData] = useState<{
    is_fresh: boolean;
    details_by_account: AccountFreshness[];
    stale_items: AccountFreshness[];
  } | null>(null);
  const [profileIdsForSync, setProfileIdsForSync] = useState<string[]>([]);
  const [pendingRuleId, setPendingRuleId] = useState<string | null>(null);
  const [pendingCampaignTypes, setPendingCampaignTypes] = useState<string[]>(['sp']);
  const [selectedRuleForHistory, setSelectedRuleForHistory] = useState<{ id: string; name: string } | null>(null);
  const [activeTab, setActiveTab] = useState("rules");

  const { accounts } = useAccounts();
  const { isDemoMode } = useDemoMode();
  const { language, t } = useLanguage();
  const { rules, isLoading, toggleRuleStatus, deleteRule } = useAlertRules({
    metric: selectedMetric,
    isActive: showActiveOnly ? true : undefined,
  });
  const { toast } = useToast();
  const queryClient = useQueryClient();

  const dateLocale = language === 'de' ? de : enUS;

  const periodLabels: Record<string, string> = {
    'yesterday': t.yesterday,
    'same_day_last_week': t.sameDayLastWeek,
    'last_7_days': language === 'de' ? '7 Tage Ø' : '7 days avg',
    'last_14_days': language === 'de' ? '14 Tage Ø' : '14 days avg',
    'last_30_days': language === 'de' ? '30 Tage Ø' : '30 days avg',
    'none': '-',
  };

  const filteredRules = rules.filter((rule: any) =>
    rule.rule_name.toLowerCase().includes(searchQuery.toLowerCase())
  );

  const handleToggleStatus = (id: string, currentStatus: boolean, ruleName: string) => {
    toggleRuleStatus.mutate({ id, isActive: !currentStatus, ruleName });
  };

  const handleDeleteRule = (id: string, ruleName: string) => {
    if (confirm(t.deleteRuleConfirm)) {
      deleteRule.mutate({ id, ruleName });
    }
  };

  const handleDuplicateSubmit = async (ruleName: string, accountIds: string[]) => {
    if (!duplicateDialogRule) return;
    
    const rule = duplicateDialogRule;
    
    try {
      const { data: session } = await supabase.auth.getSession();
      const userId = session?.session?.user?.id;
      
      const { error } = await supabase
        .from('alert_rules')
        .insert({
          rule_name: ruleName,
          account_id: accountIds[0],
          account_ids: accountIds,
          metric_name: rule.metric_name,
          threshold_percent: rule.threshold_percent,
          threshold_type: rule.threshold_type || 'percentage',
          comparison_period: rule.comparison_period,
          check_frequency: rule.check_frequency,
          check_schedule: rule.check_schedule || 'both',
          alert_direction: rule.alert_direction,
          campaign_types: rule.campaign_types || ['sp'],
          campaign_selection_mode: rule.campaign_selection_mode || 'all',
          selected_campaigns: rule.selected_campaigns,
          campaign_filters: rule.campaign_filters,
          campaign_filters_logic: rule.campaign_filters_logic || 'AND',
          alert_conditions: rule.alert_conditions,
          alert_conditions_logic: rule.alert_conditions_logic || 'AND',
          is_active: false,
          created_by: userId,
          last_edited_by: userId,
        });

      if (error) throw error;

      await queryClient.invalidateQueries({ queryKey: ["alertRules"] });

      toast({
        title: t.ruleDuplicated,
        description: t.ruleDuplicatedDesc.replace('{name}', ruleName).replace('{count}', String(accountIds.length)),
      });
    } catch (error: any) {
      toast({
        title: t.errorDuplicating,
        description: error.message || t.couldNotDuplicate,
        variant: "destructive",
      });
      throw error;
    }
  };

  const triggerSyncForCampaignTypes = async (campaignTypes: string[], ruleId?: string) => {
    const errors: string[] = [];
    const triggeredTypes: string[] = [];
    
    // Generate a unique batch_id to group all reports from this sync action
    const batchId = crypto.randomUUID();
    console.log(`Generated batch_id: ${batchId} for campaign types: ${campaignTypes.join(', ')}`);
    
    for (const type of campaignTypes) {
      let functionName: string;
      switch (type) {
        case 'sb': functionName = 'trigger-daily-report-sb'; break;
        case 'sd': functionName = 'trigger-daily-report-sd'; break;
        default: functionName = 'trigger-daily-report-sp';
      }
      
      try {
        const body = ruleId 
          ? { rule_id: ruleId, batch_id: batchId } 
          : { trigger_all: true, batch_id: batchId };
        const { error } = await supabase.functions.invoke(functionName, { body });
        
        if (error) {
          errors.push(`${type.toUpperCase()}: ${error.message}`);
        } else {
          triggeredTypes.push(type.toUpperCase());
        }
      } catch (err: any) {
        errors.push(`${type.toUpperCase()}: ${err.message}`);
      }
    }
    
    return { triggeredTypes, errors };
  };

  const triggerMakeWorkflow = async () => {
    try {
      const typesToSync = pendingCampaignTypes.length > 0 ? pendingCampaignTypes : ['sp', 'sb', 'sd'];
      
      const { triggeredTypes, errors } = await triggerSyncForCampaignTypes(typesToSync);
      
      if (errors.length > 0 && triggeredTypes.length === 0) {
        throw new Error(errors.join(', '));
      }
      
      toast({
        title: t.dataSyncStarted,
        description: t.dataSyncStartedDesc.replace('{types}', triggeredTypes.join(' & ')),
        className: "bg-success text-success-foreground border-success",
      });
    } catch (error: any) {
      toast({
        title: t.error,
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const triggerMakeForRule = async (ruleId: string) => {
    setSendingAlert(ruleId);
    try {
      const rule = rules?.find(r => r.id === ruleId);
      const campaignTypes = rule?.campaign_types || ['sp'];
      
      const { triggeredTypes, errors } = await triggerSyncForCampaignTypes(campaignTypes, ruleId);
      
      if (errors.length > 0 && triggeredTypes.length === 0) {
        throw new Error(errors.join(', '));
      }
      
      toast({
        title: t.dataSyncStarted,
        description: t.dataSyncStartedDesc.replace('{types}', triggeredTypes.join(' & ')),
        className: "bg-success text-success-foreground border-success",
      });
    } catch (error: any) {
      toast({
        title: t.error,
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSendingAlert(null);
    }
  };

  const runAlertCheckForRule = async (ruleId: string) => {
    setSendingAlert(ruleId);
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) throw new Error(language === 'de' ? "Nicht angemeldet" : "Not logged in");
      
      const { data, error } = await supabase.functions.invoke('run-alert-checks', {
        body: {
          user_id: session.session.user.id,
          profile_ids: profileIdsForSync,
          run_type: 'manual',
          rule_id: ruleId,
        }
      });
      
      if (error) throw error;
      
      toast({
        title: t.alertCheckComplete,
        description: data.has_alerts 
          ? t.campaignsExceedThreshold.replace('{count}', String(data.total_campaigns))
          : t.allCampaignsGreen,
        className: data.has_alerts ? undefined : "bg-success text-success-foreground border-success",
      });
    } catch (error: any) {
      toast({
        title: t.alertCheckError,
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSendingAlert(null);
    }
  };

  const runAlertCheckForAllRules = async () => {
    setSendingAlert('batch');
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) throw new Error(language === 'de' ? "Nicht angemeldet" : "Not logged in");
      
      const { data, error } = await supabase.functions.invoke('run-alert-checks', {
        body: {
          user_id: session.session.user.id,
          profile_ids: profileIdsForSync,
          run_type: 'manual',
        }
      });
      
      if (error) throw error;
      
      toast({
        title: t.alertsChecked,
        description: data.has_alerts 
          ? t.campaignsExceedThreshold.replace('{count}', String(data.total_campaigns))
          : t.allCampaignsGreen,
        className: data.has_alerts ? undefined : "bg-success text-success-foreground border-success",
      });
    } catch (error: any) {
      toast({
        title: t.alertCheckError,
        description: error.message,
        variant: "destructive",
      });
    } finally {
      setSendingAlert(null);
    }
  };

  const handleCheckAllRules = async () => {
    setSendingAlert('batch');
    
    try {
      const { data: session } = await supabase.auth.getSession();
      if (!session?.session?.user?.id) throw new Error(language === 'de' ? "Nicht angemeldet" : "Not logged in");

      const { data: userAccounts } = await supabase
        .from('account_users')
        .select('account_id')
        .eq('user_id', session.session.user.id);
      
      const accountIds = userAccounts?.map(a => a.account_id) || [];
      
      const { data: rulesData } = await supabase
        .from('alert_rules')
        .select('amazon_accounts!inner(profile_id), campaign_types')
        .eq('is_active', true)
        .in('account_id', accountIds);
      
      const profileIds = [...new Set(rulesData?.map((r: any) => r.amazon_accounts.profile_id))];
      const allCampaignTypes = [...new Set(rulesData?.flatMap((r: any) => r.campaign_types || ['sp']))];
      
      setProfileIdsForSync(profileIds);
      setPendingCampaignTypes(allCampaignTypes);

      const { data: freshnessCheck } = await supabase.functions.invoke('check-data-freshness', {
        body: { profile_ids: profileIds, campaign_types: allCampaignTypes }
      });
      
      // Always show dialog - let user choose between fresh data or sync
      setFreshnessData(freshnessCheck);
      setShowFreshnessDialog(true);
      setSendingAlert(null);
      
    } catch (error: any) {
      setSendingAlert(null);
      toast({
        title: t.error,
        description: error.message,
        variant: "destructive",
      });
    }
  };

  const handleForceSync = async () => {
    setShowFreshnessDialog(false);
    
    if (pendingRuleId) {
      await triggerMakeForRule(pendingRuleId);
      setPendingRuleId(null);
    } else {
      await triggerMakeWorkflow();
    }
  };

  const handleUseFreshData = async () => {
    setShowFreshnessDialog(false);
    
    if (pendingRuleId) {
      await runAlertCheckForRule(pendingRuleId);
      setPendingRuleId(null);
    } else {
      await runAlertCheckForAllRules();
    }
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-bold">{t.alertRules}</h1>
          <p className="text-muted-foreground mt-1">{t.manageRules}</p>
        </div>
        <div className="flex gap-2">
          <Button 
            variant="outline" 
            onClick={handleCheckAllRules}
            disabled={sendingAlert === 'batch'}
          >
            {sendingAlert === 'batch' ? (
              <>
                <Loader2 className="h-4 w-4 mr-2 animate-spin" />
                {t.checking}
              </>
            ) : (
              t.checkAllRules
            )}
          </Button>
          <Button onClick={() => setIsBuilderOpen(true)}>
            <Plus className="h-4 w-4 mr-2" />
            {t.createNewRule}
          </Button>
        </div>
      </div>

      {/* Tabs */}
      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList>
          <TabsTrigger value="rules">{t.rules}</TabsTrigger>
          <TabsTrigger value="history">
            <History className="h-4 w-4 mr-2" />
            {t.changeHistory}
          </TabsTrigger>
        </TabsList>

        <TabsContent value="rules" className="space-y-4 mt-4">
          {/* Filters Bar */}
          <Card>
            <CardContent className="p-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="flex-1 relative">
                  <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
                  <Input
                    placeholder={t.searchRules}
                    value={searchQuery}
                    onChange={(e) => setSearchQuery(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Select value={selectedMetric || "all"} onValueChange={(v) => setSelectedMetric(v === "all" ? undefined : v)}>
                  <SelectTrigger className="w-[180px]">
                    <SelectValue placeholder={t.allMetrics} />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="all">{t.allMetrics}</SelectItem>
                    <SelectItem value="cost">{t.cost}</SelectItem>
                    <SelectItem value="clicks">{t.clicks}</SelectItem>
                    <SelectItem value="impressions">{t.impressions}</SelectItem>
                    <SelectItem value="cpc">{t.cpc}</SelectItem>
                    <SelectItem value="ctr">{t.ctr}</SelectItem>
                    <SelectItem value="acos">{t.acos}</SelectItem>
                  </SelectContent>
                </Select>
                <div className="flex items-center gap-2">
                  <Switch checked={showActiveOnly} onCheckedChange={setShowActiveOnly} />
                  <span className="text-sm">{t.onlyActive}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Rules Table */}
          {isLoading ? (
            <div className="text-center py-12">{t.loading}</div>
          ) : filteredRules.length === 0 ? (
            <EmptyState
              title={t.noRulesYet}
              description={language === 'de' ? "Erstellen Sie Ihre erste Regel, um die Kampagnenleistung zu überwachen" : "Create your first rule to start monitoring campaign performance"}
              action={
                <Button onClick={() => setIsBuilderOpen(true)}>
                  <Plus className="h-4 w-4 mr-2" />
                  {t.createFirstRule}
                </Button>
              }
            />
          ) : (
            <Card>
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="border-b">
                    <tr className="text-left">
                      <th className="p-4 font-medium">{t.ruleName}</th>
                      <th className="p-4 font-medium">{t.account}</th>
                      <th className="p-4 font-medium">{t.campaignType}</th>
                      <th className="p-4 font-medium">{t.metric}</th>
                      <th className="p-4 font-medium">{t.threshold}</th>
                      <th className="p-4 font-medium">{t.period}</th>
                      <th className="p-4 font-medium">{t.lastEdited}</th>
                      <th className="p-4 font-medium">{t.status}</th>
                      <th className="p-4 font-medium">{t.actions}</th>
                    </tr>
                  </thead>
                  <tbody>
                    {filteredRules.map((rule: any) => (
                      <tr key={rule.id} className="border-b last:border-0 hover:bg-muted/50">
                        <td className="p-4">
                          <div>
                            <span className="font-medium">
                              {isDemoMode ? maskRuleName(rule.rule_name) : rule.rule_name}
                            </span>
                            {rule.created_by_user?.email && (
                              <div className="text-xs text-muted-foreground mt-0.5">
                                {t.createdBy}: {isDemoMode 
                                  ? maskEmail(rule.created_by_user.email)
                                  : (rule.created_by_user.full_name || rule.created_by_user.email)}
                              </div>
                            )}
                          </div>
                        </td>
                        <td className="p-4 text-muted-foreground">
                          {(() => {
                            const accountIds: string[] = (rule as any).account_ids || [];
                            if (accountIds.length > 1) {
                              const accountNames = accounts
                                .filter(a => accountIds.includes(a.id))
                                .map(a => isDemoMode ? maskAccountName(a.account_name) : a.account_name);
                              return accountNames.length > 2
                                ? `${accountNames.slice(0, 2).join(', ')} +${accountNames.length - 2}`
                                : accountNames.join(', ');
                            }
                            const accountName = (rule as any).amazon_accounts?.account_name;
                            return isDemoMode ? maskAccountName(accountName) : (accountName || t.unknown);
                          })()}
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-1.5 flex-wrap">
                            {(rule.campaign_types || ['sp']).map((type: string) => (
                              <Badge key={type} variant="secondary" className="gap-1 text-xs">
                                {type === 'sp' && <Package className="h-3 w-3" />}
                                {type === 'sb' && <Store className="h-3 w-3" />}
                                {type === 'sd' && <Monitor className="h-3 w-3" />}
                                {type.toUpperCase()}
                              </Badge>
                            ))}
                          </div>
                        </td>
                        <td className="p-4">
                          <div className="flex items-center gap-2">
                            <MetricIcon metric={rule.metric_name} size="sm" />
                            <span className="text-sm capitalize">{rule.metric_name}</span>
                          </div>
                        </td>
                        <td className="p-4">
                          <span className="text-danger font-medium">
                            {rule.alert_direction === 'increases' && '+'}
                            {rule.alert_direction === 'decreases' && '-'}
                            {(!rule.alert_direction || rule.alert_direction === 'both') && '±'}
                            {rule.threshold_percent}{rule.threshold_type === 'absolute' ? '' : '%'}
                          </span>
                        </td>
                        <td className="p-4 text-sm text-muted-foreground">
                          {(() => {
                            const conditions = rule.alert_conditions as any[] | null;
                            const conditionPeriod = conditions?.[0]?.comparison_period;
                            const displayPeriod = conditionPeriod || rule.comparison_period;
                            return periodLabels[displayPeriod] || displayPeriod;
                          })()}
                        </td>
                        <td className="p-4">
                          {rule.last_edited_at ? (
                            <div className="text-sm">
                              <div className="text-muted-foreground">
                                {format(new Date(rule.last_edited_at), "dd.MM.yy, HH:mm", { locale: dateLocale })}
                              </div>
                              {rule.last_edited_by_user?.email && (
                                <div className="text-xs text-muted-foreground/70">
                                  {rule.last_edited_by_user.full_name || rule.last_edited_by_user.email}
                                </div>
                              )}
                            </div>
                          ) : (
                            <span className="text-muted-foreground text-sm">-</span>
                          )}
                        </td>
                        <td className="p-4">
                          <Switch
                            checked={rule.is_active}
                            onCheckedChange={() => handleToggleStatus(rule.id, rule.is_active, rule.rule_name)}
                          />
                        </td>
                        <td className="p-4">
                          <DropdownMenu>
                            <DropdownMenuTrigger asChild>
                              <Button variant="ghost" size="sm">
                                <MoreVertical className="h-4 w-4" />
                              </Button>
                            </DropdownMenuTrigger>
                            <DropdownMenuContent align="end">
                              <DropdownMenuItem
                                onClick={async () => {
                                  setSendingAlert(rule.id);
                                  try {
                                    let profileId: string | undefined = rule.amazon_accounts?.profile_id as string | undefined;
                                    if (!profileId) {
                                      const { data: accountRow, error: accErr } = await supabase
                                        .from('amazon_accounts')
                                        .select('profile_id')
                                        .eq('id', rule.account_id)
                                        .single();
                                      if (accErr) throw accErr;
                                      profileId = accountRow?.profile_id as string | undefined;
                                    }
                                    if (!profileId) throw new Error(language === 'de' ? "Profile ID nicht gefunden" : "Profile ID not found");
                                    
                                    const { data: freshnessCheck } = await supabase.functions.invoke('check-data-freshness', {
                                      body: { 
                                        profile_ids: [profileId],
                                        campaign_types: rule.campaign_types || ['sp']
                                      }
                                    });
                                    
                                    if (freshnessCheck?.is_fresh) {
                                      setProfileIdsForSync([profileId]);
                                      setPendingCampaignTypes(rule.campaign_types || ['sp']);
                                      setFreshnessData(freshnessCheck);
                                      setPendingRuleId(rule.id);
                                      setShowFreshnessDialog(true);
                                    } else {
                                      await triggerMakeForRule(rule.id);
                                    }
                                  } catch (error: any) {
                                    toast({
                                      title: t.error,
                                      description: error.message,
                                      variant: "destructive",
                                    });
                                    setSendingAlert(null);
                                  }
                                }}
                                disabled={sendingAlert === rule.id}
                              >
                                {sendingAlert === rule.id ? t.syncing : t.syncAndCheck}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setEditingRule(rule)}>
                                {t.edit}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setDuplicateDialogRule(rule)}>
                                {t.duplicate}
                              </DropdownMenuItem>
                              <DropdownMenuItem onClick={() => setSelectedRuleForHistory({ id: rule.id, name: rule.rule_name })}>
                                <History className="h-4 w-4 mr-2" />
                                {t.showHistory}
                              </DropdownMenuItem>
                              <DropdownMenuItem
                                className="text-danger"
                                onClick={() => handleDeleteRule(rule.id, rule.rule_name)}
                              >
                                {t.delete}
                              </DropdownMenuItem>
                            </DropdownMenuContent>
                          </DropdownMenu>
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </Card>
          )}
        </TabsContent>

        <TabsContent value="history" className="mt-4">
          <RuleChangeHistory maxHeight="600px" />
        </TabsContent>
      </Tabs>

      {/* Rule Builder Modal */}
      <RuleBuilder 
        open={isBuilderOpen || !!editingRule} 
        onClose={() => {
          setIsBuilderOpen(false);
          setEditingRule(null);
        }} 
        editRule={editingRule}
      />

      {/* Duplicate Rule Dialog */}
      <DuplicateRuleDialog
        rule={duplicateDialogRule}
        accounts={accounts}
        open={!!duplicateDialogRule}
        onClose={() => setDuplicateDialogRule(null)}
        onDuplicate={handleDuplicateSubmit}
      />

      {/* Rule History Dialog */}
      <Dialog open={!!selectedRuleForHistory} onOpenChange={() => setSelectedRuleForHistory(null)}>
        <DialogContent className="max-w-2xl">
          <DialogHeader>
            <DialogTitle>{t.changeHistory}: {selectedRuleForHistory?.name}</DialogTitle>
          </DialogHeader>
          {selectedRuleForHistory && (
            <RuleChangeHistory ruleId={selectedRuleForHistory.id} maxHeight="400px" />
          )}
        </DialogContent>
      </Dialog>

      {/* Freshness Check Dialog */}
      <AlertDialog open={showFreshnessDialog} onOpenChange={setShowFreshnessDialog}>
        <AlertDialogContent>
          <AlertDialogHeader>
            <AlertDialogTitle>
              {freshnessData?.is_fresh ? t.dataUpToDate : t.dataSyncRequired}
            </AlertDialogTitle>
            <AlertDialogDescription asChild>
              <div className="space-y-4">
                <Collapsible defaultOpen className="border rounded-md">
                  <CollapsibleTrigger className="flex items-center justify-between w-full p-3 hover:bg-muted/50 transition-colors">
                    <span className="font-medium text-sm">
                      {language === 'de' ? 'Datenaktualität nach Account' : 'Data freshness by account'}
                    </span>
                    <ChevronDown className="h-4 w-4 text-muted-foreground" />
                  </CollapsibleTrigger>
                  <CollapsibleContent>
                    <div className="max-h-[250px] overflow-y-auto">
                      <table className="w-full text-sm">
                        <thead className="bg-muted/50 sticky top-0">
                          <tr>
                            <th className="text-left p-2 font-medium">{t.account}</th>
                            <th className="text-center p-2 font-medium">SP</th>
                            <th className="text-center p-2 font-medium">SB</th>
                            <th className="text-center p-2 font-medium">SD</th>
                          </tr>
                        </thead>
                        <tbody>
                          {(() => {
                            // Group by account
                            const accountMap = new Map<string, { sp?: typeof freshnessData.details_by_account[0]; sb?: typeof freshnessData.details_by_account[0]; sd?: typeof freshnessData.details_by_account[0] }>();
                            freshnessData?.details_by_account?.forEach((item) => {
                              if (!accountMap.has(item.account_name)) {
                                accountMap.set(item.account_name, {});
                              }
                              accountMap.get(item.account_name)![item.campaign_type] = item;
                            });
                            
                            return Array.from(accountMap.entries()).map(([accountName, types]) => (
                              <tr key={accountName} className="border-t border-border">
                                <td className="p-2 font-medium">{accountName}</td>
                                {(['sp', 'sb', 'sd'] as const).map((type) => {
                                  const item = types[type];
                                  if (!item) {
                                    return <td key={type} className="text-center p-2 text-muted-foreground">-</td>;
                                  }
                                  return (
                                    <td key={type} className="text-center p-2">
                                      <span className={item.is_fresh ? "text-success" : "text-warning"}>
                                        {item.is_fresh ? "✅" : item.last_sync_minutes_ago < 0 ? "❌" : "⚠️"}
                                      </span>
                                      <span className="ml-1 text-xs text-muted-foreground">
                                        {item.last_sync_minutes_ago < 0 
                                          ? "-" 
                                          : `${item.last_sync_minutes_ago}m`}
                                      </span>
                                    </td>
                                  );
                                })}
                              </tr>
                            ));
                          })()}
                        </tbody>
                      </table>
                    </div>
                  </CollapsibleContent>
                </Collapsible>
                
                <div className="space-y-2 pt-2 border-t border-border">
                  <p className="font-medium">{t.wouldYouLike}</p>
                  <ul className="list-disc list-inside space-y-1 text-sm">
                    <li><strong>{t.checkNow}:</strong> {t.immediateAnalysis}</li>
                    <li><strong>{t.resync}:</strong> {t.fetchNewData}</li>
                  </ul>
                </div>
              </div>
            </AlertDialogDescription>
          </AlertDialogHeader>
          <AlertDialogFooter className="flex-col sm:flex-row gap-2">
            <AlertDialogCancel onClick={() => {
              setPendingRuleId(null);
              setPendingCampaignTypes(['sp']);
              setShowFreshnessDialog(false);
              setSendingAlert(null);
            }}>
              {t.cancel}
            </AlertDialogCancel>
            <AlertDialogAction 
              onClick={handleForceSync} 
              className="bg-muted text-foreground hover:bg-muted/80 border border-border"
            >
              {t.resync}
            </AlertDialogAction>
            <AlertDialogAction onClick={handleUseFreshData} disabled={!freshnessData?.details_by_account || freshnessData.details_by_account.length === 0}>
              {t.checkNow}
            </AlertDialogAction>
          </AlertDialogFooter>
        </AlertDialogContent>
      </AlertDialog>
    </div>
  );
}

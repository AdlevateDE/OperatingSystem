import { usePendingReports } from "@/hooks/usePendingReports";
import { useAlertHistory, useAlertHistoryStats, AlertHistoryItem } from "@/hooks/useAlertHistory";
import { useLanguage } from "@/contexts/LanguageContext";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover";
import { Calendar } from "@/components/ui/calendar";
import { RefreshCw, CheckCircle, XCircle, Clock, AlertTriangle, RotateCcw, Ban, Bell, Send, MessageSquareWarning, CalendarIcon, Filter, X } from "lucide-react";
import {
  Table,
  TableBody,
  TableCell,
  TableHead,
  TableHeader,
  TableRow,
} from "@/components/ui/table";
import {
  Tooltip,
  TooltipContent,
  TooltipProvider,
  TooltipTrigger,
} from "@/components/ui/tooltip";
import { formatDistanceToNow, format, isWithinInterval, startOfDay, endOfDay } from "date-fns";
import { de, enUS } from "date-fns/locale";
import { supabase } from "@/integrations/supabase/client";
import { toast } from "sonner";
import { useState, useMemo } from "react";
import { cn } from "@/lib/utils";

// Interpret error messages for reports
function interpretError(errorMessage: string | null, language: string): { icon: string; text: string; color: string } {
  if (!errorMessage) {
    return { icon: '-', text: '-', color: 'text-muted-foreground' };
  }

  const msg = errorMessage.toLowerCase();
  const isDE = language === 'de';

  if (msg.includes('429') || msg.includes('throttl') || msg.includes('too many')) {
    return {
      icon: '⏳',
      text: isDE ? `Amazon API überlastet (429)` : `Amazon API overloaded (429)`,
      color: 'text-amber-400'
    };
  }

  if (msg.includes('401') || msg.includes('unauthorized')) {
    return {
      icon: '🔐',
      text: isDE ? `Auth-Fehler (401)` : `Auth error (401)`,
      color: 'text-red-400'
    };
  }

  if (msg.includes('400') || msg.includes('profile') && (msg.includes('invalid') || msg.includes('not found'))) {
    return {
      icon: '⚠️',
      text: isDE ? `Ungültige Profil-ID (400)` : `Invalid profile ID (400)`,
      color: 'text-orange-400'
    };
  }

  if (msg.includes('403') || msg.includes('forbidden')) {
    return {
      icon: '🚫',
      text: isDE ? `Zugriff verweigert (403)` : `Access denied (403)`,
      color: 'text-red-400'
    };
  }

  if (msg.includes('max attempts') || msg.includes('timeout')) {
    return {
      icon: '❌',
      text: isDE ? `Timeout` : `Timeout`,
      color: 'text-red-400'
    };
  }

  if (msg.includes('no data') || msg.includes('empty')) {
    return {
      icon: '📭',
      text: isDE ? `Keine Daten` : `No data`,
      color: 'text-muted-foreground'
    };
  }

  return {
    icon: '❓',
    text: errorMessage.length > 50 ? `${errorMessage.substring(0, 50)}...` : errorMessage,
    color: 'text-red-400'
  };
}

// Interpret Slack error messages
function interpretSlackError(error: string | null, language: string): { icon: string; text: string; color: string } | null {
  if (!error) return null;
  
  const msg = error.toLowerCase();
  const isDE = language === 'de';
  
  if (msg.includes('rate limit') || msg.includes('429')) {
    return { 
      icon: '⏳', 
      text: isDE ? 'Rate Limit - Zu viele Anfragen' : 'Rate Limit - Too many requests', 
      color: 'text-amber-400' 
    };
  }
  if (msg.includes('timeout') || msg.includes('timed out')) {
    return { 
      icon: '⏱️', 
      text: isDE ? 'Timeout - Slack reagierte nicht' : 'Timeout - Slack not responding', 
      color: 'text-orange-400' 
    };
  }
  if (msg.includes('invalid') || msg.includes('404') || msg.includes('not found')) {
    return { 
      icon: '🔗', 
      text: isDE ? 'Webhook ungültig oder nicht gefunden' : 'Webhook invalid or not found', 
      color: 'text-red-400' 
    };
  }
  if (msg.includes('401') || msg.includes('unauthorized')) {
    return { 
      icon: '🔐', 
      text: isDE ? 'Webhook-Authentifizierung fehlgeschlagen' : 'Webhook authentication failed', 
      color: 'text-red-400' 
    };
  }
  if (msg.includes('channel_not_found')) {
    return { 
      icon: '📭', 
      text: isDE ? 'Slack-Kanal nicht gefunden' : 'Slack channel not found', 
      color: 'text-red-400' 
    };
  }
  if (msg.includes('network')) {
    return { 
      icon: '🌐', 
      text: isDE ? 'Netzwerkfehler' : 'Network error', 
      color: 'text-orange-400' 
    };
  }
  
  return {
    icon: '❓',
    text: error.length > 50 ? `${error.substring(0, 50)}...` : error,
    color: 'text-red-400'
  };
}

export default function ReportStatus() {
  const { reports, stats, isLoading, refetch } = usePendingReports();
  const { data: alertHistory, isLoading: alertsLoading, refetch: refetchAlerts } = useAlertHistory();
  const { stats: alertStats } = useAlertHistoryStats();
  const { language, t } = useLanguage();
  const [retryingIds, setRetryingIds] = useState<Set<string>>(new Set());
  const [resendingIds, setResendingIds] = useState<Set<string>>(new Set());
  
  // Slack Alerts filters
  const [statusFilter, setStatusFilter] = useState<string>("all");
  const [accountFilter, setAccountFilter] = useState<string>("all");
  const [dateFrom, setDateFrom] = useState<Date | undefined>(undefined);
  const [dateTo, setDateTo] = useState<Date | undefined>(undefined);
  
  // Data Status filters
  const [dataStatusFilter, setDataStatusFilter] = useState<string>("all");
  const [dataAccountFilter, setDataAccountFilter] = useState<string>("all");
  const [dataReportTypeFilter, setDataReportTypeFilter] = useState<string>("all");
  const [dataDateFrom, setDataDateFrom] = useState<Date | undefined>(undefined);
  const [dataDateTo, setDataDateTo] = useState<Date | undefined>(undefined);
  
  const locale = language === 'de' ? de : enUS;

  // Get unique accounts from alert history
  const uniqueAccounts = useMemo(() => {
    if (!alertHistory) return [];
    const accounts = [...new Set(alertHistory.map(a => a.account_name).filter(Boolean))];
    return accounts.sort() as string[];
  }, [alertHistory]);

  // Get unique accounts from reports
  const uniqueReportAccounts = useMemo(() => {
    if (!reports) return [];
    const accounts = [...new Set(reports.map(r => r.account_name).filter(Boolean))];
    return accounts.sort() as string[];
  }, [reports]);

  // Filter reports
  const filteredReports = useMemo(() => {
    if (!reports) return [];
    
    return reports.filter((report) => {
      // Status filter
      if (dataStatusFilter !== "all" && report.status !== dataStatusFilter) return false;
      
      // Account filter
      if (dataAccountFilter !== "all" && report.account_name !== dataAccountFilter) return false;
      
      // Report type filter
      if (dataReportTypeFilter !== "all" && report.report_type !== dataReportTypeFilter) return false;
      
      // Date range filter
      const reportDate = new Date(report.created_at);
      if (dataDateFrom && reportDate < startOfDay(dataDateFrom)) return false;
      if (dataDateTo && reportDate > endOfDay(dataDateTo)) return false;
      
      return true;
    });
  }, [reports, dataStatusFilter, dataAccountFilter, dataReportTypeFilter, dataDateFrom, dataDateTo]);

  // Check if any data filter is active
  const hasActiveDataFilters = dataStatusFilter !== "all" || dataAccountFilter !== "all" || dataReportTypeFilter !== "all" || dataDateFrom || dataDateTo;

  const clearDataFilters = () => {
    setDataStatusFilter("all");
    setDataAccountFilter("all");
    setDataReportTypeFilter("all");
    setDataDateFrom(undefined);
    setDataDateTo(undefined);
  };

  // Filter alert history
  const filteredAlertHistory = useMemo(() => {
    if (!alertHistory) return [];
    
    return alertHistory.filter((alert) => {
      // Status filter
      if (statusFilter !== "all") {
        if (statusFilter === "sent" && !alert.slack_sent) return false;
        if (statusFilter === "failed" && (alert.slack_sent || !alert.slack_error)) return false;
        if (statusFilter === "pending" && (alert.slack_sent || alert.slack_error)) return false;
      }
      
      // Account filter
      if (accountFilter !== "all" && alert.account_name !== accountFilter) return false;
      
      // Date range filter
      const alertDate = new Date(alert.created_at);
      if (dateFrom && alertDate < startOfDay(dateFrom)) return false;
      if (dateTo && alertDate > endOfDay(dateTo)) return false;
      
      return true;
    });
  }, [alertHistory, statusFilter, accountFilter, dateFrom, dateTo]);

  // Check if any filter is active
  const hasActiveFilters = statusFilter !== "all" || accountFilter !== "all" || dateFrom || dateTo;

  const clearFilters = () => {
    setStatusFilter("all");
    setAccountFilter("all");
    setDateFrom(undefined);
    setDateTo(undefined);
  };

  const handleRetry = async (reportId: string) => {
    setRetryingIds(prev => new Set(prev).add(reportId));
    
    try {
      const { error } = await supabase.functions.invoke('retry-failed-report', {
        body: { report_id: reportId },
      });

      if (error) throw error;

      toast.success(language === 'de' ? 'Report wird erneut versucht...' : 'Retrying report...');
      setTimeout(() => refetch(), 1500);
    } catch (error) {
      console.error('Retry failed:', error);
      toast.error(language === 'de' ? 'Retry fehlgeschlagen' : 'Retry failed');
    } finally {
      setRetryingIds(prev => {
        const next = new Set(prev);
        next.delete(reportId);
        return next;
      });
    }
  };

  const handleResendSlack = async (alertId: string) => {
    setResendingIds(prev => new Set(prev).add(alertId));
    
    try {
      const { data: { user } } = await supabase.auth.getUser();
      if (!user) throw new Error('Not authenticated');

      const { error } = await supabase.functions.invoke('send-slack-alert', {
        body: { alert_id: alertId, user_id: user.id, run_type: 'manual_resend' },
      });

      if (error) throw error;

      toast.success(language === 'de' ? 'Slack-Nachricht erneut gesendet' : 'Slack message resent');
      setTimeout(() => refetchAlerts(), 1500);
    } catch (error) {
      console.error('Resend failed:', error);
      toast.error(language === 'de' ? 'Erneut senden fehlgeschlagen' : 'Resend failed');
    } finally {
      setResendingIds(prev => {
        const next = new Set(prev);
        next.delete(alertId);
        return next;
      });
    }
  };

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "completed":
        return (
          <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
            <CheckCircle className="h-3 w-3 mr-1" />
            {language === 'de' ? 'Abgeschlossen' : 'Completed'}
          </Badge>
        );
      case "failed":
        return (
          <Badge variant="destructive" className="bg-red-500/20 text-red-400 border-red-500/30">
            <XCircle className="h-3 w-3 mr-1" />
            {language === 'de' ? 'Fehlgeschlagen' : 'Failed'}
          </Badge>
        );
      case "creation_failed":
        return (
          <Badge variant="destructive" className="bg-orange-500/20 text-orange-400 border-orange-500/30">
            <Ban className="h-3 w-3 mr-1" />
            {language === 'de' ? 'Nicht erstellt' : 'Not created'}
          </Badge>
        );
      default:
        return (
          <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 border-amber-500/30">
            <Clock className="h-3 w-3 mr-1" />
            {language === 'de' ? 'Ausstehend' : 'Pending'}
          </Badge>
        );
    }
  };

  const getSlackStatusBadge = (alert: { slack_sent: boolean | null; slack_error: string | null }) => {
    if (alert.slack_sent) {
      return (
        <Badge className="bg-emerald-500/20 text-emerald-400 border-emerald-500/30">
          <CheckCircle className="h-3 w-3 mr-1" />
          {language === 'de' ? 'Gesendet' : 'Sent'}
        </Badge>
      );
    }
    if (alert.slack_error) {
      return (
        <Badge variant="destructive" className="bg-red-500/20 text-red-400 border-red-500/30">
          <XCircle className="h-3 w-3 mr-1" />
          {language === 'de' ? 'Fehler' : 'Failed'}
        </Badge>
      );
    }
    return (
      <Badge variant="secondary" className="bg-amber-500/20 text-amber-400 border-amber-500/30">
        <Clock className="h-3 w-3 mr-1" />
        {language === 'de' ? 'Ausstehend' : 'Pending'}
      </Badge>
    );
  };

  const getAlertTypeBadge = (alert: { is_all_clear: boolean | null; is_no_data: boolean | null; total_items: number | null }) => {
    if (alert.is_no_data) {
      return (
        <Badge variant="outline" className="border-amber-500/30 text-amber-400">
          <MessageSquareWarning className="h-3 w-3 mr-1" />
          {language === 'de' ? 'Keine Daten' : 'No Data'}
        </Badge>
      );
    }
    if (alert.is_all_clear) {
      return (
        <Badge variant="outline" className="border-emerald-500/30 text-emerald-400">
          <CheckCircle className="h-3 w-3 mr-1" />
          All Clear
        </Badge>
      );
    }
    return (
      <Badge variant="outline" className="border-red-500/30 text-red-400">
        <AlertTriangle className="h-3 w-3 mr-1" />
        {alert.total_items || 0} Alerts
      </Badge>
    );
  };

  const getReportTypeLabel = (type: string | null) => {
    switch (type) {
      case "sp": return "Sponsored Products";
      case "sb": return "Sponsored Brands";
      case "sd": return "Sponsored Display";
      default: return type || "SP";
    }
  };

  const creationFailedCount = reports.filter(r => r.status === 'creation_failed').length;

  return (
    <div className="space-y-6">
      <Tabs defaultValue="data" className="w-full">
        <TabsList className="mb-6">
          <TabsTrigger value="data" className="flex items-center gap-2">
            <Clock className="h-4 w-4" />
            {language === 'de' ? 'Daten-Status' : 'Data Status'}
          </TabsTrigger>
          <TabsTrigger value="slack" className="flex items-center gap-2">
            <Bell className="h-4 w-4" />
            {language === 'de' ? 'Slack Alerts' : 'Slack Alerts'}
          </TabsTrigger>
        </TabsList>

        {/* Data Status Tab */}
        <TabsContent value="data" className="space-y-6">
          {/* Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-5 gap-4">
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Gesamt' : 'Total'}</p>
                    <p className="text-2xl font-bold text-foreground">{stats.total}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Clock className="h-5 w-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Ausstehend' : 'Pending'}</p>
                    <p className="text-2xl font-bold text-amber-400">{stats.pending}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                    <AlertTriangle className="h-5 w-5 text-amber-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Abgeschlossen' : 'Completed'}</p>
                    <p className="text-2xl font-bold text-emerald-400">{stats.completed}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                    <CheckCircle className="h-5 w-5 text-emerald-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Fehlgeschlagen' : 'Failed'}</p>
                    <p className="text-2xl font-bold text-red-400">{stats.failed}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
                    <XCircle className="h-5 w-5 text-red-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Nicht erstellt' : 'Not Created'}</p>
                    <p className="text-2xl font-bold text-orange-400">{creationFailedCount}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-orange-500/10 flex items-center justify-center">
                    <Ban className="h-5 w-5 text-orange-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Reports Table */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-col gap-4">
              <div className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-foreground">{language === 'de' ? 'Report-Status' : 'Report Status'}</CardTitle>
                  <CardDescription>{language === 'de' ? 'Übersicht aller Amazon-Datenimporte' : 'Overview of all Amazon data imports'}</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={() => refetch()} disabled={isLoading} className="border-border">
                  <RefreshCw className={`h-4 w-4 mr-2 ${isLoading ? 'animate-spin' : ''}`} />
                  {t.refresh}
                </Button>
              </div>
              
              {/* Filters */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Filter className="h-4 w-4" />
                  <span>{language === 'de' ? 'Filter:' : 'Filters:'}</span>
                </div>
                
                {/* Status Filter */}
                <Select value={dataStatusFilter} onValueChange={setDataStatusFilter}>
                  <SelectTrigger className="w-[140px] h-9 bg-background border-border">
                    <SelectValue placeholder={language === 'de' ? 'Status' : 'Status'} />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">{language === 'de' ? 'Alle Status' : 'All Status'}</SelectItem>
                    <SelectItem value="pending">{language === 'de' ? 'Ausstehend' : 'Pending'}</SelectItem>
                    <SelectItem value="completed">{language === 'de' ? 'Abgeschlossen' : 'Completed'}</SelectItem>
                    <SelectItem value="failed">{language === 'de' ? 'Fehlgeschlagen' : 'Failed'}</SelectItem>
                    <SelectItem value="creation_failed">{language === 'de' ? 'Nicht erstellt' : 'Not Created'}</SelectItem>
                  </SelectContent>
                </Select>
                
                {/* Account Filter */}
                <Select value={dataAccountFilter} onValueChange={setDataAccountFilter}>
                  <SelectTrigger className="w-[160px] h-9 bg-background border-border">
                    <SelectValue placeholder="Account" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">{language === 'de' ? 'Alle Accounts' : 'All Accounts'}</SelectItem>
                    {uniqueReportAccounts.map(account => (
                      <SelectItem key={account} value={account}>{account}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {/* Report Type Filter */}
                <Select value={dataReportTypeFilter} onValueChange={setDataReportTypeFilter}>
                  <SelectTrigger className="w-[180px] h-9 bg-background border-border">
                    <SelectValue placeholder={language === 'de' ? 'Report-Typ' : 'Report Type'} />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">{language === 'de' ? 'Alle Typen' : 'All Types'}</SelectItem>
                    <SelectItem value="sp">Sponsored Products</SelectItem>
                    <SelectItem value="sb">Sponsored Brands</SelectItem>
                    <SelectItem value="sd">Sponsored Display</SelectItem>
                  </SelectContent>
                </Select>
                
                {/* Date From */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[140px] h-9 justify-start text-left font-normal border-border bg-background",
                        !dataDateFrom && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dataDateFrom ? format(dataDateFrom, "dd.MM.yyyy") : (language === 'de' ? 'Von' : 'From')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-popover border-border" align="start">
                    <Calendar
                      mode="single"
                      selected={dataDateFrom}
                      onSelect={setDataDateFrom}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                
                {/* Date To */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[140px] h-9 justify-start text-left font-normal border-border bg-background",
                        !dataDateTo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dataDateTo ? format(dataDateTo, "dd.MM.yyyy") : (language === 'de' ? 'Bis' : 'To')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-popover border-border" align="start">
                    <Calendar
                      mode="single"
                      selected={dataDateTo}
                      onSelect={setDataDateTo}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                
                {/* Clear Filters */}
                {hasActiveDataFilters && (
                  <Button variant="ghost" size="sm" onClick={clearDataFilters} className="h-9 px-2 text-muted-foreground hover:text-foreground">
                    <X className="h-4 w-4 mr-1" />
                    {language === 'de' ? 'Zurücksetzen' : 'Clear'}
                  </Button>
                )}
                
                {/* Results count */}
                {hasActiveDataFilters && (
                  <span className="text-sm text-muted-foreground ml-2">
                    {filteredReports.length} / {reports?.length || 0} {language === 'de' ? 'Ergebnisse' : 'results'}
                  </span>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {isLoading ? (
                <div className="flex items-center justify-center py-8 text-muted-foreground">{t.loading}</div>
              ) : filteredReports.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <CheckCircle className="h-12 w-12 mb-4 text-emerald-400" />
                  <p>{hasActiveDataFilters 
                    ? (language === 'de' ? 'Keine Reports mit diesen Filtern gefunden' : 'No reports match these filters')
                    : (language === 'de' ? 'Keine Reports in der Warteschlange' : 'No reports in queue')
                  }</p>
                </div>
              ) : (
                <div className="rounded-md border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead className="text-muted-foreground">Account</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Report-Typ' : 'Report Type'}</TableHead>
                        <TableHead className="text-muted-foreground">{t.status}</TableHead>
                        <TableHead className="text-muted-foreground text-center">{language === 'de' ? 'Versuche' : 'Attempts'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Zeitraum' : 'Period'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Erstellt' : 'Created'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Fehlermeldung' : 'Error'}</TableHead>
                        <TableHead className="text-muted-foreground text-center">{language === 'de' ? 'Aktion' : 'Action'}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredReports.map((report) => {
                        const interpretedError = interpretError(report.error_message, language);
                        const canRetry = report.status === 'failed' || report.status === 'creation_failed';
                        const isRetrying = retryingIds.has(report.id);

                        return (
                          <TableRow key={report.id} className="border-border">
                            <TableCell className="font-medium text-foreground">{report.account_name}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs border-border">{getReportTypeLabel(report.report_type)}</Badge>
                            </TableCell>
                            <TableCell>{getStatusBadge(report.status)}</TableCell>
                            <TableCell className="text-center text-muted-foreground">{report.attempts}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {format(new Date(report.start_date), 'dd.MM.yyyy')} - {format(new Date(report.end_date), 'dd.MM.yyyy')}
                            </TableCell>
                            <TableCell className="text-sm text-muted-foreground">
                              {formatDistanceToNow(new Date(report.created_at), { addSuffix: true, locale })}
                            </TableCell>
                            <TableCell className="max-w-xs">
                              {report.error_message ? (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span className={`text-sm ${interpretedError.color} cursor-help`}>
                                        {interpretedError.icon} {interpretedError.text}
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent className="max-w-md">
                                      <p className="text-xs font-mono">{report.error_message}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {canRetry && (
                                <Button variant="ghost" size="sm" onClick={() => handleRetry(report.id)} disabled={isRetrying} className="h-8 px-2">
                                  <RotateCcw className={`h-4 w-4 ${isRetrying ? 'animate-spin' : ''}`} />
                                  <span className="ml-1 text-xs">Retry</span>
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Slack Alerts Tab */}
        <TabsContent value="slack" className="space-y-6">
          {/* Slack Stats Cards */}
          <div className="grid grid-cols-1 md:grid-cols-4 gap-4">
            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Gesamt' : 'Total'}</p>
                    <p className="text-2xl font-bold text-foreground">{alertStats.total}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-primary/10 flex items-center justify-center">
                    <Bell className="h-5 w-5 text-primary" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Gesendet' : 'Sent'}</p>
                    <p className="text-2xl font-bold text-emerald-400">{alertStats.sent}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-emerald-500/10 flex items-center justify-center">
                    <Send className="h-5 w-5 text-emerald-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Fehlgeschlagen' : 'Failed'}</p>
                    <p className="text-2xl font-bold text-red-400">{alertStats.failed}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-red-500/10 flex items-center justify-center">
                    <XCircle className="h-5 w-5 text-red-400" />
                  </div>
                </div>
              </CardContent>
            </Card>

            <Card className="bg-card border-border">
              <CardContent className="pt-6">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-muted-foreground">{language === 'de' ? 'Keine Daten' : 'No Data'}</p>
                    <p className="text-2xl font-bold text-amber-400">{alertStats.noData}</p>
                  </div>
                  <div className="h-10 w-10 rounded-full bg-amber-500/10 flex items-center justify-center">
                    <MessageSquareWarning className="h-5 w-5 text-amber-400" />
                  </div>
                </div>
              </CardContent>
            </Card>
          </div>

          {/* Slack Alerts Table */}
          <Card className="bg-card border-border">
            <CardHeader className="flex flex-col gap-4">
              <div className="flex flex-row items-center justify-between">
                <div>
                  <CardTitle className="text-foreground">{language === 'de' ? 'Slack Alert-Verlauf' : 'Slack Alert History'}</CardTitle>
                  <CardDescription>{language === 'de' ? 'Übersicht aller Slack-Benachrichtigungen' : 'Overview of all Slack notifications'}</CardDescription>
                </div>
                <Button variant="outline" size="sm" onClick={() => refetchAlerts()} disabled={alertsLoading} className="border-border">
                  <RefreshCw className={`h-4 w-4 mr-2 ${alertsLoading ? 'animate-spin' : ''}`} />
                  {t.refresh}
                </Button>
              </div>
              
              {/* Filters */}
              <div className="flex flex-wrap items-center gap-3">
                <div className="flex items-center gap-2 text-sm text-muted-foreground">
                  <Filter className="h-4 w-4" />
                  <span>{language === 'de' ? 'Filter:' : 'Filters:'}</span>
                </div>
                
                {/* Status Filter */}
                <Select value={statusFilter} onValueChange={setStatusFilter}>
                  <SelectTrigger className="w-[140px] h-9 bg-background border-border">
                    <SelectValue placeholder={language === 'de' ? 'Status' : 'Status'} />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">{language === 'de' ? 'Alle Status' : 'All Status'}</SelectItem>
                    <SelectItem value="sent">{language === 'de' ? 'Gesendet' : 'Sent'}</SelectItem>
                    <SelectItem value="failed">{language === 'de' ? 'Fehlgeschlagen' : 'Failed'}</SelectItem>
                    <SelectItem value="pending">{language === 'de' ? 'Ausstehend' : 'Pending'}</SelectItem>
                  </SelectContent>
                </Select>
                
                {/* Account Filter */}
                <Select value={accountFilter} onValueChange={setAccountFilter}>
                  <SelectTrigger className="w-[160px] h-9 bg-background border-border">
                    <SelectValue placeholder="Account" />
                  </SelectTrigger>
                  <SelectContent className="bg-popover border-border">
                    <SelectItem value="all">{language === 'de' ? 'Alle Accounts' : 'All Accounts'}</SelectItem>
                    {uniqueAccounts.map(account => (
                      <SelectItem key={account} value={account}>{account}</SelectItem>
                    ))}
                  </SelectContent>
                </Select>
                
                {/* Date From */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[140px] h-9 justify-start text-left font-normal border-border bg-background",
                        !dateFrom && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateFrom ? format(dateFrom, "dd.MM.yyyy") : (language === 'de' ? 'Von' : 'From')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-popover border-border" align="start">
                    <Calendar
                      mode="single"
                      selected={dateFrom}
                      onSelect={setDateFrom}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                
                {/* Date To */}
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant="outline"
                      className={cn(
                        "w-[140px] h-9 justify-start text-left font-normal border-border bg-background",
                        !dateTo && "text-muted-foreground"
                      )}
                    >
                      <CalendarIcon className="mr-2 h-4 w-4" />
                      {dateTo ? format(dateTo, "dd.MM.yyyy") : (language === 'de' ? 'Bis' : 'To')}
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0 bg-popover border-border" align="start">
                    <Calendar
                      mode="single"
                      selected={dateTo}
                      onSelect={setDateTo}
                      initialFocus
                      className="p-3 pointer-events-auto"
                    />
                  </PopoverContent>
                </Popover>
                
                {/* Clear Filters */}
                {hasActiveFilters && (
                  <Button variant="ghost" size="sm" onClick={clearFilters} className="h-9 px-2 text-muted-foreground hover:text-foreground">
                    <X className="h-4 w-4 mr-1" />
                    {language === 'de' ? 'Zurücksetzen' : 'Clear'}
                  </Button>
                )}
                
                {/* Results count */}
                {hasActiveFilters && (
                  <span className="text-sm text-muted-foreground ml-2">
                    {filteredAlertHistory.length} / {alertHistory?.length || 0} {language === 'de' ? 'Ergebnisse' : 'results'}
                  </span>
                )}
              </div>
            </CardHeader>
            <CardContent>
              {alertsLoading ? (
                <div className="flex items-center justify-center py-8 text-muted-foreground">{t.loading}</div>
              ) : filteredAlertHistory.length === 0 ? (
                <div className="flex flex-col items-center justify-center py-12 text-muted-foreground">
                  <Bell className="h-12 w-12 mb-4 text-muted-foreground/50" />
                  <p>{hasActiveFilters 
                    ? (language === 'de' ? 'Keine Alerts mit diesen Filtern gefunden' : 'No alerts match these filters')
                    : (language === 'de' ? 'Keine Alerts vorhanden' : 'No alerts found')
                  }</p>
                </div>
              ) : (
                <div className="rounded-md border border-border overflow-hidden">
                  <Table>
                    <TableHeader>
                      <TableRow className="border-border hover:bg-transparent">
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Datum' : 'Date'}</TableHead>
                        <TableHead className="text-muted-foreground">Account</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Regel' : 'Rule'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Typ' : 'Type'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Alert-Typ' : 'Alert Type'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Slack Status' : 'Slack Status'}</TableHead>
                        <TableHead className="text-muted-foreground">{language === 'de' ? 'Fehler' : 'Error'}</TableHead>
                        <TableHead className="text-muted-foreground text-center">{language === 'de' ? 'Aktion' : 'Action'}</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredAlertHistory.map((alert) => {
                        const interpretedError = interpretSlackError(alert.slack_error, language);
                        const canResend = !alert.slack_sent;
                        const isResending = resendingIds.has(alert.id);

                        return (
                          <TableRow key={alert.id} className="border-border">
                            <TableCell className="text-sm text-foreground">
                              {format(new Date(alert.created_at), 'dd.MM.yyyy HH:mm', { locale })}
                            </TableCell>
                            <TableCell className="font-medium text-foreground">{alert.account_name || '-'}</TableCell>
                            <TableCell className="text-sm text-muted-foreground">{alert.rule_name || '-'}</TableCell>
                            <TableCell>
                              <Badge variant="outline" className="text-xs border-border">
                                {alert.run_type === 'scheduled' ? (language === 'de' ? 'Geplant' : 'Scheduled') : 
                                 alert.run_type === 'manual' ? (language === 'de' ? 'Manuell' : 'Manual') : 
                                 alert.run_type || '-'}
                              </Badge>
                            </TableCell>
                            <TableCell>{getAlertTypeBadge(alert)}</TableCell>
                            <TableCell>{getSlackStatusBadge(alert)}</TableCell>
                            <TableCell className="max-w-xs">
                              {interpretedError ? (
                                <TooltipProvider>
                                  <Tooltip>
                                    <TooltipTrigger asChild>
                                      <span className={`text-sm ${interpretedError.color} cursor-help`}>
                                        {interpretedError.icon} {interpretedError.text}
                                      </span>
                                    </TooltipTrigger>
                                    <TooltipContent className="max-w-md">
                                      <p className="text-xs font-mono">{alert.slack_error}</p>
                                    </TooltipContent>
                                  </Tooltip>
                                </TooltipProvider>
                              ) : (
                                <span className="text-muted-foreground">-</span>
                              )}
                            </TableCell>
                            <TableCell className="text-center">
                              {canResend && (
                                <Button variant="ghost" size="sm" onClick={() => handleResendSlack(alert.id)} disabled={isResending} className="h-8 px-2">
                                  <Send className={`h-4 w-4 ${isResending ? 'animate-spin' : ''}`} />
                                  <span className="ml-1 text-xs">{language === 'de' ? 'Senden' : 'Send'}</span>
                                </Button>
                              )}
                            </TableCell>
                          </TableRow>
                        );
                      })}
                    </TableBody>
                  </Table>
                </div>
              )}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}

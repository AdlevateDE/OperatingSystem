import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { useAccounts } from "@/hooks/useAccounts";
import { Badge } from "@/components/ui/badge";
import { CheckCircle, AlertCircle } from "lucide-react";
import { useState, useEffect } from "react";
import { supabase } from "@/integrations/supabase/client";
import { useToast } from "@/hooks/use-toast";
import { z } from "zod";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskAccountName, maskProfileId, maskUrl } from "@/lib/demoMode";
import { useLanguage } from "@/contexts/LanguageContext";
import { AccountDialog } from "@/components/AccountDialog";
import { DeleteAccountDialog } from "@/components/DeleteAccountDialog";
import { Tables } from "@/integrations/supabase/types";

type Account = Tables<"amazon_accounts">;

export default function Settings() {
  const { accounts, refetch } = useAccounts();
  const { toast } = useToast();
  const { isDemoMode } = useDemoMode();
  const { t, language } = useLanguage();
  const [slackWebhook, setSlackWebhook] = useState("");
  const [dashboardUrl, setDashboardUrl] = useState("");
  const [isLoadingSlack, setIsLoadingSlack] = useState(false);
  const [isSavingSlack, setIsSavingSlack] = useState(false);
  const [slackConfigured, setSlackConfigured] = useState(false);
  const [dashboardConfigured, setDashboardConfigured] = useState(false);
  const [currentUserId, setCurrentUserId] = useState<string | null>(null);
  
  // Account dialog state
  const [accountDialogOpen, setAccountDialogOpen] = useState(false);
  const [editingAccount, setEditingAccount] = useState<Account | null>(null);
  const [isSavingAccount, setIsSavingAccount] = useState(false);
  
  // Delete dialog state
  const [deleteDialogOpen, setDeleteDialogOpen] = useState(false);
  const [deletingAccount, setDeletingAccount] = useState<Account | null>(null);
  const [isDeletingAccount, setIsDeletingAccount] = useState(false);

  const slackWebhookSchema = z.string()
    .trim()
    .url({ message: language === 'de' ? "Bitte geben Sie eine gültige URL ein" : "Please enter a valid URL" })
    .startsWith("https://hooks.slack.com/services/", { 
      message: language === 'de' ? "Die URL muss mit 'https://hooks.slack.com/services/' beginnen" : "URL must start with 'https://hooks.slack.com/services/'"
    })
    .max(500, { message: language === 'de' ? "Die URL ist zu lang" : "URL is too long" });

  // Load current user and their Slack webhook
  useEffect(() => {
    const loadUserSettings = async () => {
      setIsLoadingSlack(true);
      try {
        const { data: { user } } = await supabase.auth.getUser();
        
        if (!user) {
          console.log('No authenticated user found');
          return;
        }

        setCurrentUserId(user.id);

        const { data, error } = await supabase
          .from('users')
          .select('slack_webhook_url, dashboard_url')
          .eq('id', user.id)
          .maybeSingle();

        if (error) throw error;

        if (data?.slack_webhook_url) {
          setSlackWebhook(data.slack_webhook_url);
          setSlackConfigured(true);
        }
        if (data?.dashboard_url) {
          setDashboardUrl(data.dashboard_url);
          setDashboardConfigured(true);
        }
      } catch (error: any) {
        console.error('Error loading Slack settings:', error);
      } finally {
        setIsLoadingSlack(false);
      }
    };

    loadUserSettings();
  }, [toast]);

  const handleSaveSlackWebhook = async () => {
    if (!currentUserId) {
      toast({
        title: t.errorLogin,
        description: t.loginRequired,
        variant: "destructive",
      });
      return;
    }

    const validation = slackWebhookSchema.safeParse(slackWebhook);
    if (!validation.success) {
      toast({
        title: t.invalidWebhookUrl,
        description: validation.error.errors[0].message,
        variant: "destructive",
      });
      return;
    }

    setIsSavingSlack(true);
    try {
      const { data: { user } } = await supabase.auth.getUser();
      const userEmail = user?.email || 'no-email@example.com';

      const { data: existingUser } = await supabase
        .from('users')
        .select('id')
        .eq('id', currentUserId)
        .maybeSingle();

      if (!existingUser) {
        const { error: insertError } = await supabase
          .from('users')
          .insert([{
            id: currentUserId,
            email: userEmail,
            slack_webhook_url: slackWebhook,
            dashboard_url: dashboardUrl || null,
          }]);

        if (insertError) throw insertError;
      } else {
        const { error: updateError } = await supabase
          .from('users')
          .update({ 
            slack_webhook_url: slackWebhook,
            dashboard_url: dashboardUrl || null,
          })
          .eq('id', currentUserId);

        if (updateError) throw updateError;
      }
      
      setDashboardConfigured(!!dashboardUrl);
      setSlackConfigured(true);
      toast({
        title: t.saved,
        description: t.slackWebhookSaved,
      });
    } catch (error: any) {
      console.error('Error saving Slack webhook:', error);
      toast({
        title: t.saveError,
        description: error.message || t.webhookSaveError,
        variant: "destructive",
      });
    } finally {
      setIsSavingSlack(false);
    }
  };

  const handleTestSlackConnection = async () => {
    if (!slackWebhook) {
      toast({
        title: t.noUrl,
        description: t.saveUrlFirst,
        variant: "destructive",
      });
      return;
    }

    try {
      const { data, error } = await supabase.functions.invoke('test-slack-webhook', {
        body: { webhook_url: slackWebhook, language, dashboard_url: dashboardUrl }
      });

      if (error) {
        throw new Error(error.message);
      }

      if (data?.success) {
        toast({
          title: t.testSuccess,
          description: t.testMessageSent,
        });
      } else {
        throw new Error(data?.error || t.slackConnectionError);
      }
    } catch (error: any) {
      toast({
        title: t.testFailed,
        description: error.message || t.slackConnectionError,
        variant: "destructive",
      });
    }
  };

  // Account handlers
  const handleAddAccount = () => {
    setEditingAccount(null);
    setAccountDialogOpen(true);
  };

  const handleEditAccount = (account: Account) => {
    setEditingAccount(account);
    setAccountDialogOpen(true);
  };

  const handleDeleteAccount = (account: Account) => {
    setDeletingAccount(account);
    setDeleteDialogOpen(true);
  };

  const handleSaveAccount = async (data: {
    account_name: string;
    profile_id: string;
    marketplace: string;
    currency_code: string;
  }) => {
    setIsSavingAccount(true);
    try {
      if (editingAccount) {
        // Update existing account
        const { error } = await supabase
          .from("amazon_accounts")
          .update({
            account_name: data.account_name,
            marketplace: data.marketplace,
            currency_code: data.currency_code,
          })
          .eq("id", editingAccount.id);

        if (error) throw error;

        toast({
          title: t.saved,
          description: t.accountUpdated,
        });
      } else {
        // Create new account
        const { error } = await supabase.from("amazon_accounts").insert({
          account_name: data.account_name,
          profile_id: data.profile_id,
          marketplace: data.marketplace,
          currency_code: data.currency_code,
        });

        if (error) throw error;

        toast({
          title: t.saved,
          description: t.accountCreated,
        });
      }

      setAccountDialogOpen(false);
      refetch();
    } catch (error: any) {
      console.error("Error saving account:", error);
      toast({
        title: t.error,
        description: editingAccount ? t.accountUpdateError : t.accountCreateError,
        variant: "destructive",
      });
    } finally {
      setIsSavingAccount(false);
    }
  };

  const handleConfirmDelete = async () => {
    if (!deletingAccount) return;
    
    setIsDeletingAccount(true);
    try {
      const { error } = await supabase
        .from("amazon_accounts")
        .delete()
        .eq("id", deletingAccount.id);

      if (error) throw error;

      toast({
        title: t.saved,
        description: t.accountDeleted,
      });

      setDeleteDialogOpen(false);
      setDeletingAccount(null);
      refetch();
    } catch (error: any) {
      console.error("Error deleting account:", error);
      toast({
        title: t.error,
        description: t.accountDeleteError,
        variant: "destructive",
      });
    } finally {
      setIsDeletingAccount(false);
    }
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-bold">{t.settingsTitle}</h1>
        <p className="text-muted-foreground mt-1">{t.settingsDesc}</p>
      </div>

      <Tabs defaultValue="accounts" className="space-y-6">
        <TabsList>
          <TabsTrigger value="accounts">{t.accountsTab}</TabsTrigger>
          <TabsTrigger value="integrations">{t.integrationsTab}</TabsTrigger>
          <TabsTrigger value="preferences">{t.preferencesTab}</TabsTrigger>
        </TabsList>

        {/* Accounts Tab */}
        <TabsContent value="accounts" className="space-y-4">
          <div className="flex justify-between items-center">
            <p className="text-sm text-muted-foreground">{t.manageAccounts}</p>
            <Button onClick={handleAddAccount}>{t.addAccount}</Button>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            {accounts.map((account) => (
              <Card key={account.id}>
                <CardHeader>
                  <div className="flex items-start justify-between">
                  <div>
                    <CardTitle className="text-lg">
                      {isDemoMode ? maskAccountName(account.account_name) : account.account_name}
                    </CardTitle>
                    <p className="text-sm text-muted-foreground mt-1">
                      Profile ID: {isDemoMode ? maskProfileId(account.profile_id) : account.profile_id}
                    </p>
                  </div>
                  <Badge variant={account.is_active ? "default" : "secondary"}>
                    {account.is_active ? t.active : t.inactive}
                  </Badge>
                  </div>
                </CardHeader>
                <CardContent>
              <div className="space-y-2 text-sm">
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t.marketplace}:</span>
                  <span className="font-medium">{account.marketplace}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t.currency}:</span>
                  <span className="font-medium">{account.currency_code}</span>
                </div>
                <div className="flex justify-between">
                  <span className="text-muted-foreground">{t.lastSyncAt}:</span>
                  <span className="font-medium">
                    {account.last_sync_at 
                      ? new Date(account.last_sync_at).toLocaleDateString(language === 'de' ? 'de-DE' : 'en-US')
                      : t.never
                    }
                  </span>
                </div>
              </div>
              <div className="flex gap-2 mt-4">
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => handleEditAccount(account)}
                >
                  {t.edit}
                </Button>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1"
                  onClick={() => handleDeleteAccount(account)}
                >
                  {t.delete}
                </Button>
              </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        {/* Integrations Tab */}
        <TabsContent value="integrations" className="space-y-6">
          {/* Slack Integration */}
          <Card>
            <CardHeader>
              <CardTitle>{t.slackIntegration}</CardTitle>
              <p className="text-sm text-muted-foreground">{t.slackDesc}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              {isLoadingSlack ? (
                <div className="text-sm text-muted-foreground">{t.loading}</div>
              ) : (
                <>
                  <div className="flex items-center gap-2 p-3 bg-muted rounded-lg">
                    {slackConfigured ? (
                      <>
                        <CheckCircle className="h-5 w-5 text-success" />
                        <span className="text-sm">{t.configured}</span>
                      </>
                    ) : (
                      <>
                        <AlertCircle className="h-5 w-5 text-warning" />
                        <span className="text-sm">{t.notConfigured}</span>
                      </>
                    )}
                  </div>
                  <div>
                    <Label htmlFor="slackWebhook">{t.webhookUrl}</Label>
                    <Input
                      id="slackWebhook"
                      type="password"
                      placeholder="https://hooks.slack.com/services/..."
                      className="mt-2"
                      value={isDemoMode ? maskUrl(slackWebhook) : slackWebhook}
                      onChange={(e) => setSlackWebhook(e.target.value)}
                      disabled={isDemoMode}
                    />
                    <p className="text-xs text-muted-foreground mt-1">{t.webhookUrlHint}</p>
                  </div>
                  <div>
                    <Label htmlFor="dashboardUrl">{t.dashboardUrlLabel}</Label>
                    <Input
                      id="dashboardUrl"
                      type="url"
                      placeholder={t.dashboardUrlPlaceholder}
                      className="mt-2"
                      value={isDemoMode ? maskUrl(dashboardUrl) : dashboardUrl}
                      onChange={(e) => setDashboardUrl(e.target.value)}
                      disabled={isDemoMode}
                    />
                    <p className="text-xs text-muted-foreground mt-1">{t.dashboardUrlHint}</p>
                  </div>
                  <div className="flex gap-2">
                    <Button onClick={handleSaveSlackWebhook} disabled={isSavingSlack}>
                      {isSavingSlack ? t.saving : t.saveSettings}
                    </Button>
                    <Button 
                      variant="outline" 
                      onClick={handleTestSlackConnection}
                      disabled={!slackConfigured}
                    >
                      {t.testConnection}
                    </Button>
                  </div>
                </>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* Preferences Tab */}
        <TabsContent value="preferences" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>{t.defaultSettings}</CardTitle>
              <p className="text-sm text-muted-foreground">{t.defaultSettingsDesc}</p>
            </CardHeader>
            <CardContent className="space-y-4">
              <div>
                <Label htmlFor="defaultPeriod">{t.defaultComparisonPeriod}</Label>
                <Input
                  id="defaultPeriod"
                  defaultValue={t.last7Days}
                  className="mt-2"
                  disabled
                />
              </div>
              <Button>{t.saveSettings}</Button>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      {/* Account Dialog */}
      <AccountDialog
        open={accountDialogOpen}
        onOpenChange={setAccountDialogOpen}
        account={editingAccount}
        onSave={handleSaveAccount}
        isSaving={isSavingAccount}
      />

      {/* Delete Account Dialog */}
      <DeleteAccountDialog
        open={deleteDialogOpen}
        onOpenChange={setDeleteDialogOpen}
        account={deletingAccount}
        onConfirm={handleConfirmDelete}
        isDeleting={isDeletingAccount}
      />
    </div>
  );
}

import { Bell, AlertCircle, TrendingDown, Users } from "lucide-react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { useAlerts } from "@/hooks/useAlerts";
import { useAlertRules } from "@/hooks/useAlertRules";
import { useAccounts } from "@/hooks/useAccounts";
import { formatDistanceToNow } from "date-fns";
import { de, enUS } from "date-fns/locale";
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer } from "recharts";
import { StatusBadge } from "@/components/StatusBadge";
import { AlertResultsTable } from "@/components/AlertResultsTable";
import { useDemoMode } from "@/contexts/DemoModeContext";
import { maskAccountName } from "@/lib/demoMode";
import { useLanguage } from "@/contexts/LanguageContext";

export default function Dashboard() {
  const { accounts } = useAccounts();
  const { rules } = useAlertRules({ isActive: true });
  const { alerts, todayAlerts, criticalAlerts, trendData } = useAlerts();
  const { isDemoMode } = useDemoMode();
  const { t, language } = useLanguage();

  const dateLocale = language === 'de' ? de : enUS;
  const recentAlerts = alerts.slice(0, 5);

  const metricCards = [
    {
      title: t.activeRules,
      value: rules.length,
      icon: Bell,
      gradient: "bg-gradient-success",
    },
    {
      title: t.alertsToday,
      value: todayAlerts,
      icon: AlertCircle,
      gradient: "bg-gradient-primary",
    },
    {
      title: t.criticalDeviations,
      value: criticalAlerts,
      icon: TrendingDown,
      gradient: "bg-gradient-danger",
    },
    {
      title: t.monitoredAccounts,
      value: accounts.length,
      icon: Users,
      gradient: "bg-gradient-purple",
    },
  ];

  return (
    <div className="space-y-6">
      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {metricCards.map((card) => (
          <Card key={card.title} className={`${card.gradient} text-white border-0`}>
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm font-medium opacity-90">{card.title}</p>
                  <p className="text-3xl font-bold mt-2">{card.value}</p>
                </div>
                <card.icon className="h-12 w-12 opacity-80" />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Alert Results Table */}
      <AlertResultsTable />

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Recent Alerts */}
        <Card>
          <CardHeader>
            <CardTitle>{t.recentAlerts}</CardTitle>
          </CardHeader>
          <CardContent>
            {recentAlerts.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">{t.noAlertsYet}</p>
            ) : (
              <div className="space-y-4">
                {recentAlerts.map((alert: any) => (
                  <div key={alert.id} className="flex items-center justify-between p-3 rounded-lg border">
                    <div className="flex-1">
                      <p className="font-medium text-sm">
                        {isDemoMode 
                          ? maskAccountName(alert.amazon_accounts?.account_name) 
                          : (alert.amazon_accounts?.account_name || t.unknownAccount)}
                      </p>
                      <p className="text-xs text-muted-foreground mt-1">
                        {formatDistanceToNow(new Date(alert.created_at), { addSuffix: true, locale: dateLocale })}
                      </p>
                    </div>
                    <div className="text-right">
                      <p className="text-sm font-medium">{alert.total_items || 0} {t.campaigns}</p>
                      <StatusBadge status={alert.slack_sent ? "sent" : "pending"} />
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Alerts Trend Chart */}
        <Card>
          <CardHeader>
            <CardTitle>{t.alertsTrend}</CardTitle>
          </CardHeader>
          <CardContent>
            <ResponsiveContainer width="100%" height={300}>
              <LineChart data={trendData}>
                <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                <XAxis
                  dataKey="date"
                  stroke="hsl(var(--muted-foreground))"
                  tickFormatter={(value) => new Date(value).toLocaleDateString(language === 'de' ? 'de-DE' : 'en-US', { weekday: "short" })}
                />
                <YAxis stroke="hsl(var(--muted-foreground))" />
                <Tooltip
                  contentStyle={{
                    backgroundColor: "hsl(var(--card))",
                    border: "1px solid hsl(var(--border))",
                    borderRadius: "0.5rem",
                  }}
                />
                <Line
                  type="monotone"
                  dataKey="count"
                  stroke="hsl(var(--primary))"
                  strokeWidth={2}
                  dot={{ fill: "hsl(var(--primary))" }}
                />
              </LineChart>
            </ResponsiveContainer>
          </CardContent>
        </Card>
      </div>
    </div>
  );
}

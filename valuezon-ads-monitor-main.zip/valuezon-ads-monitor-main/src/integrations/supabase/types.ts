export type Json =
  | string
  | number
  | boolean
  | null
  | { [key: string]: Json | undefined }
  | Json[]

export type Database = {
  // Allows to automatically instantiate createClient with right options
  // instead of createClient<Database, { PostgrestVersion: 'XX' }>(URL, KEY)
  __InternalSupabase: {
    PostgrestVersion: "13.0.5"
  }
  public: {
    Tables: {
      account_users: {
        Row: {
          account_id: string
          created_at: string | null
          id: string
          role: Database["public"]["Enums"]["account_role"]
          user_id: string
        }
        Insert: {
          account_id: string
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["account_role"]
          user_id: string
        }
        Update: {
          account_id?: string
          created_at?: string | null
          id?: string
          role?: Database["public"]["Enums"]["account_role"]
          user_id?: string
        }
        Relationships: [
          {
            foreignKeyName: "account_users_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "amazon_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "account_users_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      alert_items: {
        Row: {
          account_name: string | null
          alert_direction: string | null
          alert_id: string
          campaign_id: string | null
          campaign_name: string | null
          comparison_period: string
          created_at: string | null
          current_value: number
          date: string
          deviation_percent: number
          external_campaign_id: number | null
          id: string
          metric_name: string
          reference_value: number
          rule_name: string | null
          threshold_percent: number
        }
        Insert: {
          account_name?: string | null
          alert_direction?: string | null
          alert_id: string
          campaign_id?: string | null
          campaign_name?: string | null
          comparison_period: string
          created_at?: string | null
          current_value: number
          date: string
          deviation_percent: number
          external_campaign_id?: number | null
          id?: string
          metric_name: string
          reference_value: number
          rule_name?: string | null
          threshold_percent: number
        }
        Update: {
          account_name?: string | null
          alert_direction?: string | null
          alert_id?: string
          campaign_id?: string | null
          campaign_name?: string | null
          comparison_period?: string
          created_at?: string | null
          current_value?: number
          date?: string
          deviation_percent?: number
          external_campaign_id?: number | null
          id?: string
          metric_name?: string
          reference_value?: number
          rule_name?: string | null
          threshold_percent?: number
        }
        Relationships: [
          {
            foreignKeyName: "alert_items_alert_id_fkey"
            columns: ["alert_id"]
            isOneToOne: false
            referencedRelation: "alerts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_items_campaign_id_fkey"
            columns: ["campaign_id"]
            isOneToOne: false
            referencedRelation: "campaigns"
            referencedColumns: ["id"]
          },
        ]
      }
      alert_rule_changes: {
        Row: {
          change_type: string
          changed_at: string | null
          changed_by: string | null
          changed_by_email: string | null
          changes: Json | null
          id: string
          new_values: Json | null
          previous_values: Json | null
          rule_id: string | null
          rule_name: string
        }
        Insert: {
          change_type: string
          changed_at?: string | null
          changed_by?: string | null
          changed_by_email?: string | null
          changes?: Json | null
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          rule_id?: string | null
          rule_name: string
        }
        Update: {
          change_type?: string
          changed_at?: string | null
          changed_by?: string | null
          changed_by_email?: string | null
          changes?: Json | null
          id?: string
          new_values?: Json | null
          previous_values?: Json | null
          rule_id?: string | null
          rule_name?: string
        }
        Relationships: [
          {
            foreignKeyName: "alert_rule_changes_changed_by_fkey"
            columns: ["changed_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_rule_changes_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "alert_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      alert_rules: {
        Row: {
          account_id: string
          account_ids: string[] | null
          alert_conditions: Json | null
          alert_conditions_logic: string | null
          alert_direction: string | null
          campaign_filters: Json | null
          campaign_filters_logic: string | null
          campaign_selection_mode: string | null
          campaign_types: string[] | null
          check_frequency: string
          check_schedule: string | null
          comparison_period: string
          created_at: string | null
          created_by: string | null
          id: string
          is_active: boolean | null
          last_check_at: string | null
          last_edited_at: string | null
          last_edited_by: string | null
          metric_name: string
          rule_name: string
          selected_campaigns: string[] | null
          threshold_percent: number
          threshold_type: string | null
          updated_at: string | null
        }
        Insert: {
          account_id: string
          account_ids?: string[] | null
          alert_conditions?: Json | null
          alert_conditions_logic?: string | null
          alert_direction?: string | null
          campaign_filters?: Json | null
          campaign_filters_logic?: string | null
          campaign_selection_mode?: string | null
          campaign_types?: string[] | null
          check_frequency?: string
          check_schedule?: string | null
          comparison_period: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          last_check_at?: string | null
          last_edited_at?: string | null
          last_edited_by?: string | null
          metric_name: string
          rule_name: string
          selected_campaigns?: string[] | null
          threshold_percent: number
          threshold_type?: string | null
          updated_at?: string | null
        }
        Update: {
          account_id?: string
          account_ids?: string[] | null
          alert_conditions?: Json | null
          alert_conditions_logic?: string | null
          alert_direction?: string | null
          campaign_filters?: Json | null
          campaign_filters_logic?: string | null
          campaign_selection_mode?: string | null
          campaign_types?: string[] | null
          check_frequency?: string
          check_schedule?: string | null
          comparison_period?: string
          created_at?: string | null
          created_by?: string | null
          id?: string
          is_active?: boolean | null
          last_check_at?: string | null
          last_edited_at?: string | null
          last_edited_by?: string | null
          metric_name?: string
          rule_name?: string
          selected_campaigns?: string[] | null
          threshold_percent?: number
          threshold_type?: string | null
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "alert_rules_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "amazon_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_rules_created_by_fkey"
            columns: ["created_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alert_rules_last_edited_by_fkey"
            columns: ["last_edited_by"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      alerts: {
        Row: {
          account_id: string
          alert_date: string
          created_at: string | null
          id: string
          is_all_clear: boolean | null
          is_no_data: boolean | null
          rule_id: string | null
          run_type: string | null
          sent_at: string | null
          sheets_url: string | null
          slack_error: string | null
          slack_sent: boolean | null
          total_items: number | null
          triggered_by_email: string | null
        }
        Insert: {
          account_id: string
          alert_date: string
          created_at?: string | null
          id?: string
          is_all_clear?: boolean | null
          is_no_data?: boolean | null
          rule_id?: string | null
          run_type?: string | null
          sent_at?: string | null
          sheets_url?: string | null
          slack_error?: string | null
          slack_sent?: boolean | null
          total_items?: number | null
          triggered_by_email?: string | null
        }
        Update: {
          account_id?: string
          alert_date?: string
          created_at?: string | null
          id?: string
          is_all_clear?: boolean | null
          is_no_data?: boolean | null
          rule_id?: string | null
          run_type?: string | null
          sent_at?: string | null
          sheets_url?: string | null
          slack_error?: string | null
          slack_sent?: boolean | null
          total_items?: number | null
          triggered_by_email?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "alerts_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "amazon_accounts"
            referencedColumns: ["id"]
          },
          {
            foreignKeyName: "alerts_rule_id_fkey"
            columns: ["rule_id"]
            isOneToOne: false
            referencedRelation: "alert_rules"
            referencedColumns: ["id"]
          },
        ]
      }
      amazon_accounts: {
        Row: {
          account_name: string
          created_at: string | null
          currency_code: string
          id: string
          is_active: boolean | null
          last_sync_at: string | null
          marketplace: string
          profile_id: string
          refresh_token_key: string | null
          updated_at: string | null
          user_id: string | null
        }
        Insert: {
          account_name: string
          created_at?: string | null
          currency_code?: string
          id?: string
          is_active?: boolean | null
          last_sync_at?: string | null
          marketplace: string
          profile_id: string
          refresh_token_key?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Update: {
          account_name?: string
          created_at?: string | null
          currency_code?: string
          id?: string
          is_active?: boolean | null
          last_sync_at?: string | null
          marketplace?: string
          profile_id?: string
          refresh_token_key?: string | null
          updated_at?: string | null
          user_id?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "amazon_accounts_user_id_fkey"
            columns: ["user_id"]
            isOneToOne: false
            referencedRelation: "users"
            referencedColumns: ["id"]
          },
        ]
      }
      campaign_metrics_sb: {
        Row: {
          add_to_cart: number | null
          campaign_budget_amount: number | null
          campaign_budget_currency_code: string | null
          campaign_budget_type: string | null
          campaign_id: number | null
          campaign_name: string | null
          campaign_status: string | null
          clicks: number | null
          cost: number | null
          cost_type: string | null
          created_at: string | null
          date: string
          detail_page_views: number | null
          id: string
          impressions: number | null
          new_to_brand_purchases: number | null
          new_to_brand_sales: number | null
          new_to_brand_units_sold: number | null
          profile_id: string | null
          purchases: number | null
          sales: number | null
          top_of_search_impression_share: number | null
          unique_key: string | null
          units_sold: number | null
          updated_at: string | null
          video_5_second_views: number | null
          video_complete_views: number | null
        }
        Insert: {
          add_to_cart?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          clicks?: number | null
          cost?: number | null
          cost_type?: string | null
          created_at?: string | null
          date: string
          detail_page_views?: number | null
          id?: string
          impressions?: number | null
          new_to_brand_purchases?: number | null
          new_to_brand_sales?: number | null
          new_to_brand_units_sold?: number | null
          profile_id?: string | null
          purchases?: number | null
          sales?: number | null
          top_of_search_impression_share?: number | null
          unique_key?: string | null
          units_sold?: number | null
          updated_at?: string | null
          video_5_second_views?: number | null
          video_complete_views?: number | null
        }
        Update: {
          add_to_cart?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          clicks?: number | null
          cost?: number | null
          cost_type?: string | null
          created_at?: string | null
          date?: string
          detail_page_views?: number | null
          id?: string
          impressions?: number | null
          new_to_brand_purchases?: number | null
          new_to_brand_sales?: number | null
          new_to_brand_units_sold?: number | null
          profile_id?: string | null
          purchases?: number | null
          sales?: number | null
          top_of_search_impression_share?: number | null
          unique_key?: string | null
          units_sold?: number | null
          updated_at?: string | null
          video_5_second_views?: number | null
          video_complete_views?: number | null
        }
        Relationships: []
      }
      campaign_metrics_sd: {
        Row: {
          add_to_cart_clicks: number | null
          campaign_budget_amount: number | null
          campaign_budget_currency_code: string | null
          campaign_budget_type: string | null
          campaign_id: number | null
          campaign_name: string | null
          campaign_status: string | null
          clicks: number | null
          cost: number | null
          cost_type: string | null
          created_at: string | null
          date: string
          detail_page_views_clicks: number | null
          id: string
          impressions: number | null
          new_to_brand_purchases_clicks: number | null
          new_to_brand_sales_clicks: number | null
          new_to_brand_units_sold_clicks: number | null
          profile_id: string | null
          purchases_clicks: number | null
          sales_clicks: number | null
          unique_key: string | null
          units_sold_clicks: number | null
          updated_at: string | null
          video_5_second_views: number | null
          video_complete_views: number | null
        }
        Insert: {
          add_to_cart_clicks?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          clicks?: number | null
          cost?: number | null
          cost_type?: string | null
          created_at?: string | null
          date: string
          detail_page_views_clicks?: number | null
          id?: string
          impressions?: number | null
          new_to_brand_purchases_clicks?: number | null
          new_to_brand_sales_clicks?: number | null
          new_to_brand_units_sold_clicks?: number | null
          profile_id?: string | null
          purchases_clicks?: number | null
          sales_clicks?: number | null
          unique_key?: string | null
          units_sold_clicks?: number | null
          updated_at?: string | null
          video_5_second_views?: number | null
          video_complete_views?: number | null
        }
        Update: {
          add_to_cart_clicks?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          clicks?: number | null
          cost?: number | null
          cost_type?: string | null
          created_at?: string | null
          date?: string
          detail_page_views_clicks?: number | null
          id?: string
          impressions?: number | null
          new_to_brand_purchases_clicks?: number | null
          new_to_brand_sales_clicks?: number | null
          new_to_brand_units_sold_clicks?: number | null
          profile_id?: string | null
          purchases_clicks?: number | null
          sales_clicks?: number | null
          unique_key?: string | null
          units_sold_clicks?: number | null
          updated_at?: string | null
          video_5_second_views?: number | null
          video_complete_views?: number | null
        }
        Relationships: []
      }
      campaign_metrics_sp: {
        Row: {
          acos_clicks_14d: number | null
          campaign_budget_amount: number | null
          campaign_budget_currency_code: string | null
          campaign_budget_type: string | null
          campaign_id: number | null
          campaign_name: string | null
          campaign_status: string | null
          click_through_rate: number | null
          clicks: number | null
          cost: number | null
          cost_per_click: number | null
          created_at: string | null
          date: string
          id: string
          impressions: number | null
          profile_id: string | null
          purchases_14d: number | null
          roas_clicks_14d: number | null
          sales_14d: number | null
          top_of_search_impression_share: number | null
          unique_key: string | null
          units_sold_clicks_14d: number | null
          updated_at: string | null
        }
        Insert: {
          acos_clicks_14d?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          click_through_rate?: number | null
          clicks?: number | null
          cost?: number | null
          cost_per_click?: number | null
          created_at?: string | null
          date: string
          id?: string
          impressions?: number | null
          profile_id?: string | null
          purchases_14d?: number | null
          roas_clicks_14d?: number | null
          sales_14d?: number | null
          top_of_search_impression_share?: number | null
          unique_key?: string | null
          units_sold_clicks_14d?: number | null
          updated_at?: string | null
        }
        Update: {
          acos_clicks_14d?: number | null
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_id?: number | null
          campaign_name?: string | null
          campaign_status?: string | null
          click_through_rate?: number | null
          clicks?: number | null
          cost?: number | null
          cost_per_click?: number | null
          created_at?: string | null
          date?: string
          id?: string
          impressions?: number | null
          profile_id?: string | null
          purchases_14d?: number | null
          roas_clicks_14d?: number | null
          sales_14d?: number | null
          top_of_search_impression_share?: number | null
          unique_key?: string | null
          units_sold_clicks_14d?: number | null
          updated_at?: string | null
        }
        Relationships: []
      }
      campaigns: {
        Row: {
          account_id: string
          campaign_budget_amount: number | null
          campaign_budget_currency_code: string | null
          campaign_budget_type: string | null
          campaign_name: string
          campaign_status: string | null
          campaign_type: string
          created_at: string | null
          external_campaign_id: string
          id: string
          updated_at: string | null
        }
        Insert: {
          account_id: string
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_name: string
          campaign_status?: string | null
          campaign_type: string
          created_at?: string | null
          external_campaign_id: string
          id?: string
          updated_at?: string | null
        }
        Update: {
          account_id?: string
          campaign_budget_amount?: number | null
          campaign_budget_currency_code?: string | null
          campaign_budget_type?: string | null
          campaign_name?: string
          campaign_status?: string | null
          campaign_type?: string
          created_at?: string | null
          external_campaign_id?: string
          id?: string
          updated_at?: string | null
        }
        Relationships: [
          {
            foreignKeyName: "campaigns_account_id_fkey"
            columns: ["account_id"]
            isOneToOne: false
            referencedRelation: "amazon_accounts"
            referencedColumns: ["id"]
          },
        ]
      }
      cleanup_trigger: {
        Row: {
          id: number
          last_run: string | null
        }
        Insert: {
          id?: number
          last_run?: string | null
        }
        Update: {
          id?: number
          last_run?: string | null
        }
        Relationships: []
      }
      function_runs: {
        Row: {
          created_at: string
          duration_ms: number | null
          error_message: string | null
          error_stack: string | null
          finished_at: string | null
          function_name: string
          id: string
          metadata: Json | null
          started_at: string
          status: string
          trigger_source: string | null
        }
        Insert: {
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          error_stack?: string | null
          finished_at?: string | null
          function_name: string
          id?: string
          metadata?: Json | null
          started_at?: string
          status?: string
          trigger_source?: string | null
        }
        Update: {
          created_at?: string
          duration_ms?: number | null
          error_message?: string | null
          error_stack?: string | null
          finished_at?: string | null
          function_name?: string
          id?: string
          metadata?: Json | null
          started_at?: string
          status?: string
          trigger_source?: string | null
        }
        Relationships: []
      }
      pending_reports: {
        Row: {
          attempts: number
          batch_id: string | null
          completed_at: string | null
          created_at: string
          download_url: string | null
          end_date: string
          error_message: string | null
          id: string
          last_attempt_at: string | null
          profile_id: string
          report_id: string
          report_type: string | null
          start_date: string
          status: string
          trigger_alert_check: boolean | null
        }
        Insert: {
          attempts?: number
          batch_id?: string | null
          completed_at?: string | null
          created_at?: string
          download_url?: string | null
          end_date: string
          error_message?: string | null
          id?: string
          last_attempt_at?: string | null
          profile_id: string
          report_id: string
          report_type?: string | null
          start_date: string
          status?: string
          trigger_alert_check?: boolean | null
        }
        Update: {
          attempts?: number
          batch_id?: string | null
          completed_at?: string | null
          created_at?: string
          download_url?: string | null
          end_date?: string
          error_message?: string | null
          id?: string
          last_attempt_at?: string | null
          profile_id?: string
          report_id?: string
          report_type?: string | null
          start_date?: string
          status?: string
          trigger_alert_check?: boolean | null
        }
        Relationships: []
      }
      users: {
        Row: {
          created_at: string | null
          dashboard_url: string | null
          email: string
          full_name: string | null
          id: string
          slack_webhook_url: string | null
          updated_at: string | null
        }
        Insert: {
          created_at?: string | null
          dashboard_url?: string | null
          email: string
          full_name?: string | null
          id?: string
          slack_webhook_url?: string | null
          updated_at?: string | null
        }
        Update: {
          created_at?: string | null
          dashboard_url?: string | null
          email?: string
          full_name?: string | null
          id?: string
          slack_webhook_url?: string | null
          updated_at?: string | null
        }
        Relationships: []
      }
    }
    Views: {
      [_ in never]: never
    }
    Functions: {
      delete_duplicates_spcampaigns: { Args: never; Returns: undefined }
      delete_last15days_spcampaigns: { Args: { p: Json }; Returns: Json }
      has_account_access: { Args: { _account_id: string }; Returns: boolean }
      has_account_editor_or_owner: {
        Args: { _account_id: string }
        Returns: boolean
      }
      is_account_owner: {
        Args: { _account_id: string; _user_id?: string }
        Returns: boolean
      }
    }
    Enums: {
      account_role: "owner" | "editor" | "viewer"
    }
    CompositeTypes: {
      [_ in never]: never
    }
  }
}

type DatabaseWithoutInternals = Omit<Database, "__InternalSupabase">

type DefaultSchema = DatabaseWithoutInternals[Extract<keyof Database, "public">]

export type Tables<
  DefaultSchemaTableNameOrOptions extends
    | keyof (DefaultSchema["Tables"] & DefaultSchema["Views"])
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
        DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? (DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"] &
      DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Views"])[TableName] extends {
      Row: infer R
    }
    ? R
    : never
  : DefaultSchemaTableNameOrOptions extends keyof (DefaultSchema["Tables"] &
        DefaultSchema["Views"])
    ? (DefaultSchema["Tables"] &
        DefaultSchema["Views"])[DefaultSchemaTableNameOrOptions] extends {
        Row: infer R
      }
      ? R
      : never
    : never

export type TablesInsert<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Insert: infer I
    }
    ? I
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Insert: infer I
      }
      ? I
      : never
    : never

export type TablesUpdate<
  DefaultSchemaTableNameOrOptions extends
    | keyof DefaultSchema["Tables"]
    | { schema: keyof DatabaseWithoutInternals },
  TableName extends DefaultSchemaTableNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"]
    : never = never,
> = DefaultSchemaTableNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaTableNameOrOptions["schema"]]["Tables"][TableName] extends {
      Update: infer U
    }
    ? U
    : never
  : DefaultSchemaTableNameOrOptions extends keyof DefaultSchema["Tables"]
    ? DefaultSchema["Tables"][DefaultSchemaTableNameOrOptions] extends {
        Update: infer U
      }
      ? U
      : never
    : never

export type Enums<
  DefaultSchemaEnumNameOrOptions extends
    | keyof DefaultSchema["Enums"]
    | { schema: keyof DatabaseWithoutInternals },
  EnumName extends DefaultSchemaEnumNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"]
    : never = never,
> = DefaultSchemaEnumNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[DefaultSchemaEnumNameOrOptions["schema"]]["Enums"][EnumName]
  : DefaultSchemaEnumNameOrOptions extends keyof DefaultSchema["Enums"]
    ? DefaultSchema["Enums"][DefaultSchemaEnumNameOrOptions]
    : never

export type CompositeTypes<
  PublicCompositeTypeNameOrOptions extends
    | keyof DefaultSchema["CompositeTypes"]
    | { schema: keyof DatabaseWithoutInternals },
  CompositeTypeName extends PublicCompositeTypeNameOrOptions extends {
    schema: keyof DatabaseWithoutInternals
  }
    ? keyof DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"]
    : never = never,
> = PublicCompositeTypeNameOrOptions extends {
  schema: keyof DatabaseWithoutInternals
}
  ? DatabaseWithoutInternals[PublicCompositeTypeNameOrOptions["schema"]]["CompositeTypes"][CompositeTypeName]
  : PublicCompositeTypeNameOrOptions extends keyof DefaultSchema["CompositeTypes"]
    ? DefaultSchema["CompositeTypes"][PublicCompositeTypeNameOrOptions]
    : never

export const Constants = {
  public: {
    Enums: {
      account_role: ["owner", "editor", "viewer"],
    },
  },
} as const

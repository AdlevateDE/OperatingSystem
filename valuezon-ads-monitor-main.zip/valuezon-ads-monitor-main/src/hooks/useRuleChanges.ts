import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface RuleChange {
  id: string;
  rule_id: string | null;
  rule_name: string;
  changed_by: string | null;
  changed_by_email: string | null;
  changed_at: string;
  change_type: "created" | "updated" | "deleted";
  changes: Record<string, any> | null;
  previous_values: Record<string, any> | null;
  new_values: Record<string, any> | null;
}

export function useRuleChanges(ruleId?: string) {
  const queryClient = useQueryClient();

  const { data: changes = [], isLoading } = useQuery({
    queryKey: ["ruleChanges", ruleId],
    queryFn: async () => {
      let query = supabase
        .from("alert_rule_changes")
        .select("*")
        .order("changed_at", { ascending: false });

      if (ruleId) {
        query = query.eq("rule_id", ruleId);
      }

      const { data, error } = await query.limit(100);
      if (error) throw error;
      return data as RuleChange[];
    },
  });

  const logChange = useMutation({
    mutationFn: async ({
      ruleId,
      ruleName,
      changeType,
      previousValues,
      newValues,
    }: {
      ruleId?: string;
      ruleName: string;
      changeType: "created" | "updated" | "deleted";
      previousValues?: Record<string, any>;
      newValues?: Record<string, any>;
    }) => {
      const { data: session } = await supabase.auth.getSession();
      const userId = session?.session?.user?.id;
      const userEmail = session?.session?.user?.email;

      // Calculate what changed
      const changes: Record<string, { from: any; to: any }> = {};
      if (previousValues && newValues) {
        const allKeys = new Set([
          ...Object.keys(previousValues),
          ...Object.keys(newValues),
        ]);
        allKeys.forEach((key) => {
          if (JSON.stringify(previousValues[key]) !== JSON.stringify(newValues[key])) {
            changes[key] = {
              from: previousValues[key],
              to: newValues[key],
            };
          }
        });
      }

      const { error } = await supabase.from("alert_rule_changes").insert({
        rule_id: ruleId || null,
        rule_name: ruleName,
        changed_by: userId,
        changed_by_email: userEmail,
        change_type: changeType,
        changes: Object.keys(changes).length > 0 ? changes : null,
        previous_values: previousValues || null,
        new_values: newValues || null,
      });

      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["ruleChanges"] });
    },
  });

  return {
    changes,
    isLoading,
    logChange,
  };
}

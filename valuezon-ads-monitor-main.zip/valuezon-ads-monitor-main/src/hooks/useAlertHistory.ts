import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface AlertHistoryItem {
  id: string;
  alert_date: string;
  is_all_clear: boolean | null;
  is_no_data: boolean | null;
  slack_sent: boolean | null;
  sent_at: string | null;
  slack_error: string | null;
  run_type: string | null;
  total_items: number | null;
  created_at: string;
  account_name: string | null;
  rule_name: string | null;
}

export function useAlertHistory() {
  return useQuery({
    queryKey: ['alert-history'],
    queryFn: async () => {
      const { data, error } = await supabase
        .from('alerts')
        .select(`
          id,
          alert_date,
          is_all_clear,
          is_no_data,
          slack_sent,
          sent_at,
          slack_error,
          run_type,
          total_items,
          created_at,
          amazon_accounts(account_name),
          alert_rules(rule_name)
        `)
        .order('created_at', { ascending: false })
        .limit(100);
      
      if (error) throw error;
      
      // Flatten the nested objects
      return (data || []).map(item => ({
        id: item.id,
        alert_date: item.alert_date,
        is_all_clear: item.is_all_clear,
        is_no_data: item.is_no_data,
        slack_sent: item.slack_sent,
        sent_at: item.sent_at,
        slack_error: item.slack_error,
        run_type: item.run_type,
        total_items: item.total_items,
        created_at: item.created_at,
        account_name: (item.amazon_accounts as any)?.account_name || null,
        rule_name: (item.alert_rules as any)?.rule_name || null,
      })) as AlertHistoryItem[];
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });
}

export function useAlertHistoryStats() {
  const { data: alerts, isLoading } = useAlertHistory();
  
  const stats = {
    total: alerts?.length || 0,
    sent: alerts?.filter(a => a.slack_sent).length || 0,
    failed: alerts?.filter(a => !a.slack_sent && a.slack_error).length || 0,
    pending: alerts?.filter(a => !a.slack_sent && !a.slack_error).length || 0,
    noData: alerts?.filter(a => a.is_no_data).length || 0,
  };
  
  return { stats, isLoading };
}

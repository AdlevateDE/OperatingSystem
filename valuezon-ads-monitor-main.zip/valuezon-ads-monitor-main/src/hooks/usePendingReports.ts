import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

export interface PendingReport {
  id: string;
  profile_id: string;
  report_id: string;
  report_type: string | null;
  status: string;
  attempts: number;
  error_message: string | null;
  start_date: string;
  end_date: string;
  created_at: string;
  last_attempt_at: string | null;
  completed_at: string | null;
  batch_id: string | null;
  account_name?: string;
}

export function usePendingReports() {
  const { data: reports, isLoading, refetch } = useQuery({
    queryKey: ["pending-reports"],
    queryFn: async () => {
      // First get pending reports
      const { data: pendingReports, error: reportsError } = await supabase
        .from("pending_reports")
        .select("*")
        .order("created_at", { ascending: false })
        .limit(100);

      if (reportsError) throw reportsError;

      // Get all accounts to map profile_id to account_name
      const { data: accounts, error: accountsError } = await supabase
        .from("amazon_accounts")
        .select("profile_id, account_name");

      if (accountsError) throw accountsError;

      // Create a map for quick lookup
      const accountMap = new Map(
        accounts?.map((a) => [a.profile_id, a.account_name]) || []
      );

      // Enrich reports with account names
      const enrichedReports: PendingReport[] = (pendingReports || []).map((report) => ({
        ...report,
        account_name: accountMap.get(report.profile_id) || report.profile_id,
      }));

      return enrichedReports;
    },
    refetchInterval: 30000, // Refresh every 30 seconds
  });

  // Calculate stats
  const stats = {
    pending: reports?.filter((r) => r.status === "pending").length || 0,
    completed: reports?.filter((r) => r.status === "completed").length || 0,
    failed: reports?.filter((r) => r.status === "failed").length || 0,
    total: reports?.length || 0,
  };

  return {
    reports: reports || [],
    stats,
    isLoading,
    refetch,
  };
}

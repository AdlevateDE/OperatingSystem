import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { startOfDay, endOfDay, subDays } from "date-fns";

interface UseAlertsOptions {
  accountId?: string | null;
  startDate?: Date;
  endDate?: Date;
}

export function useAlerts(options: UseAlertsOptions = {}) {
  const { accountId, startDate, endDate } = options;

  const { data: alerts = [], isLoading } = useQuery({
    queryKey: ["alerts", accountId, startDate, endDate],
    queryFn: async () => {
      let query = supabase
        .from("alerts")
        .select(`
          *,
          amazon_accounts(account_name, marketplace),
          alert_rules(rule_name),
          alert_items(*)
        `)
        .order("created_at", { ascending: false });

      if (accountId) {
        query = query.eq("account_id", accountId);
      }
      if (startDate) {
        query = query.gte("alert_date", startOfDay(startDate).toISOString());
      }
      if (endDate) {
        query = query.lte("alert_date", endOfDay(endDate).toISOString());
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  // Dashboard metrics
  const { data: todayAlerts = 0 } = useQuery({
    queryKey: ["alertsToday", accountId],
    queryFn: async () => {
      const today = new Date().toISOString().split("T")[0];
      let query = supabase
        .from("alerts")
        .select("id", { count: "exact", head: true })
        .eq("alert_date", today);

      if (accountId) {
        query = query.eq("account_id", accountId);
      }

      const { count, error } = await query;
      if (error) throw error;
      return count || 0;
    },
  });

  const { data: criticalAlerts = 0 } = useQuery({
    queryKey: ["criticalAlerts", accountId],
    queryFn: async () => {
      let query = supabase
        .from("alert_items")
        .select("id", { count: "exact", head: true })
        .gte("deviation_percent", 30);

      if (accountId) {
        const { data: accountAlerts } = await supabase
          .from("alerts")
          .select("id")
          .eq("account_id", accountId);
        
        if (accountAlerts && accountAlerts.length > 0) {
          const alertIds = accountAlerts.map(a => a.id);
          query = query.in("alert_id", alertIds);
        }
      }

      const { count, error } = await query;
      if (error) throw error;
      return count || 0;
    },
  });

  // Trend data for last 7 days
  const { data: trendData = [] } = useQuery({
    queryKey: ["alertsTrend", accountId],
    queryFn: async () => {
      const days = Array.from({ length: 7 }, (_, i) => {
        const date = subDays(new Date(), 6 - i);
        return date.toISOString().split("T")[0];
      });

      const results = await Promise.all(
        days.map(async (date) => {
          let query = supabase
            .from("alerts")
            .select("id", { count: "exact", head: true })
            .eq("alert_date", date);

          if (accountId) {
            query = query.eq("account_id", accountId);
          }

          const { count } = await query;
          return { date, count: count || 0 };
        })
      );

      return results;
    },
  });

  return {
    alerts,
    todayAlerts,
    criticalAlerts,
    trendData,
    isLoading,
  };
}

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables, TablesInsert, TablesUpdate } from "@/integrations/supabase/types";
import { toast } from "sonner";

type AlertRule = Tables<"alert_rules">;
type AlertRuleInsert = TablesInsert<"alert_rules">;
type AlertRuleUpdate = TablesUpdate<"alert_rules">;

interface UseAlertRulesOptions {
  accountId?: string | null;
  metric?: string;
  isActive?: boolean;
}

async function logRuleChange(
  ruleId: string | null,
  ruleName: string,
  changeType: "created" | "updated" | "deleted",
  previousValues?: Record<string, any>,
  newValues?: Record<string, any>
) {
  const { data: session } = await supabase.auth.getSession();
  const userId = session?.session?.user?.id;
  const userEmail = session?.session?.user?.email;

  // Calculate what changed
  const changes: Record<string, { from: any; to: any }> = {};
  if (previousValues && newValues) {
    const allKeys = new Set([
      ...Object.keys(previousValues),
      ...Object.keys(newValues),
    ]);
    allKeys.forEach((key) => {
      if (JSON.stringify(previousValues[key]) !== JSON.stringify(newValues[key])) {
        changes[key] = {
          from: previousValues[key],
          to: newValues[key],
        };
      }
    });
  }

  await supabase.from("alert_rule_changes").insert({
    rule_id: ruleId,
    rule_name: ruleName,
    changed_by: userId,
    changed_by_email: userEmail,
    change_type: changeType,
    changes: Object.keys(changes).length > 0 ? changes : null,
    previous_values: previousValues || null,
    new_values: newValues || null,
  });
}

export function useAlertRules(options: UseAlertRulesOptions = {}) {
  const queryClient = useQueryClient();

  const { data: rules = [], isLoading } = useQuery({
    queryKey: ["alertRules", options],
    queryFn: async () => {
      let query = supabase
        .from("alert_rules")
        .select(`
          *, 
          amazon_accounts(account_name, marketplace, profile_id),
          created_by_user:users!alert_rules_created_by_fkey(email, full_name),
          last_edited_by_user:users!alert_rules_last_edited_by_fkey(email, full_name)
        `)
        .order("created_at", { ascending: false });

      if (options.accountId) {
        query = query.eq("account_id", options.accountId);
      }
      if (options.metric) {
        query = query.eq("metric_name", options.metric);
      }
      if (options.isActive !== undefined) {
        query = query.eq("is_active", options.isActive);
      }

      const { data, error } = await query;
      if (error) throw error;
      return data;
    },
  });

  const createRule = useMutation({
    mutationFn: async (newRule: AlertRuleInsert) => {
      const { data: session } = await supabase.auth.getSession();
      const userId = session?.session?.user?.id;

      const ruleWithOwner = {
        ...newRule,
        created_by: userId,
        last_edited_by: userId,
        last_edited_at: new Date().toISOString(),
      };

      const { data, error } = await supabase.from("alert_rules").insert(ruleWithOwner).select().single();
      if (error) throw error;

      // Log the creation
      await logRuleChange(data.id, data.rule_name, "created", undefined, ruleWithOwner);

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alertRules"] });
      queryClient.invalidateQueries({ queryKey: ["ruleChanges"] });
      toast.success("Alert rule created successfully");
    },
    onError: (error: Error) => {
      toast.error(`Failed to create rule: ${error.message}`);
    },
  });

  const updateRule = useMutation({
    mutationFn: async ({ id, updates, previousValues }: { id: string; updates: AlertRuleUpdate; previousValues?: Record<string, any> }) => {
      const { data: session } = await supabase.auth.getSession();
      const userId = session?.session?.user?.id;

      const updatesWithEditor = {
        ...updates,
        last_edited_by: userId,
        last_edited_at: new Date().toISOString(),
      };

      const { data, error } = await supabase
        .from("alert_rules")
        .update(updatesWithEditor)
        .eq("id", id)
        .select()
        .single();
      if (error) throw error;

      // Log the update
      await logRuleChange(id, data.rule_name, "updated", previousValues, updatesWithEditor);

      return data;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alertRules"] });
      queryClient.invalidateQueries({ queryKey: ["ruleChanges"] });
      toast.success("Alert rule updated successfully");
    },
    onError: (error: Error) => {
      toast.error(`Failed to update rule: ${error.message}`);
    },
  });

  const deleteRule = useMutation({
    mutationFn: async ({ id, ruleName }: { id: string; ruleName: string }) => {
      // Log the deletion first (before the rule is gone)
      await logRuleChange(id, ruleName, "deleted");

      const { error } = await supabase.from("alert_rules").delete().eq("id", id);
      if (error) throw error;
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alertRules"] });
      queryClient.invalidateQueries({ queryKey: ["ruleChanges"] });
      toast.success("Alert rule deleted successfully");
    },
    onError: (error: Error) => {
      toast.error(`Failed to delete rule: ${error.message}`);
    },
  });

  const toggleRuleStatus = useMutation({
    mutationFn: async ({ id, isActive, ruleName }: { id: string; isActive: boolean; ruleName?: string }) => {
      const { data: session } = await supabase.auth.getSession();
      const userId = session?.session?.user?.id;

      const { error } = await supabase
        .from("alert_rules")
        .update({ 
          is_active: isActive,
          last_edited_by: userId,
          last_edited_at: new Date().toISOString(),
        })
        .eq("id", id);
      if (error) throw error;

      // Log status change
      if (ruleName) {
        await logRuleChange(id, ruleName, "updated", { is_active: !isActive }, { is_active: isActive });
      }
    },
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ["alertRules"] });
      queryClient.invalidateQueries({ queryKey: ["ruleChanges"] });
    },
    onError: (error: Error) => {
      toast.error(`Failed to update rule status: ${error.message}`);
    },
  });

  return {
    rules,
    isLoading,
    createRule,
    updateRule,
    deleteRule,
    toggleRuleStatus,
  };
}

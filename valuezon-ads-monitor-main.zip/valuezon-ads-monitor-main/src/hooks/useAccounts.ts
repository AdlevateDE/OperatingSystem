import { useState, useEffect } from "react";
import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";
import { Tables } from "@/integrations/supabase/types";

type Account = Tables<"amazon_accounts">;

export function useAccounts() {
  const [session, setSession] = useState<any>(null);

  // Get current session
  useEffect(() => {
    supabase.auth.getSession().then(({ data: { session } }) => {
      setSession(session);
    });

    const { data: { subscription } } = supabase.auth.onAuthStateChange((_event, session) => {
      setSession(session);
    });

    return () => subscription.unsubscribe();
  }, []);

  const { data: accounts = [], isLoading, refetch, error } = useQuery({
    queryKey: ["accounts", session?.user?.id],
    queryFn: async () => {
      const { data, error } = await supabase
        .from("amazon_accounts")
        .select("*")
        .eq("is_active", true)
        .order("account_name");

      if (error) {
        console.error("Error fetching accounts:", error);
        throw error;
      }
      return data as Account[];
    },
    enabled: !!session?.user,
    staleTime: 5 * 60 * 1000, // 5 minutes - prevents unnecessary refetches
    gcTime: 10 * 60 * 1000, // 10 minutes cache time
  });

  // Get most recent sync time from all accounts
  const lastSync = accounts.length > 0 
    ? accounts.reduce((latest, account) => {
        if (!account.last_sync_at) return latest;
        if (!latest) return account.last_sync_at;
        return account.last_sync_at > latest ? account.last_sync_at : latest;
      }, null as string | null)
    : null;

  return {
    accounts,
    isLoading,
    refetch,
    lastSync,
    error,
  };
}

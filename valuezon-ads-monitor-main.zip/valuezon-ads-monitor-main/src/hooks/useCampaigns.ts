import { useQuery } from "@tanstack/react-query";
import { supabase } from "@/integrations/supabase/client";

interface UseCampaignsOptions {
  accountId?: string;
  accountIds?: string[];
  enabled?: boolean;
}

export function useCampaigns({ accountId, accountIds, enabled = true }: UseCampaignsOptions = {}) {
  // Support both single accountId and multiple accountIds
  const resolvedAccountIds = accountIds?.length ? accountIds : (accountId ? [accountId] : []);
  
  return useQuery({
    queryKey: ["campaigns", resolvedAccountIds],
    queryFn: async () => {
      if (resolvedAccountIds.length === 0) return [];

      // Get profile_ids for all accounts
      const { data: accounts, error: accountError } = await supabase
        .from("amazon_accounts")
        .select("profile_id")
        .in("id", resolvedAccountIds);

      if (accountError || !accounts?.length) {
        console.error("Error fetching accounts:", accountError);
        return [];
      }

      const profileIds = accounts.map(a => a.profile_id).filter(Boolean);
      if (profileIds.length === 0) return [];

      // Get distinct campaign names from campaign_metrics_sp for all profile_ids
      const { data: campaigns, error: campaignsError } = await supabase
        .from("campaign_metrics_sp")
        .select("campaign_name")
        .in("profile_id", profileIds)
        .not("campaign_name", "is", null);

      if (campaignsError) {
        console.error("Error fetching campaigns:", campaignsError);
        return [];
      }

      // Get unique campaign names and sort them
      const uniqueNames = [...new Set(campaigns.map((c) => c.campaign_name))].filter(Boolean).sort();
      return uniqueNames as string[];
    },
    enabled: enabled && resolvedAccountIds.length > 0,
  });
}

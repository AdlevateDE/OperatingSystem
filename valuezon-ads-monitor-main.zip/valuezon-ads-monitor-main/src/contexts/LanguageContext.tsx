import React, { createContext, useContext, useState, useEffect, ReactNode } from 'react';

type Language = 'de' | 'en';

interface Translations {
  // Navigation
  dashboard: string;
  alertRules: string;
  alertHistory: string;
  settings: string;
  
  // Actions
  logout: string;
  collapse: string;
  demoMode: string;
  demoOff: string;
  refresh: string;
  save: string;
  cancel: string;
  delete: string;
  edit: string;
  create: string;
  search: string;
  filter: string;
  back: string;
  next: string;
  close: string;
  
  // Common
  lastSync: string;
  loading: string;
  loggedOut: string;
  loggedOutDesc: string;
  logoutError: string;
  all: string;
  none: string;
  unknown: string;
  demo: string;
  language: string;
  german: string;
  english: string;
  status: string;
  actions: string;
  
  // Alert Rules Page
  manageRules: string;
  checkAllRules: string;
  checking: string;
  createNewRule: string;
  createFirstRule: string;
  noRulesYet: string;
  searchRules: string;
  allMetrics: string;
  onlyActive: string;
  rules: string;
  changeHistory: string;
  ruleName: string;
  account: string;
  accounts: string;
  campaignType: string;
  metric: string;
  threshold: string;
  period: string;
  lastEdited: string;
  createdBy: string;
  syncAndCheck: string;
  syncing: string;
  duplicate: string;
  showHistory: string;
  
  // Metrics
  cost: string;
  costNoConversions: string;
  clicks: string;
  impressions: string;
  cpc: string;
  ctr: string;
  acos: string;
  
  // Comparison Periods
  yesterday: string;
  sameDayLastWeek: string;
  last7Days: string;
  last14Days: string;
  last30Days: string;
  
  // Rule Builder
  editRule: string;
  createRule: string;
  ruleNamePlaceholder: string;
  selectAccounts: string;
  selectAccountsPlaceholder: string;
  accountsSelected: string;
  campaignTypes: string;
  sponsoredProducts: string;
  sponsoredBrands: string;
  sponsoredDisplay: string;
  atLeastOneCampaignType: string;
  automaticCheck: string;
  automaticCheckDesc: string;
  morning: string;
  evening: string;
  checkTime: string;
  onlyMorning: string;
  onlyEvening: string;
  twiceDaily: string;
  tipHighBudget: string;
  notificationChannels: string;
  summary: string;
  rule: string;
  campaignSelection: string;
  allCampaigns: string;
  campaignsIncluded: string;
  campaignsExcluded: string;
  conditions: string;
  saveRule: string;
  
  // Campaign Selection
  selectCampaigns: string;
  onlySelected: string;
  excludeSelected: string;
  selectAll: string;
  clearAll: string;
  campaignsAvailable: string;
  searchCampaigns: string;
  
  // Alert Conditions
  alertConditions: string;
  addCondition: string;
  maxConditions: string;
  increases: string;
  decreases: string;
  both: string;
  percentage: string;
  absolute: string;
  absoluteDeviation: string;
  comparisonPeriod: string;
  
  // Freshness Dialog
  dataUpToDate: string;
  dataSyncRequired: string;
  noDataAvailable: string;
  updatedMinutesAgo: string;
  statusUnknown: string;
  checkNow: string;
  resync: string;
  immediateAnalysis: string;
  fetchNewData: string;
  
  // Toast Messages
  ruleDuplicated: string;
  ruleDuplicatedDesc: string;
  errorDuplicating: string;
  couldNotDuplicate: string;
  dataSyncStarted: string;
  dataSyncStartedDesc: string;
  error: string;
  alertCheckComplete: string;
  campaignsExceedThreshold: string;
  slackSent: string;
  allCampaignsGreen: string;
  alertsChecked: string;
  alertCheckError: string;
  
  // Misc
  deleteRuleConfirm: string;
  wouldYouLike: string;
  
  // Dashboard
  activeRules: string;
  alertsToday: string;
  criticalDeviations: string;
  monitoredAccounts: string;
  recentAlerts: string;
  viewAll: string;
  noAlertsYet: string;
  campaigns: string;
  alertsTrend: string;
  unknownAccount: string;
  
  // Alert History
  alertHistoryTitle: string;
  loadingAlerts: string;
  noAlertsFound: string;
  noAlertsPeriod: string;
  ruleLabel: string;
  campaignsAffected: string;
  alertDate: string;
  export: string;
  viewDetails: string;
  
  // Settings
  settingsTitle: string;
  settingsDesc: string;
  accountsTab: string;
  integrationsTab: string;
  preferencesTab: string;
  manageAccounts: string;
  addAccount: string;
  marketplace: string;
  currency: string;
  lastSyncAt: string;
  never: string;
  active: string;
  inactive: string;
  slackIntegration: string;
  slackDesc: string;
  configured: string;
  notConfigured: string;
  webhookUrl: string;
  webhookUrlHint: string;
  dashboardUrlLabel: string;
  dashboardUrlPlaceholder: string;
  dashboardUrlHint: string;
  saveSettings: string;
  saving: string;
  testConnection: string;
  defaultSettings: string;
  defaultSettingsDesc: string;
  defaultComparisonPeriod: string;
  
  // Settings Toast Messages
  errorLogin: string;
  loginRequired: string;
  invalidWebhookUrl: string;
  saved: string;
  slackWebhookSaved: string;
  saveError: string;
  webhookSaveError: string;
  noUrl: string;
  saveUrlFirst: string;
  testSuccess: string;
  testMessageSent: string;
  testFailed: string;
  slackConnectionError: string;
  
  // Duplicate Rule Dialog
  duplicateRule: string;
  duplicateRuleDesc: string;
  targetAccounts: string;
  others: string;
  selectAccountsDropdown: string;
  accountSelected: string;
  accountsSelectedPlural: string;
  searchAccount: string;
  noAccountsFound: string;
  original: string;
  selectAtLeastOneAccount: string;
  duplicating: string;
  
  // Account Management
  editAccount: string;
  accountName: string;
  deleteAccount: string;
  deleteAccountConfirm: string;
  deleting: string;
  accountCreated: string;
  accountUpdated: string;
  accountDeleted: string;
  accountCreateError: string;
  accountUpdateError: string;
  accountDeleteError: string;
}

const translations: Record<Language, Translations> = {
  de: {
    // Navigation
    dashboard: 'Dashboard',
    alertRules: 'Alert-Regeln',
    alertHistory: 'Alert-Verlauf',
    settings: 'Einstellungen',
    
    // Actions
    logout: 'Abmelden',
    collapse: 'Einklappen',
    demoMode: 'Demo-Modus',
    demoOff: 'Demo aus',
    refresh: 'Aktualisieren',
    save: 'Speichern',
    cancel: 'Abbrechen',
    delete: 'Löschen',
    edit: 'Bearbeiten',
    create: 'Erstellen',
    search: 'Suchen',
    filter: 'Filtern',
    back: 'Zurück',
    next: 'Weiter',
    close: 'Schließen',
    
    // Common
    lastSync: 'Letzte Synchronisation',
    loading: 'Wird geladen...',
    loggedOut: 'Abgemeldet',
    loggedOutDesc: 'Sie wurden erfolgreich abgemeldet.',
    logoutError: 'Fehler beim Abmelden',
    all: 'Alle',
    none: 'Keine',
    unknown: 'Unbekannt',
    demo: 'DEMO',
    language: 'Sprache',
    german: 'Deutsch',
    english: 'Englisch',
    status: 'Status',
    actions: 'Aktionen',
    
    // Alert Rules Page
    manageRules: 'Verwalten Sie Ihre Kampagnen-Überwachungsregeln',
    checkAllRules: '🚀 Alle aktiven Regeln prüfen',
    checking: 'Wird geprüft...',
    createNewRule: 'Neue Regel erstellen',
    createFirstRule: 'Erste Regel erstellen',
    noRulesYet: 'Noch keine Regeln erstellt',
    searchRules: 'Regeln durchsuchen...',
    allMetrics: 'Alle Metriken',
    onlyActive: 'Nur aktive',
    rules: 'Regeln',
    changeHistory: 'Änderungshistorie',
    ruleName: 'Regelname',
    account: 'Account',
    accounts: 'Accounts',
    campaignType: 'Kampagnentyp',
    metric: 'Metrik',
    threshold: 'Schwellenwert',
    period: 'Zeitraum',
    lastEdited: 'Zuletzt bearbeitet',
    createdBy: 'Erstellt von',
    syncAndCheck: '▶️ Daten syncen & prüfen',
    syncing: 'Sync läuft...',
    duplicate: 'Duplizieren',
    showHistory: 'Verlauf anzeigen',
    
    // Metrics
    cost: 'Kosten',
    costNoConversions: 'Kosten ohne Conversions',
    clicks: 'Klicks',
    impressions: 'Impressionen',
    cpc: 'CPC',
    ctr: 'CTR',
    acos: 'ACoS',
    
    // Comparison Periods
    yesterday: 'Gestern',
    sameDayLastWeek: 'Gleicher Tag Vorwoche',
    last7Days: 'Letzte 7 Tage Durchschnitt',
    last14Days: 'Letzte 14 Tage Durchschnitt',
    last30Days: 'Letzte 30 Tage Durchschnitt',
    
    // Rule Builder
    editRule: 'Alert-Regel bearbeiten',
    createRule: 'Alert-Regel erstellen',
    ruleNamePlaceholder: 'z.B. Kosten-Rückgang Alert - DE Markt',
    selectAccounts: 'Accounts auswählen',
    selectAccountsPlaceholder: 'Accounts wählen...',
    accountsSelected: 'Accounts ausgewählt',
    campaignTypes: 'Kampagnentypen',
    sponsoredProducts: 'Sponsored Products',
    sponsoredBrands: 'Sponsored Brands',
    sponsoredDisplay: 'Sponsored Display',
    atLeastOneCampaignType: 'Mindestens ein Kampagnentyp muss ausgewählt sein',
    automaticCheck: 'Automatische Prüfung',
    automaticCheckDesc: 'Wählen Sie, wann Ihre Regel automatisch geprüft werden soll.',
    morning: 'Morgens',
    evening: 'Abends',
    checkTime: 'Prüfungszeitpunkt',
    onlyMorning: '🌅 Nur morgens (11:00 Uhr)',
    onlyEvening: '🌆 Nur abends (17:00 Uhr)',
    twiceDaily: '🔄 Zweimal täglich (11:00 & 17:00 Uhr)',
    tipHighBudget: '💡 Tipp: Für Prime Days oder High-Budget-Accounts empfehlen wir zweimal täglich',
    notificationChannels: 'Benachrichtigungskanäle',
    summary: 'Zusammenfassung',
    rule: 'Regel',
    campaignSelection: 'Kampagnenauswahl',
    allCampaigns: 'Alle Kampagnen',
    campaignsIncluded: 'Kampagnen eingeschlossen',
    campaignsExcluded: 'Kampagnen ausgeschlossen',
    conditions: 'Bedingungen',
    saveRule: 'Regel speichern',
    
    // Campaign Selection
    selectCampaigns: 'Kampagnen auswählen',
    onlySelected: 'Nur ausgewählte',
    excludeSelected: 'Ausgewählte ausschließen',
    selectAll: 'Alle',
    clearAll: 'Keine',
    campaignsAvailable: 'Kampagnen verfügbar',
    searchCampaigns: 'Kampagnen suchen...',
    
    // Alert Conditions
    alertConditions: 'Alert-Bedingungen',
    addCondition: 'Bedingung hinzufügen',
    maxConditions: 'Maximal 3 Bedingungen',
    increases: 'steigt',
    decreases: 'sinkt',
    both: 'ändert sich',
    percentage: 'Prozentual',
    absolute: 'Absolut',
    absoluteDeviation: 'Absolute Abweichung',
    comparisonPeriod: 'Vergleichszeitraum',
    
    // Freshness Dialog
    dataUpToDate: 'Daten aktuell',
    dataSyncRequired: 'Daten-Synchronisation erforderlich',
    noDataAvailable: 'Keine Daten vorhanden',
    updatedMinutesAgo: 'vor {minutes} Min. aktualisiert',
    statusUnknown: 'Status unbekannt',
    checkNow: 'Jetzt prüfen',
    resync: 'Neu synchronisieren',
    immediateAnalysis: 'Sofortige Analyse mit bestehenden Daten ohne API-Call',
    fetchNewData: 'Aktuelle Daten von Amazon holen (2-10 Min.)',
    
    // Toast Messages
    ruleDuplicated: 'Regel dupliziert',
    ruleDuplicatedDesc: '"{name}" wurde erfolgreich für {count} Account(s) erstellt.',
    errorDuplicating: 'Fehler beim Duplizieren',
    couldNotDuplicate: 'Die Regel konnte nicht dupliziert werden.',
    dataSyncStarted: 'Daten-Sync gestartet',
    dataSyncStartedDesc: '{types} Daten werden synchronisiert. Ergebnisse in 2-10 Min.',
    error: 'Fehler',
    alertCheckComplete: 'Alert-Check abgeschlossen',
    campaignsExceedThreshold: '{count} Kampagnen überschreiten Schwellenwerte. Slack-Benachrichtigung wurde gesendet.',
    slackSent: 'Slack-Benachrichtigung wurde gesendet.',
    allCampaignsGreen: 'Alle Kampagnen im grünen Bereich! ✅',
    alertsChecked: 'Alerts geprüft',
    alertCheckError: 'Fehler bei Alert-Check',
    
    // Misc
    deleteRuleConfirm: 'Möchten Sie diese Regel wirklich löschen?',
    wouldYouLike: 'Möchten Sie:',
    
    // Dashboard
    activeRules: 'Aktive Regeln',
    alertsToday: 'Alerts heute',
    criticalDeviations: 'Kritische Abweichungen',
    monitoredAccounts: 'Überwachte Accounts',
    recentAlerts: 'Letzte Alerts',
    viewAll: 'Alle anzeigen',
    noAlertsYet: 'Noch keine Alerts',
    campaigns: 'Kampagnen',
    alertsTrend: 'Alert-Trend (Letzte 7 Tage)',
    unknownAccount: 'Unbekannter Account',
    
    // Alert History
    alertHistoryTitle: 'Alert-Verlauf',
    loadingAlerts: 'Alerts werden geladen...',
    noAlertsFound: 'Keine Alerts gefunden',
    noAlertsPeriod: 'In diesem Zeitraum wurden keine Alerts ausgelöst',
    ruleLabel: 'Regel:',
    campaignsAffected: 'Betroffene Kampagnen:',
    alertDate: 'Alert-Datum:',
    export: 'Exportieren',
    viewDetails: 'Details anzeigen',
    
    // Settings
    settingsTitle: 'Einstellungen',
    settingsDesc: 'Verwalten Sie Ihre Accounts, Integrationen und Einstellungen',
    accountsTab: 'Accounts',
    integrationsTab: 'Integrationen',
    preferencesTab: 'Einstellungen',
    manageAccounts: 'Verwalten Sie Ihre Amazon Advertising Accounts',
    addAccount: 'Account hinzufügen',
    marketplace: 'Marketplace',
    currency: 'Währung',
    lastSyncAt: 'Letzte Synchronisation',
    never: 'Nie',
    active: 'Aktiv',
    inactive: 'Inaktiv',
    slackIntegration: 'Slack Integration',
    slackDesc: 'Empfangen Sie Alert-Benachrichtigungen in Ihrem Slack Workspace',
    configured: 'Konfiguriert',
    notConfigured: 'Nicht konfiguriert',
    webhookUrl: 'Webhook URL',
    webhookUrlHint: 'Die URL wird verschlüsselt gespeichert und ist nur für Sie sichtbar',
    dashboardUrlLabel: 'Dashboard URL (optional)',
    dashboardUrlPlaceholder: 'https://ihre-domain.lovable.app/',
    dashboardUrlHint: 'Wird in Slack-Benachrichtigungen als Link angezeigt (nur bei tatsächlichen Alerts)',
    saveSettings: 'Einstellungen speichern',
    saving: 'Wird gespeichert...',
    testConnection: 'Verbindung testen',
    defaultSettings: 'Standardeinstellungen',
    defaultSettingsDesc: 'Legen Sie Standardwerte für neue Alert-Regeln fest',
    defaultComparisonPeriod: 'Standard-Vergleichszeitraum',
    
    // Settings Toast Messages
    errorLogin: 'Fehler',
    loginRequired: 'Sie müssen angemeldet sein, um Einstellungen zu speichern.',
    invalidWebhookUrl: 'Ungültige Webhook URL',
    saved: 'Gespeichert',
    slackWebhookSaved: 'Slack Webhook URL wurde erfolgreich gespeichert.',
    saveError: 'Fehler beim Speichern',
    webhookSaveError: 'Die Webhook URL konnte nicht gespeichert werden.',
    noUrl: 'Keine URL',
    saveUrlFirst: 'Bitte speichern Sie zuerst eine Webhook URL.',
    testSuccess: 'Test erfolgreich',
    testMessageSent: 'Die Test-Nachricht wurde an Slack gesendet.',
    testFailed: 'Test fehlgeschlagen',
    slackConnectionError: 'Die Verbindung zu Slack konnte nicht hergestellt werden.',
    
    // Duplicate Rule Dialog
    duplicateRule: 'Regel duplizieren',
    duplicateRuleDesc: 'Erstellen Sie eine Kopie dieser Regel für ausgewählte Accounts.',
    targetAccounts: 'Ziel-Accounts',
    others: 'Andere',
    selectAccountsDropdown: 'Accounts auswählen...',
    accountSelected: 'Account ausgewählt',
    accountsSelectedPlural: 'Accounts ausgewählt',
    searchAccount: 'Account suchen...',
    noAccountsFound: 'Keine Accounts gefunden',
    original: 'Original',
    selectAtLeastOneAccount: 'Bitte wählen Sie mindestens einen Account aus.',
    duplicating: 'Wird dupliziert...',
    
    // Account Management
    editAccount: 'Account bearbeiten',
    accountName: 'Account-Name',
    deleteAccount: 'Account löschen',
    deleteAccountConfirm: 'Sind Sie sicher, dass Sie den Account "{name}" löschen möchten? Diese Aktion kann nicht rückgängig gemacht werden.',
    deleting: 'Wird gelöscht...',
    accountCreated: 'Account erfolgreich erstellt.',
    accountUpdated: 'Account erfolgreich aktualisiert.',
    accountDeleted: 'Account erfolgreich gelöscht.',
    accountCreateError: 'Fehler beim Erstellen des Accounts.',
    accountUpdateError: 'Fehler beim Aktualisieren des Accounts.',
    accountDeleteError: 'Fehler beim Löschen des Accounts.',
  },
  en: {
    // Navigation
    dashboard: 'Dashboard',
    alertRules: 'Alert Rules',
    alertHistory: 'Alert History',
    settings: 'Settings',
    
    // Actions
    logout: 'Logout',
    collapse: 'Collapse',
    demoMode: 'Demo Mode',
    demoOff: 'Demo Off',
    refresh: 'Refresh',
    save: 'Save',
    cancel: 'Cancel',
    delete: 'Delete',
    edit: 'Edit',
    create: 'Create',
    search: 'Search',
    filter: 'Filter',
    back: 'Back',
    next: 'Next',
    close: 'Close',
    
    // Common
    lastSync: 'Last sync',
    loading: 'Loading...',
    loggedOut: 'Logged out',
    loggedOutDesc: 'You have been successfully logged out.',
    logoutError: 'Logout error',
    all: 'All',
    none: 'None',
    unknown: 'Unknown',
    demo: 'DEMO',
    language: 'Language',
    german: 'German',
    english: 'English',
    status: 'Status',
    actions: 'Actions',
    
    // Alert Rules Page
    manageRules: 'Manage your campaign monitoring rules',
    checkAllRules: '🚀 Check all active rules',
    checking: 'Checking...',
    createNewRule: 'Create new rule',
    createFirstRule: 'Create first rule',
    noRulesYet: 'No rules created yet',
    searchRules: 'Search rules...',
    allMetrics: 'All Metrics',
    onlyActive: 'Active only',
    rules: 'Rules',
    changeHistory: 'Change History',
    ruleName: 'Rule Name',
    account: 'Account',
    accounts: 'Accounts',
    campaignType: 'Campaign Type',
    metric: 'Metric',
    threshold: 'Threshold',
    period: 'Period',
    lastEdited: 'Last Edited',
    createdBy: 'Created by',
    syncAndCheck: '▶️ Sync data & check',
    syncing: 'Syncing...',
    duplicate: 'Duplicate',
    showHistory: 'Show History',
    
    // Metrics
    cost: 'Cost',
    costNoConversions: 'Cost without Conversions',
    clicks: 'Clicks',
    impressions: 'Impressions',
    cpc: 'CPC',
    ctr: 'CTR',
    acos: 'ACoS',
    
    // Comparison Periods
    yesterday: 'Yesterday',
    sameDayLastWeek: 'Same day last week',
    last7Days: 'Last 7 days average',
    last14Days: 'Last 14 days average',
    last30Days: 'Last 30 days average',
    
    // Rule Builder
    editRule: 'Edit Alert Rule',
    createRule: 'Create Alert Rule',
    ruleNamePlaceholder: 'e.g. Cost Drop Alert - US Market',
    selectAccounts: 'Select Accounts',
    selectAccountsPlaceholder: 'Select accounts...',
    accountsSelected: 'accounts selected',
    campaignTypes: 'Campaign Types',
    sponsoredProducts: 'Sponsored Products',
    sponsoredBrands: 'Sponsored Brands',
    sponsoredDisplay: 'Sponsored Display',
    atLeastOneCampaignType: 'At least one campaign type must be selected',
    automaticCheck: 'Automatic Check',
    automaticCheckDesc: 'Choose when your rule should be automatically checked.',
    morning: 'Morning',
    evening: 'Evening',
    checkTime: 'Check Time',
    onlyMorning: '🌅 Morning only (11:00 AM)',
    onlyEvening: '🌆 Evening only (5:00 PM)',
    twiceDaily: '🔄 Twice daily (11:00 AM & 5:00 PM)',
    tipHighBudget: '💡 Tip: For Prime Days or high-budget accounts, we recommend twice daily',
    notificationChannels: 'Notification Channels',
    summary: 'Summary',
    rule: 'Rule',
    campaignSelection: 'Campaign Selection',
    allCampaigns: 'All Campaigns',
    campaignsIncluded: 'campaigns included',
    campaignsExcluded: 'campaigns excluded',
    conditions: 'Conditions',
    saveRule: 'Save Rule',
    
    // Campaign Selection
    selectCampaigns: 'Select Campaigns',
    onlySelected: 'Only selected',
    excludeSelected: 'Exclude selected',
    selectAll: 'All',
    clearAll: 'None',
    campaignsAvailable: 'campaigns available',
    searchCampaigns: 'Search campaigns...',
    
    // Alert Conditions
    alertConditions: 'Alert Conditions',
    addCondition: 'Add Condition',
    maxConditions: 'Maximum 3 conditions',
    increases: 'increases',
    decreases: 'decreases',
    both: 'changes',
    percentage: 'Percentage',
    absolute: 'Absolute',
    absoluteDeviation: 'Absolute Deviation',
    comparisonPeriod: 'Comparison Period',
    
    // Freshness Dialog
    dataUpToDate: 'Data up to date',
    dataSyncRequired: 'Data sync required',
    noDataAvailable: 'No data available',
    updatedMinutesAgo: 'updated {minutes} min. ago',
    statusUnknown: 'Status unknown',
    checkNow: 'Check now',
    resync: 'Re-sync',
    immediateAnalysis: 'Immediate analysis with existing data without API call',
    fetchNewData: 'Fetch current data from Amazon (2-10 min.)',
    
    // Toast Messages
    ruleDuplicated: 'Rule duplicated',
    ruleDuplicatedDesc: '"{name}" was successfully created for {count} account(s).',
    errorDuplicating: 'Error duplicating',
    couldNotDuplicate: 'The rule could not be duplicated.',
    dataSyncStarted: 'Data sync started',
    dataSyncStartedDesc: '{types} data is being synchronized. Results in 2-10 min.',
    error: 'Error',
    alertCheckComplete: 'Alert check complete',
    campaignsExceedThreshold: '{count} campaigns exceed thresholds. Slack notification sent.',
    slackSent: 'Slack notification sent.',
    allCampaignsGreen: 'All campaigns in green! ✅',
    alertsChecked: 'Alerts checked',
    alertCheckError: 'Alert check error',
    
    // Misc
    deleteRuleConfirm: 'Are you sure you want to delete this rule?',
    wouldYouLike: 'Would you like to:',
    
    // Dashboard
    activeRules: 'Active Rules',
    alertsToday: 'Alerts Today',
    criticalDeviations: 'Critical Deviations',
    monitoredAccounts: 'Monitored Accounts',
    recentAlerts: 'Recent Alerts',
    viewAll: 'View All',
    noAlertsYet: 'No alerts yet',
    campaigns: 'campaigns',
    alertsTrend: 'Alerts Trend (Last 7 Days)',
    unknownAccount: 'Unknown Account',
    
    // Alert History
    alertHistoryTitle: 'Alert History',
    loadingAlerts: 'Loading alerts...',
    noAlertsFound: 'No alerts found',
    noAlertsPeriod: 'No alerts were triggered during this period',
    ruleLabel: 'Rule:',
    campaignsAffected: 'Campaigns Affected:',
    alertDate: 'Alert Date:',
    export: 'Export',
    viewDetails: 'View Details',
    
    // Settings
    settingsTitle: 'Settings',
    settingsDesc: 'Manage your accounts, integrations and settings',
    accountsTab: 'Accounts',
    integrationsTab: 'Integrations',
    preferencesTab: 'Preferences',
    manageAccounts: 'Manage your Amazon Advertising Accounts',
    addAccount: 'Add Account',
    marketplace: 'Marketplace',
    currency: 'Currency',
    lastSyncAt: 'Last Sync',
    never: 'Never',
    active: 'Active',
    inactive: 'Inactive',
    slackIntegration: 'Slack Integration',
    slackDesc: 'Receive alert notifications in your Slack workspace',
    configured: 'Configured',
    notConfigured: 'Not configured',
    webhookUrl: 'Webhook URL',
    webhookUrlHint: 'The URL is encrypted and only visible to you',
    dashboardUrlLabel: 'Dashboard URL (optional)',
    dashboardUrlPlaceholder: 'https://your-domain.lovable.app/',
    dashboardUrlHint: 'Will be displayed as a link in Slack notifications (only for actual alerts)',
    saveSettings: 'Save Settings',
    saving: 'Saving...',
    testConnection: 'Test Connection',
    defaultSettings: 'Default Settings',
    defaultSettingsDesc: 'Set default values for new alert rules',
    defaultComparisonPeriod: 'Default Comparison Period',
    
    // Settings Toast Messages
    errorLogin: 'Error',
    loginRequired: 'You must be logged in to save settings.',
    invalidWebhookUrl: 'Invalid Webhook URL',
    saved: 'Saved',
    slackWebhookSaved: 'Slack Webhook URL was saved successfully.',
    saveError: 'Save Error',
    webhookSaveError: 'The Webhook URL could not be saved.',
    noUrl: 'No URL',
    saveUrlFirst: 'Please save a Webhook URL first.',
    testSuccess: 'Test successful',
    testMessageSent: 'The test message was sent to Slack.',
    testFailed: 'Test failed',
    slackConnectionError: 'Could not connect to Slack.',
    
    // Duplicate Rule Dialog
    duplicateRule: 'Duplicate Rule',
    duplicateRuleDesc: 'Create a copy of this rule for selected accounts.',
    targetAccounts: 'Target Accounts',
    others: 'Others',
    selectAccountsDropdown: 'Select accounts...',
    accountSelected: 'account selected',
    accountsSelectedPlural: 'accounts selected',
    searchAccount: 'Search account...',
    noAccountsFound: 'No accounts found',
    original: 'Original',
    selectAtLeastOneAccount: 'Please select at least one account.',
    duplicating: 'Duplicating...',
    
    // Account Management
    editAccount: 'Edit Account',
    accountName: 'Account Name',
    deleteAccount: 'Delete Account',
    deleteAccountConfirm: 'Are you sure you want to delete the account "{name}"? This action cannot be undone.',
    deleting: 'Deleting...',
    accountCreated: 'Account created successfully.',
    accountUpdated: 'Account updated successfully.',
    accountDeleted: 'Account deleted successfully.',
    accountCreateError: 'Error creating account.',
    accountUpdateError: 'Error updating account.',
    accountDeleteError: 'Error deleting account.',
  },
};

interface LanguageContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  t: Translations;
}

const LanguageContext = createContext<LanguageContextType | undefined>(undefined);

export function LanguageProvider({ children }: { children: ReactNode }) {
  const [language, setLanguage] = useState<Language>(() => {
    const saved = localStorage.getItem('app-language');
    return (saved as Language) || 'de';
  });

  useEffect(() => {
    localStorage.setItem('app-language', language);
  }, [language]);

  const value = {
    language,
    setLanguage,
    t: translations[language],
  };

  return (
    <LanguageContext.Provider value={value}>
      {children}
    </LanguageContext.Provider>
  );
}

export function useLanguage() {
  const context = useContext(LanguageContext);
  if (context === undefined) {
    throw new Error('useLanguage must be used within a LanguageProvider');
  }
  return context;
}

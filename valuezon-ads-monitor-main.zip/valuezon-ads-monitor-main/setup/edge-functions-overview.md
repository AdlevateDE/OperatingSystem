# Edge Functions Overview

This document describes all 23 Edge Functions in the Amazon Advertising Alert System.

## Function Categories

| Category | Count | Functions |
|----------|-------|-----------|
| Data Fetching | 6 | fetch-amazon-data-*, trigger-daily-report-* |
| Report Processing | 3 | process-pending-reports-* |
| Alert System | 3 | run-alert-checks, check-scheduled-alerts, send-slack-alert |
| Account Management | 2 | list-amazon-profiles, backfill-profile-id |
| Data Sync | 2 | sync-daily-data, trigger-14day-backfill |
| Utilities | 4 | check-data-freshness, delete-test-data, create-test-rules, retry-failed-report |
| Testing | 3 | test-slack-webhook, test-auth-third-of-life, delete_duplicates_spcampaigns |

---

## Data Fetching Functions

### 1. fetch-amazon-data-sp
**Purpose**: Fetches Sponsored Products campaign data from Amazon API

**Authentication**: Public (verify_jwt = false)

**Trigger**: Called by `sync-daily-data` and `trigger-daily-report-sp`

**Flow**:
1. Receives list of profile IDs and date range
2. Refreshes Amazon access token
3. Creates async report request for each profile
4. Stores report job in `pending_reports` table
5. Returns immediately (processing happens async)

---

### 2. fetch-amazon-data-sb
**Purpose**: Fetches Sponsored Brands campaign data from Amazon API

**Authentication**: Public (verify_jwt = false)

**Trigger**: Called by `sync-daily-data` and `trigger-daily-report-sb`

**Flow**: Same as `fetch-amazon-data-sp` but for SB campaigns

---

### 3. fetch-amazon-data-sd
**Purpose**: Fetches Sponsored Display campaign data from Amazon API

**Authentication**: Public (verify_jwt = false)

**Trigger**: Called by `sync-daily-data` and `trigger-daily-report-sd`

**Flow**: Same as `fetch-amazon-data-sp` but for SD campaigns

---

### 4. trigger-daily-report-sp
**Purpose**: Triggers SP data fetch for specific rules or all accounts

**Authentication**: Requires JWT

**Trigger**: Manual trigger from UI or cron job

**Parameters**:
- `rule_id`: Fetch data for specific rule's accounts
- `trigger_all`: Fetch for all active accounts
- `account_ids`: Fetch for specific accounts

---

### 5. trigger-daily-report-sb
**Purpose**: Triggers SB data fetch for specific rules or all accounts

**Authentication**: Requires JWT

**Flow**: Same as `trigger-daily-report-sp` but for SB campaigns

---

### 6. trigger-daily-report-sd
**Purpose**: Triggers SD data fetch for specific rules or all accounts

**Authentication**: Requires JWT

**Flow**: Same as `trigger-daily-report-sp` but for SD campaigns

---

## Report Processing Functions

### 7. process-pending-reports-sp
**Purpose**: Checks and downloads completed SP reports

**Authentication**: Public (called by cron)

**Schedule**: Every 5 minutes

**Flow**:
1. Fetches pending SP reports from database
2. Checks report status with Amazon API
3. If completed: downloads, parses, saves metrics
4. If failed: marks report as failed
5. Updates `last_sync_at` on amazon_accounts
6. Optionally triggers alert check

---

### 8. process-pending-reports-sb
**Purpose**: Checks and downloads completed SB reports

**Authentication**: Public (called by cron)

**Flow**: Same as `process-pending-reports-sp` but for SB

---

### 9. process-pending-reports-sd
**Purpose**: Checks and downloads completed SD reports

**Authentication**: Public (called by cron)

**Flow**: Same as `process-pending-reports-sp` but for SD

---

## Alert System Functions

### 10. run-alert-checks
**Purpose**: Executes alert rule logic and creates alert records

**Authentication**: Public (called internally)

**Trigger**: Called after report processing or manually

**Flow**:
1. Receives rule ID or checks all active rules
2. For each rule:
   - Fetches current period metrics
   - Fetches comparison period metrics
   - Calculates deviations
   - Applies threshold filters
   - Creates alert and alert_items records
3. Calls `send-slack-alert` if configured

---

### 11. check-scheduled-alerts
**Purpose**: Triggers alert checks based on schedule (morning/evening)

**Authentication**: Requires JWT

**Schedule**: 10:00 UTC (morning), 16:00 UTC (evening)

**Parameters**:
- `schedule`: "morning" or "evening"

**Flow**:
1. Fetches rules matching the schedule
2. Calls `run-alert-checks` for each matching rule

---

### 12. send-slack-alert
**Purpose**: Sends alert notifications to Slack

**Authentication**: Public (called internally)

**Flow**:
1. Receives alert data
2. Fetches user's Slack webhook URL
3. Formats message with alert details
4. Sends to Slack webhook
5. Updates alert record with send status

---

## Account Management Functions

### 13. list-amazon-profiles
**Purpose**: Lists all Amazon Advertising profiles for account setup

**Authentication**: Requires JWT

**Usage**: Called from Settings UI when adding new accounts

**Flow**:
1. Refreshes Amazon access token
2. Calls Amazon Profiles API
3. Returns list of available profiles with marketplace info

---

### 14. backfill-profile-id
**Purpose**: Backfills profile_id on existing records

**Authentication**: Requires JWT

**Usage**: One-time migration utility

---

## Data Sync Functions

### 15. sync-daily-data
**Purpose**: Orchestrates daily data sync for all campaign types

**Authentication**: Public (called by cron)

**Schedule**: 08:00 UTC, 14:00 UTC

**Flow**:
1. Fetches all active amazon_accounts
2. Calls `fetch-amazon-data-sp` with all profile IDs
3. Waits 10 seconds (rate limit)
4. Calls `fetch-amazon-data-sb`
5. Waits 10 seconds
6. Calls `fetch-amazon-data-sd`
7. Returns summary of triggered fetches

---

### 16. trigger-14day-backfill
**Purpose**: Refreshes last 14 days of data

**Authentication**: Requires JWT

**Schedule**: 01:01 UTC (nightly)

**Flow**:
1. Calculates 14-day date range
2. Triggers fetch for SP, SB, SD with 10s delays
3. Ensures historical data accuracy

---

## Utility Functions

### 17. check-data-freshness
**Purpose**: Checks if data is up-to-date for accounts

**Authentication**: Requires JWT

**Usage**: Called from Data Status UI

**Returns**: Last sync time and data availability per account

---

### 18. delete-test-data
**Purpose**: Removes test data from database

**Authentication**: Requires JWT

**Usage**: Development/testing cleanup

---

### 19. create-test-rules
**Purpose**: Creates sample alert rules for testing

**Authentication**: Requires JWT

**Usage**: Development/demo setup

---

### 20. retry-failed-report
**Purpose**: Retries a failed report fetch

**Authentication**: Public

**Usage**: Called from Data Status UI "Retry" button

**Flow**:
1. Fetches failed report details
2. Deletes old failed record
3. Triggers new fetch for that profile/date

---

## Testing Functions

### 21. test-slack-webhook
**Purpose**: Tests Slack webhook configuration

**Authentication**: Public

**Usage**: Called from Settings → Test Connection

**Flow**:
1. Receives webhook URL
2. Sends test message
3. Returns success/failure status

---

### 22. test-auth-third-of-life
**Purpose**: Tests Amazon OAuth with specific refresh token

**Authentication**: Public

**Usage**: Development testing for multi-account setup

---

### 23. delete_duplicates_spcampaigns
**Purpose**: Removes duplicate campaign metrics

**Authentication**: Requires JWT

**Usage**: Data cleanup utility

---

## Configuration Reference

All functions are configured in `supabase/config.toml`:

```toml
[functions.function-name]
verify_jwt = true  # or false for public functions
```

### Public Functions (verify_jwt = false)
These are called by cron jobs or other edge functions:
- fetch-amazon-data-sp, sb, sd
- process-pending-reports-sp, sb, sd
- run-alert-checks
- send-slack-alert
- sync-daily-data
- test-slack-webhook
- test-auth-third-of-life
- retry-failed-report

### Protected Functions (verify_jwt = true)
These require user authentication:
- trigger-daily-report-sp, sb, sd
- check-scheduled-alerts
- list-amazon-profiles
- backfill-profile-id
- trigger-14day-backfill
- check-data-freshness
- delete-test-data
- create-test-rules
- delete_duplicates_spcampaigns

---

## Rate Limiting Notes

Amazon Advertising API has strict rate limits:
- **10 requests per second** per profile
- **Report creation**: 30 seconds recommended delay between calls

The functions implement these safeguards:
- 10-second delay between SP/SB/SD calls in `sync-daily-data`
- 3-second delay between report creations in fetch functions
- Exponential backoff on 429 errors

---

## Error Handling

All functions follow consistent error handling:
1. Return proper HTTP status codes (200, 400, 401, 500)
2. Include error details in JSON response
3. Log errors for debugging
4. Update database records with error messages

Check logs at: Supabase Dashboard → Edge Functions → [Function Name] → Logs

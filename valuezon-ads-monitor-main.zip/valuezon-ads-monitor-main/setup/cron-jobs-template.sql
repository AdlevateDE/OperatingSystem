-- ============================================
-- Amazon Advertising Alert System
-- Cron Jobs Configuration
-- ============================================
--
-- IMPORTANT: Before running this SQL, replace:
--   YOUR_PROJECT_REF  → Your Supabase project reference (e.g., abcdefghijklmnop)
--   YOUR_ANON_KEY     → Your Supabase anon key (starts with eyJ...)
--
-- You can find these in: Supabase Dashboard → Settings → API
--
-- Prerequisites:
--   1. Enable pg_cron extension: CREATE EXTENSION IF NOT EXISTS pg_cron;
--   2. Enable pg_net extension: CREATE EXTENSION IF NOT EXISTS pg_net;
--
-- CRITICAL: All jobs use timeout_milliseconds := 30000 (30 seconds)
-- The default 5-second timeout is too short for Edge Functions!
-- ============================================


-- ============================================
-- 1. MORNING DATA SYNC (08:00 UTC / 09:00 CET)
-- ============================================
-- Fetches yesterday's data from Amazon for all active accounts
-- Runs before morning alert check to ensure fresh data

SELECT cron.schedule(
    'daily-data-sync-morning',
    '0 8 * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/sync-daily-data',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := jsonb_build_object('trigger', 'morning_cron'),
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 2. AFTERNOON DATA SYNC (14:00 UTC / 15:00 CET)
-- ============================================
-- Second data sync to catch any late-reporting campaigns
-- Amazon sometimes delays data by several hours

SELECT cron.schedule(
    'daily-data-sync-afternoon',
    '0 14 * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/sync-daily-data',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := jsonb_build_object('trigger', 'afternoon_cron'),
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 3. MORNING ALERT CHECK (10:00 UTC / 11:00 CET)
-- ============================================
-- Checks all active alert rules configured for "morning" or "both"
-- Sends Slack notifications for any triggered alerts

SELECT cron.schedule(
    'check-alerts-morning',
    '0 10 * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/check-scheduled-alerts',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := jsonb_build_object('schedule', 'morning'),
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 4. EVENING ALERT CHECK (16:00 UTC / 17:00 CET)
-- ============================================
-- Checks all active alert rules configured for "evening" or "both"
-- Catches any issues that developed during the day

SELECT cron.schedule(
    'check-alerts-evening',
    '0 16 * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/check-scheduled-alerts',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := jsonb_build_object('schedule', 'evening'),
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 5. NIGHTLY 14-DAY BACKFILL (01:01 UTC)
-- ============================================
-- Refreshes the last 14 days of data nightly
-- Ensures historical data accuracy and catches any corrections

SELECT cron.schedule(
    'nightly-14day-backfill',
    '1 1 * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/trigger-14day-backfill',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := jsonb_build_object('trigger', 'nightly_cron'),
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 6. PROCESS SP REPORTS (Every 5 minutes)
-- ============================================
-- Checks for completed Sponsored Products reports
-- Downloads and saves metrics to database

SELECT cron.schedule(
    'process-pending-reports-sp',
    '*/5 * * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/process-pending-reports-sp',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := '{}'::jsonb,
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 7. PROCESS SB REPORTS (Every 5 minutes)
-- ============================================
-- Checks for completed Sponsored Brands reports
-- Downloads and saves metrics to database

SELECT cron.schedule(
    'process-pending-reports-sb',
    '*/5 * * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/process-pending-reports-sb',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := '{}'::jsonb,
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- 8. PROCESS SD REPORTS (Every 5 minutes)
-- ============================================
-- Checks for completed Sponsored Display reports
-- Downloads and saves metrics to database

SELECT cron.schedule(
    'process-pending-reports-sd',
    '*/5 * * * *',
    $$
    SELECT net.http_post(
        url := 'https://YOUR_PROJECT_REF.supabase.co/functions/v1/process-pending-reports-sd',
        headers := jsonb_build_object(
            'Content-Type', 'application/json',
            'Authorization', 'Bearer YOUR_ANON_KEY'
        ),
        body := '{}'::jsonb,
        timeout_milliseconds := 30000
    ) AS request_id;
    $$
);


-- ============================================
-- UTILITY COMMANDS
-- ============================================

-- View all scheduled cron jobs:
-- SELECT * FROM cron.job ORDER BY jobname;

-- View recent cron job runs:
-- SELECT * FROM cron.job_run_details ORDER BY start_time DESC LIMIT 50;

-- Check for timeout errors in HTTP responses:
-- SELECT id, created, status_code, error_msg FROM net._http_response ORDER BY created DESC LIMIT 50;

-- Disable a specific job:
-- SELECT cron.unschedule('job-name-here');

-- Update a job schedule (example: change morning sync to 07:00):
-- SELECT cron.alter_job(
--     job_id,
--     schedule := '0 7 * * *'
-- ) FROM cron.job WHERE jobname = 'daily-data-sync-morning';

-- Delete all jobs (use with caution!):
-- SELECT cron.unschedule(jobid) FROM cron.job;


-- ============================================
-- TIMEZONE REFERENCE
-- ============================================
-- All times are in UTC. Common conversions:
--
-- | UTC   | CET (Winter) | CEST (Summer) | EST   | PST   |
-- |-------|--------------|---------------|-------|-------|
-- | 01:00 | 02:00        | 03:00         | 20:00 | 17:00 |
-- | 08:00 | 09:00        | 10:00         | 03:00 | 00:00 |
-- | 10:00 | 11:00        | 12:00         | 05:00 | 02:00 |
-- | 14:00 | 15:00        | 16:00         | 09:00 | 06:00 |
-- | 16:00 | 17:00        | 18:00         | 11:00 | 08:00 |
--
-- To adjust times, modify the cron schedule patterns above.
-- Cron format: minute hour day month weekday
-- Examples:
--   '0 8 * * *'   = 08:00 every day
--   '30 9 * * *'  = 09:30 every day
--   '0 8 * * 1-5' = 08:00 Monday-Friday only

-- ============================================
-- Amazon Advertising Alert System
-- Complete Database Schema
-- ============================================
-- 
-- This file contains the complete database schema for the alert system.
-- Run this in Supabase SQL Editor to set up all tables, policies, and functions.
--
-- Tables: 13
-- RLS Policies: 35+
-- Functions: 8
-- ============================================

-- ============================================
-- ENUM TYPES
-- ============================================

-- Account role enum for permission management
CREATE TYPE public.account_role AS ENUM ('owner', 'editor', 'viewer');

-- ============================================
-- TABLES
-- ============================================

-- --------------------------------------------
-- 1. Users Table (Profile data)
-- --------------------------------------------
CREATE TABLE public.users (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    email VARCHAR NOT NULL,
    full_name VARCHAR,
    slack_webhook_url TEXT,
    dashboard_url TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.users ENABLE ROW LEVEL SECURITY;

-- Users RLS Policies
CREATE POLICY "Users can view own profile" ON public.users
    FOR SELECT USING (id = auth.uid());

CREATE POLICY "Users can insert own profile" ON public.users
    FOR INSERT WITH CHECK (id = auth.uid());

CREATE POLICY "Users can update own profile" ON public.users
    FOR UPDATE USING (id = auth.uid()) WITH CHECK (id = auth.uid());

-- --------------------------------------------
-- 2. Amazon Accounts Table
-- --------------------------------------------
CREATE TABLE public.amazon_accounts (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_name VARCHAR NOT NULL,
    profile_id VARCHAR NOT NULL,
    marketplace VARCHAR NOT NULL,
    currency_code VARCHAR NOT NULL DEFAULT 'EUR',
    refresh_token_key TEXT,
    is_active BOOLEAN DEFAULT true,
    user_id UUID,
    last_sync_at TIMESTAMP WITH TIME ZONE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.amazon_accounts ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 3. Account Users Table (Many-to-Many with roles)
-- --------------------------------------------
CREATE TABLE public.account_users (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id UUID NOT NULL,
    user_id UUID NOT NULL,
    role public.account_role NOT NULL DEFAULT 'viewer',
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.account_users ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 4. Campaigns Table
-- --------------------------------------------
CREATE TABLE public.campaigns (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id UUID NOT NULL,
    external_campaign_id TEXT NOT NULL,
    campaign_name TEXT NOT NULL,
    campaign_type TEXT NOT NULL,
    campaign_status TEXT,
    campaign_budget_type TEXT,
    campaign_budget_amount NUMERIC,
    campaign_budget_currency_code TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.campaigns ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 5. Campaign Metrics SP (Sponsored Products)
-- --------------------------------------------
CREATE TABLE public.campaign_metrics_sp (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id TEXT,
    campaign_id BIGINT,
    campaign_name TEXT,
    campaign_status TEXT,
    date DATE NOT NULL,
    impressions BIGINT,
    clicks BIGINT,
    cost NUMERIC,
    cost_per_click NUMERIC,
    click_through_rate NUMERIC,
    purchases_14d BIGINT,
    sales_14d NUMERIC,
    units_sold_clicks_14d BIGINT,
    acos_clicks_14d NUMERIC,
    roas_clicks_14d NUMERIC,
    top_of_search_impression_share NUMERIC,
    campaign_budget_type TEXT,
    campaign_budget_amount NUMERIC,
    campaign_budget_currency_code TEXT,
    unique_key TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.campaign_metrics_sp ENABLE ROW LEVEL SECURITY;

-- Unique constraint for upsert operations
CREATE UNIQUE INDEX IF NOT EXISTS campaign_metrics_sp_unique_key_idx 
    ON public.campaign_metrics_sp(unique_key);

-- --------------------------------------------
-- 6. Campaign Metrics SB (Sponsored Brands)
-- --------------------------------------------
CREATE TABLE public.campaign_metrics_sb (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id TEXT,
    campaign_id BIGINT,
    campaign_name TEXT,
    campaign_status TEXT,
    date DATE NOT NULL,
    impressions BIGINT,
    clicks BIGINT,
    cost NUMERIC,
    cost_type TEXT,
    purchases BIGINT,
    sales NUMERIC,
    units_sold BIGINT,
    top_of_search_impression_share NUMERIC,
    detail_page_views BIGINT,
    add_to_cart BIGINT,
    new_to_brand_purchases BIGINT,
    new_to_brand_sales NUMERIC,
    new_to_brand_units_sold BIGINT,
    video_complete_views BIGINT,
    video_5_second_views BIGINT,
    campaign_budget_type TEXT,
    campaign_budget_amount NUMERIC,
    campaign_budget_currency_code TEXT,
    unique_key TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.campaign_metrics_sb ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX IF NOT EXISTS campaign_metrics_sb_unique_key_idx 
    ON public.campaign_metrics_sb(unique_key);

-- --------------------------------------------
-- 7. Campaign Metrics SD (Sponsored Display)
-- --------------------------------------------
CREATE TABLE public.campaign_metrics_sd (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id TEXT,
    campaign_id BIGINT,
    campaign_name TEXT,
    campaign_status TEXT,
    date DATE NOT NULL,
    impressions BIGINT,
    clicks BIGINT,
    cost NUMERIC,
    cost_type TEXT,
    purchases_clicks BIGINT,
    sales_clicks NUMERIC,
    units_sold_clicks BIGINT,
    detail_page_views_clicks BIGINT,
    add_to_cart_clicks BIGINT,
    new_to_brand_purchases_clicks BIGINT,
    new_to_brand_sales_clicks NUMERIC,
    new_to_brand_units_sold_clicks BIGINT,
    video_complete_views BIGINT,
    video_5_second_views BIGINT,
    campaign_budget_type TEXT,
    campaign_budget_amount NUMERIC,
    campaign_budget_currency_code TEXT,
    unique_key TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.campaign_metrics_sd ENABLE ROW LEVEL SECURITY;

CREATE UNIQUE INDEX IF NOT EXISTS campaign_metrics_sd_unique_key_idx 
    ON public.campaign_metrics_sd(unique_key);

-- --------------------------------------------
-- 8. Alert Rules Table
-- --------------------------------------------
CREATE TABLE public.alert_rules (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id UUID NOT NULL,
    account_ids UUID[],
    rule_name VARCHAR NOT NULL,
    metric_name VARCHAR NOT NULL,
    comparison_period VARCHAR NOT NULL,
    threshold_percent NUMERIC NOT NULL,
    threshold_type TEXT DEFAULT 'percentage',
    check_frequency VARCHAR NOT NULL DEFAULT 'daily',
    check_schedule TEXT DEFAULT 'both',
    alert_direction TEXT DEFAULT 'both',
    campaign_types TEXT[] DEFAULT ARRAY['sp'],
    campaign_selection_mode TEXT DEFAULT 'all',
    selected_campaigns TEXT[],
    campaign_filters JSONB,
    campaign_filters_logic TEXT DEFAULT 'AND',
    alert_conditions JSONB,
    alert_conditions_logic TEXT DEFAULT 'AND',
    is_active BOOLEAN DEFAULT true,
    last_check_at TIMESTAMP WITH TIME ZONE,
    last_edited_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    last_edited_by UUID,
    created_by UUID,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.alert_rules ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 9. Alerts Table
-- --------------------------------------------
CREATE TABLE public.alerts (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    account_id UUID NOT NULL,
    rule_id UUID,
    alert_date DATE NOT NULL,
    run_type VARCHAR,
    total_items INTEGER DEFAULT 0,
    is_no_data BOOLEAN DEFAULT false,
    is_all_clear BOOLEAN DEFAULT false,
    slack_sent BOOLEAN DEFAULT false,
    slack_error TEXT,
    sent_at TIMESTAMP WITH TIME ZONE,
    sheets_url TEXT,
    triggered_by_email TEXT,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.alerts ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 10. Alert Items Table
-- --------------------------------------------
CREATE TABLE public.alert_items (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    alert_id UUID NOT NULL,
    campaign_id UUID,
    external_campaign_id BIGINT,
    campaign_name TEXT,
    account_name VARCHAR,
    rule_name VARCHAR,
    metric_name VARCHAR NOT NULL,
    comparison_period VARCHAR NOT NULL,
    threshold_percent NUMERIC NOT NULL,
    current_value NUMERIC NOT NULL,
    reference_value NUMERIC NOT NULL,
    deviation_percent NUMERIC NOT NULL,
    alert_direction TEXT,
    date DATE NOT NULL,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.alert_items ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 11. Alert Rule Changes Table (Audit Log)
-- --------------------------------------------
CREATE TABLE public.alert_rule_changes (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    rule_id UUID,
    rule_name TEXT NOT NULL,
    change_type TEXT NOT NULL,
    changed_by UUID,
    changed_by_email TEXT,
    changes JSONB,
    previous_values JSONB,
    new_values JSONB,
    changed_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

ALTER TABLE public.alert_rule_changes ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 12. Pending Reports Table
-- --------------------------------------------
CREATE TABLE public.pending_reports (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id TEXT NOT NULL,
    report_id TEXT NOT NULL,
    report_type TEXT DEFAULT 'sp',
    status TEXT NOT NULL DEFAULT 'pending',
    start_date DATE NOT NULL,
    end_date DATE NOT NULL,
    download_url TEXT,
    error_message TEXT,
    attempts INTEGER NOT NULL DEFAULT 0,
    last_attempt_at TIMESTAMP WITH TIME ZONE,
    completed_at TIMESTAMP WITH TIME ZONE,
    batch_id UUID,
    trigger_alert_check BOOLEAN DEFAULT false,
    created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

ALTER TABLE public.pending_reports ENABLE ROW LEVEL SECURITY;

-- --------------------------------------------
-- 13. Cleanup Trigger Table (Internal)
-- --------------------------------------------
CREATE TABLE public.cleanup_trigger (
    id INTEGER NOT NULL DEFAULT 1 PRIMARY KEY,
    last_run TIMESTAMP WITH TIME ZONE
);

ALTER TABLE public.cleanup_trigger ENABLE ROW LEVEL SECURITY;

-- ============================================
-- ROW LEVEL SECURITY POLICIES
-- ============================================

-- Amazon Accounts Policies
CREATE POLICY "Authenticated users can view all accounts" ON public.amazon_accounts
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Users can insert accounts" ON public.amazon_accounts
    FOR INSERT WITH CHECK (true);

CREATE POLICY "Owners/editors can update accounts" ON public.amazon_accounts
    FOR UPDATE USING (has_account_editor_or_owner(id));

CREATE POLICY "Owners can delete accounts" ON public.amazon_accounts
    FOR DELETE USING (is_account_owner(id));

-- Account Users Policies
CREATE POLICY "Users can view own memberships" ON public.account_users
    FOR SELECT USING (user_id = auth.uid());

CREATE POLICY "Owners can manage memberships" ON public.account_users
    FOR ALL USING (is_account_owner(account_id)) WITH CHECK (is_account_owner(account_id));

-- Campaigns Policies
CREATE POLICY "Authenticated users can view all campaigns" ON public.campaigns
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert campaigns" ON public.campaigns
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update campaigns" ON public.campaigns
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Owners/editors can delete campaigns" ON public.campaigns
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM account_users
            WHERE account_users.account_id = campaigns.account_id
            AND account_users.user_id = auth.uid()
            AND account_users.role = ANY (ARRAY['owner'::account_role, 'editor'::account_role])
        )
    );

-- Campaign Metrics SP Policies
CREATE POLICY "Authenticated users can view all metrics sp" ON public.campaign_metrics_sp
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert metrics sp" ON public.campaign_metrics_sp
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update metrics sp" ON public.campaign_metrics_sp
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete metrics sp" ON public.campaign_metrics_sp
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Campaign Metrics SB Policies
CREATE POLICY "Authenticated users can view all metrics sb" ON public.campaign_metrics_sb
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert metrics sb" ON public.campaign_metrics_sb
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update metrics sb" ON public.campaign_metrics_sb
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete metrics sb" ON public.campaign_metrics_sb
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Campaign Metrics SD Policies
CREATE POLICY "Authenticated users can view all metrics sd" ON public.campaign_metrics_sd
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert metrics sd" ON public.campaign_metrics_sd
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update metrics sd" ON public.campaign_metrics_sd
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete metrics sd" ON public.campaign_metrics_sd
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Alert Rules Policies
CREATE POLICY "Authenticated users can view all alert rules" ON public.alert_rules
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert alert rules" ON public.alert_rules
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update alert rules" ON public.alert_rules
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Owners/editors can delete alert rules" ON public.alert_rules
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM account_users
            WHERE account_users.account_id = ANY (alert_rules.account_ids)
            AND account_users.user_id = auth.uid()
            AND account_users.role = ANY (ARRAY['owner'::account_role, 'editor'::account_role])
        )
    );

-- Alerts Policies
CREATE POLICY "Authenticated users can view all alerts" ON public.alerts
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert alerts" ON public.alerts
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update alerts" ON public.alerts
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Owners/editors can delete alerts" ON public.alerts
    FOR DELETE USING (
        EXISTS (
            SELECT 1 FROM account_users
            WHERE account_users.account_id = alerts.account_id
            AND account_users.user_id = auth.uid()
            AND account_users.role = ANY (ARRAY['owner'::account_role, 'editor'::account_role])
        )
    );

-- Alert Items Policies
CREATE POLICY "Authenticated users can view all alert items" ON public.alert_items
    FOR SELECT USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can insert alert items" ON public.alert_items
    FOR INSERT WITH CHECK (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can update alert items" ON public.alert_items
    FOR UPDATE USING (auth.uid() IS NOT NULL);

CREATE POLICY "Authenticated users can delete alert items" ON public.alert_items
    FOR DELETE USING (auth.uid() IS NOT NULL);

-- Alert Rule Changes Policies
CREATE POLICY "All users can view rule changes" ON public.alert_rule_changes
    FOR SELECT USING (true);

CREATE POLICY "Users can insert rule changes" ON public.alert_rule_changes
    FOR INSERT WITH CHECK (changed_by = auth.uid());

-- Pending Reports Policies
CREATE POLICY "Authenticated users can view all pending reports" ON public.pending_reports
    FOR SELECT USING (auth.uid() IS NOT NULL);

-- Cleanup Trigger Policies
CREATE POLICY "Only service role can access cleanup_trigger" ON public.cleanup_trigger
    FOR ALL USING (true) WITH CHECK (true);

-- ============================================
-- DATABASE FUNCTIONS
-- ============================================

-- Function to update updated_at timestamp
CREATE OR REPLACE FUNCTION public.update_updated_at_column()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    NEW.updated_at = NOW();
    RETURN NEW;
END;
$$;

-- Function to add account owner on creation
CREATE OR REPLACE FUNCTION public.add_account_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public'
AS $$
BEGIN
    INSERT INTO account_users (account_id, user_id, role)
    VALUES (NEW.id, auth.uid(), 'owner');
    RETURN NEW;
END;
$$;

-- Function to check if user has access to account
CREATE OR REPLACE FUNCTION public.has_account_access(_account_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.account_users
        WHERE account_id = _account_id
        AND user_id = auth.uid()
    );
$$;

-- Function to check if user is editor or owner
CREATE OR REPLACE FUNCTION public.has_account_editor_or_owner(_account_id UUID)
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.account_users
        WHERE account_id = _account_id
        AND user_id = auth.uid()
        AND role = ANY (ARRAY['owner','editor']::public.account_role[])
    );
$$;

-- Function to check if user is account owner
CREATE OR REPLACE FUNCTION public.is_account_owner(_account_id UUID, _user_id UUID DEFAULT auth.uid())
RETURNS BOOLEAN
LANGUAGE sql
STABLE
SECURITY DEFINER
SET search_path TO 'public'
AS $$
    SELECT EXISTS (
        SELECT 1 FROM public.account_users
        WHERE account_id = _account_id
        AND user_id = _user_id
        AND role = 'owner'
    );
$$;

-- Function to delete last 15 days of SP campaign data
CREATE OR REPLACE FUNCTION public.delete_last15days_spcampaigns(p JSON)
RETURNS JSON
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path TO 'public', 'pg_temp'
AS $$
BEGIN
    DELETE FROM campaign_metrics_sp 
    WHERE date >= CURRENT_DATE - INTERVAL '15 days';
    
    RETURN json_build_object('deleted', true);
END;
$$;

-- Function to delete duplicate SP campaigns
CREATE OR REPLACE FUNCTION public.delete_duplicates_spcampaigns()
RETURNS VOID
LANGUAGE plpgsql
AS $$
BEGIN
    DELETE FROM campaign_metrics_sp a
    USING campaign_metrics_sp b
    WHERE 
        a.campaign_id = b.campaign_id
        AND a.date = b.date
        AND a.created_at < b.created_at;
END;
$$;

-- Trigger function for SP cleanup
CREATE OR REPLACE FUNCTION public.trigger_cleanup_sp()
RETURNS TRIGGER
LANGUAGE plpgsql
SET search_path TO 'public', 'pg_temp'
AS $$
BEGIN
    DELETE FROM campaign_metrics_sp WHERE date >= CURRENT_DATE - INTERVAL '15 days';
    RETURN NEW;
END;
$$;

-- ============================================
-- TRIGGERS
-- ============================================

-- Trigger for amazon_accounts to add owner
CREATE TRIGGER on_amazon_account_created
    AFTER INSERT ON public.amazon_accounts
    FOR EACH ROW
    EXECUTE FUNCTION public.add_account_owner();

-- Triggers for updated_at columns
CREATE TRIGGER update_users_updated_at
    BEFORE UPDATE ON public.users
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_amazon_accounts_updated_at
    BEFORE UPDATE ON public.amazon_accounts
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_campaigns_updated_at
    BEFORE UPDATE ON public.campaigns
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_campaign_metrics_sp_updated_at
    BEFORE UPDATE ON public.campaign_metrics_sp
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_campaign_metrics_sb_updated_at
    BEFORE UPDATE ON public.campaign_metrics_sb
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_campaign_metrics_sd_updated_at
    BEFORE UPDATE ON public.campaign_metrics_sd
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

CREATE TRIGGER update_alert_rules_updated_at
    BEFORE UPDATE ON public.alert_rules
    FOR EACH ROW
    EXECUTE FUNCTION public.update_updated_at_column();

-- ============================================
-- INDEXES
-- ============================================

-- Performance indexes for common queries
CREATE INDEX IF NOT EXISTS idx_campaign_metrics_sp_profile_date 
    ON public.campaign_metrics_sp(profile_id, date);

CREATE INDEX IF NOT EXISTS idx_campaign_metrics_sb_profile_date 
    ON public.campaign_metrics_sb(profile_id, date);

CREATE INDEX IF NOT EXISTS idx_campaign_metrics_sd_profile_date 
    ON public.campaign_metrics_sd(profile_id, date);

CREATE INDEX IF NOT EXISTS idx_pending_reports_status 
    ON public.pending_reports(status);

CREATE INDEX IF NOT EXISTS idx_pending_reports_profile 
    ON public.pending_reports(profile_id);

CREATE INDEX IF NOT EXISTS idx_alerts_rule_date 
    ON public.alerts(rule_id, alert_date);

CREATE INDEX IF NOT EXISTS idx_alert_items_alert 
    ON public.alert_items(alert_id);

-- ============================================
-- END OF SCHEMA
-- ============================================

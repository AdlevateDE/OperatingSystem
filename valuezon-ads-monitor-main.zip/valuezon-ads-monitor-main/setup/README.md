# Amazon Advertising Alert System - Template Setup Guide

## 🎯 What You Get

This template provides a complete Amazon Advertising monitoring and alerting system:

- **13 Database Tables** - Full data model for accounts, campaigns, metrics, alerts
- **23 Edge Functions** - Backend logic for API integration and processing
- **8 Automated Cron Jobs** - Scheduled data fetching and alert checking
- **React Frontend** - Modern UI with Tailwind CSS and shadcn/ui
- **Multi-Account Support** - Manage multiple Amazon Advertising accounts
- **Slack Integration** - Real-time alert notifications

---

## 📋 Prerequisites Checklist

Before starting, ensure you have:

- [ ] **Amazon Developer Account** - [developer.amazon.com](https://developer.amazon.com)
- [ ] **Amazon Advertising API Access** - Applied and approved (can take 1-7 days)
- [ ] **Lovable Account** - [lovable.dev](https://lovable.dev)
- [ ] **Slack Workspace** (optional) - For alert notifications

---

## 🚀 Setup Guide

### Phase 1: Amazon Developer Setup (30 minutes)

#### 1.1 Create Amazon Developer Account

1. Go to [developer.amazon.com](https://developer.amazon.com)
2. Sign in or create a new account
3. Navigate to "Apps & Services" → "Login with Amazon"
4. Click "Create a New Security Profile"
5. Fill in the required information:
   - Security Profile Name: `Your App Name`
   - Security Profile Description: `Amazon Advertising monitoring`
   - Consent Privacy Notice URL: Your privacy policy URL

#### 1.2 Register for Amazon Advertising API

1. Go to [advertising.amazon.com/developer](https://advertising.amazon.com/developer)
2. Click "Request API Access"
3. Select your use case (typically "Advertising Tool Provider")
4. Fill in the application form
5. Wait for approval (1-7 business days)

#### 1.3 Note Your Credentials

After approval, save these values:
- **Client ID**: `amzn1.application-oa2-client.xxxxx`
- **Client Secret**: `xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

---

### Phase 2: GitHub Repository Setup (10 minutes)

#### 2.1 Create Your GitHub Repository

1. Go to [github.com](https://github.com) and sign in (or create an account)
2. Click the **+** icon in the top right → "New repository"
3. Choose a repository name (e.g., `amazon-ads-alerts`)
4. Set visibility to **Private** (recommended)
5. Leave "Initialize with README" **unchecked**
6. Click "Create repository"

#### 2.2 Upload Template Code to GitHub

**Option A: Using GitHub Web Interface (Easiest)**

1. In your new empty repository, click the link "uploading an existing file"
2. Extract the downloaded template ZIP file to a folder
3. Drag all files and folders into the upload area
4. Add a commit message (e.g., "Initial template setup")
5. Click "Commit changes"

**Option B: Using Git Command Line**

1. Extract the template ZIP to a folder on your computer
2. Open terminal/command prompt in that folder
3. Run these commands:

```bash
git init
git add .
git commit -m "Initial template setup"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/YOUR_REPO_NAME.git
git push -u origin main
```

#### 2.3 Verify Upload

1. Refresh your GitHub repository page
2. You should see all files including:
   - `/src` folder (frontend code)
   - `/supabase` folder (edge functions)
   - `/setup` folder (documentation)
   - `package.json`, `vite.config.ts`, etc.

---

### Phase 3: Lovable Project Setup (15 minutes)

#### 3.1 Create New Lovable Project

1. Go to [lovable.dev](https://lovable.dev)
2. Click "New Project"
3. Select "Import from GitHub"
4. Connect your GitHub account if not already connected
5. **Select the repository you created in Phase 2** (e.g., `amazon-ads-alerts`)
6. Wait for the import to complete

#### 3.2 Connect Supabase

1. In Lovable, go to **Settings** → **Supabase**
2. Click "Connect to Supabase"
3. Choose "Create new Supabase project" OR connect existing
4. Wait for the connection to complete
5. Note your **Project Reference** (e.g., `abcdefghijklmnop`)

---

### Phase 4: Database Setup (20 minutes)

#### 3.1 Enable Required Extensions

Open Supabase Dashboard → SQL Editor and run:

```sql
-- Enable required extensions for cron jobs
CREATE EXTENSION IF NOT EXISTS pg_cron;
CREATE EXTENSION IF NOT EXISTS pg_net;
```

#### 3.2 Import Database Schema

1. Open Supabase Dashboard → SQL Editor
2. Copy the contents of `setup/schema.sql`
3. Paste and execute the SQL
4. Verify all 13 tables were created in Table Editor

#### 3.3 Setup Cron Jobs

1. Open `setup/cron-jobs-template.sql`
2. Replace placeholders:
   - `YOUR_PROJECT_REF` → Your Supabase project reference
   - `YOUR_ANON_KEY` → Your Supabase anon key (found in Settings → API)
3. Execute the SQL in SQL Editor
4. Verify cron jobs in Database → Extensions → pg_cron

---

### Phase 5: Secrets Configuration (10 minutes)

Navigate to Supabase Dashboard → Settings → Edge Functions → Secrets

Add the following secrets:

| Secret Name | Description | Where to Find |
|-------------|-------------|---------------|
| `AMAZON_CLIENT_ID` | Amazon OAuth Client ID | Amazon Developer Console |
| `AMAZON_CLIENT_SECRET` | Amazon OAuth Client Secret | Amazon Developer Console |
| `AMAZON_REFRESH_TOKEN` | OAuth Refresh Token | See Phase 5 below |
| `SUPABASE_URL` | Your Supabase URL | Settings → API |
| `SUPABASE_ANON_KEY` | Supabase Anonymous Key | Settings → API |
| `SUPABASE_SERVICE_ROLE_KEY` | Service Role Key | Settings → API |

See `setup/secrets-checklist.md` for detailed instructions.

---

### Phase 6: Amazon OAuth Refresh Token (15 minutes)

You need to perform a one-time OAuth flow to get a refresh token.

#### 5.1 Generate Authorization URL

Replace placeholders and open in browser:

```
https://www.amazon.com/ap/oa?client_id=YOUR_CLIENT_ID&scope=advertising::campaign_management&response_type=code&redirect_uri=https://www.amazon.com
```

#### 5.2 Authorize and Get Code

1. Log in to your Amazon account
2. Authorize the application
3. You'll be redirected to a URL like:
   ```
   https://www.amazon.com/?code=ANxxxxxxxxxxxxxx&scope=...
   ```
4. Copy the `code` parameter value

#### 5.3 Exchange Code for Refresh Token

Run this curl command (replace placeholders):

```bash
curl -X POST https://api.amazon.com/auth/o2/token \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code" \
  -d "code=YOUR_AUTHORIZATION_CODE" \
  -d "client_id=YOUR_CLIENT_ID" \
  -d "client_secret=YOUR_CLIENT_SECRET" \
  -d "redirect_uri=https://www.amazon.com"
```

#### 5.4 Save Refresh Token

The response will contain a `refresh_token`. Save this as the `AMAZON_REFRESH_TOKEN` secret in Supabase.

> ⚠️ **Important**: The authorization code expires in 5 minutes. If you get an error, start from step 5.1 again.

---

### Phase 7: App Configuration (10 minutes)

#### 6.1 Create First User

1. Open your Lovable app preview
2. Click "Sign Up" or "Register"
3. Enter your email and password
4. Confirm your email (check inbox)

#### 6.2 Add Amazon Account

1. Go to **Settings** → **Accounts**
2. Click "Add Account"
3. Enter your Amazon Profile details:
   - **Account Name**: Friendly name (e.g., "Main Account DE")
   - **Profile ID**: Found in Amazon Advertising Console URL
   - **Marketplace**: Select your marketplace (e.g., DE, US, UK)
   - **Currency**: Select currency (e.g., EUR, USD, GBP)

#### 6.3 Configure Slack (Optional)

1. Go to **Settings** → **Integrations**
2. Add your Slack Webhook URL
3. Add your Dashboard URL (for links in Slack messages)
4. Click "Test Connection" to verify

---

### Phase 8: First Alert Rule (5 minutes)

#### 7.1 Create Test Rule

1. Go to **Alert Rules**
2. Click "Create New Rule"
3. Configure a simple rule:
   - **Name**: "Test Alert - Cost Spike"
   - **Metric**: Cost
   - **Threshold**: 20%
   - **Direction**: Increase
   - **Comparison**: Previous 7 days

#### 7.2 Manual Test

1. Click the play button (▶️) next to your rule
2. Wait for the check to complete
3. Check the **Data Status** tab for results

---

### Phase 9: Deployment (5 minutes)

#### 8.1 Publish Your App

1. In Lovable, click "Publish" (top right)
2. Choose a subdomain or connect custom domain
3. Edge Functions deploy automatically
4. Share the URL with your team

---

## 🔧 Troubleshooting

### Common Issues

#### 429 Rate Limit Errors from Amazon API

The edge functions have built-in delays (10 seconds between calls). If you have many accounts:
- Increase delay in `sync-daily-data` function
- Stagger account sync times

#### No Data at 11 AM

Amazon reports take time to process:
- Morning sync runs at 08:00 UTC
- Alert checks run at 10:00 UTC (11:00 CET)
- If data is missing, wait until afternoon check (16:00 UTC)

#### Slack Messages Not Arriving

Check these common issues:
1. Webhook URL format: Must start with `https://hooks.slack.com/services/`
2. Dashboard URL: Should NOT have trailing slash
3. Test webhook manually via Settings

#### RLS Policy Errors

Ensure proper user setup:
1. User must exist in `users` table
2. Account-user link must exist in `account_users` table
3. User must have proper role (owner/editor/viewer)

#### "Report Failed" Status

Amazon occasionally fails to generate reports:
1. Wait 30 minutes and retry
2. Check Amazon Advertising Console for API status
3. Use the "Retry" button in Data Status

---

## 🎨 Customization Guide

### Changing Alert Check Times

Edit cron jobs in Supabase SQL Editor:
```sql
-- View existing schedules
SELECT * FROM cron.job;

-- Update schedule (example: change to 9 AM UTC)
SELECT cron.alter_job(job_id, schedule := '0 9 * * *')
FROM cron.job WHERE jobname = 'check-alerts-morning';
```

### Adding New Metrics

1. Add metric to `campaign_metrics_sp/sb/sd` tables
2. Update fetch functions to capture new metric
3. Add metric option in `AlertConditionBuilder.tsx`
4. Update `run-alert-checks` function

### Custom Notification Channels

The system uses Slack webhooks. To add other channels:
1. Create new edge function for the channel
2. Call it from `send-slack-alert` or create parallel function
3. Add configuration in Settings UI

---

## 📁 File Structure

```
├── src/
│   ├── components/     # React components
│   ├── contexts/       # React contexts
│   ├── hooks/          # Custom hooks
│   ├── pages/          # Page components
│   └── integrations/   # Supabase client
├── supabase/
│   ├── functions/      # 23 Edge Functions
│   └── config.toml     # Function configuration
└── setup/
    ├── README.md           # This file
    ├── schema.sql          # Database schema
    ├── cron-jobs-template.sql  # Cron job definitions
    ├── secrets-checklist.md    # Secrets guide
    └── edge-functions-overview.md  # Function docs
```

---

## 🔐 Security Notes

This template includes:
- **Row Level Security (RLS)** on all tables
- **Role-based access control** (owner/editor/viewer)
- **Secure secret management** via Supabase Secrets
- **No hardcoded credentials** in code

Never commit actual API keys or secrets to your repository.

---

## 📞 Support

For template-specific questions, refer to:
- `setup/secrets-checklist.md` - Detailed secrets guide
- `setup/edge-functions-overview.md` - Function documentation
- Supabase Documentation: [supabase.com/docs](https://supabase.com/docs)
- Amazon Advertising API Docs: [advertising.amazon.com/API](https://advertising.amazon.com/API)

---

## ✅ Quick Checklist

- [ ] Amazon Developer Account created
- [ ] Amazon Advertising API access approved
- [ ] Lovable project created and connected to GitHub
- [ ] Supabase connected
- [ ] pg_cron and pg_net extensions enabled
- [ ] schema.sql executed
- [ ] Cron jobs configured with your project details
- [ ] All 6 secrets added to Supabase
- [ ] First user created
- [ ] First Amazon account added
- [ ] Test alert rule created and working
- [ ] App published

🎉 **Congratulations!** Your Amazon Advertising Alert System is ready!

# Secrets Configuration Checklist

This document describes all secrets required for the Amazon Advertising Alert System.

## Required Secrets Overview

| # | Secret Name | Required | Source |
|---|-------------|----------|--------|
| 1 | `AMAZON_CLIENT_ID` | ✅ Yes | Amazon Developer Console |
| 2 | `AMAZON_CLIENT_SECRET` | ✅ Yes | Amazon Developer Console |
| 3 | `AMAZON_REFRESH_TOKEN` | ✅ Yes | OAuth Flow |
| 4 | `SUPABASE_URL` | ✅ Yes | Auto-available |
| 5 | `SUPABASE_ANON_KEY` | ✅ Yes | Auto-available |
| 6 | `SUPABASE_SERVICE_ROLE_KEY` | ✅ Yes | Supabase Dashboard |

---

## 1. AMAZON_CLIENT_ID

**Description**: OAuth 2.0 Client ID for Amazon Advertising API

**Format**: `amzn1.application-oa2-client.xxxxxxxxxxxxxxxxxxxxxxxxxxxxxxxx`

**How to obtain**:
1. Go to [Amazon Developer Console](https://developer.amazon.com)
2. Navigate to "Apps & Services" → "Login with Amazon"
3. Select your Security Profile
4. Go to "Web Settings"
5. Copy the "Client ID"

---

## 2. AMAZON_CLIENT_SECRET

**Description**: OAuth 2.0 Client Secret for Amazon Advertising API

**Format**: 64-character hexadecimal string

**How to obtain**:
1. Go to [Amazon Developer Console](https://developer.amazon.com)
2. Navigate to "Apps & Services" → "Login with Amazon"
3. Select your Security Profile
4. Go to "Web Settings"
5. Click "Show Secret" next to Client Secret
6. Copy the secret value

⚠️ **Security Note**: Never share or commit this value. Store only in Supabase Secrets.

---

## 3. AMAZON_REFRESH_TOKEN

**Description**: Long-lived OAuth token for API access without user interaction

**Format**: `Atzr|IwE...` (long base64-encoded string)

**How to obtain**:

### Step 1: Generate Authorization URL
Replace `YOUR_CLIENT_ID` and open in browser:
```
https://www.amazon.com/ap/oa?client_id=YOUR_CLIENT_ID&scope=advertising::campaign_management&response_type=code&redirect_uri=https://www.amazon.com
```

### Step 2: Authorize Application
1. Log in with your Amazon Advertising account
2. Click "Allow" to authorize the application
3. You'll be redirected to a URL like:
   ```
   https://www.amazon.com/?code=ANxxxxxxxxxxxx&scope=advertising::campaign_management
   ```
4. Copy the `code` parameter value (starts with "AN")

### Step 3: Exchange Code for Tokens
Run this curl command (replace ALL placeholders):

```bash
curl -X POST "https://api.amazon.com/auth/o2/token" \
  -H "Content-Type: application/x-www-form-urlencoded" \
  -d "grant_type=authorization_code" \
  -d "code=YOUR_AUTHORIZATION_CODE" \
  -d "client_id=YOUR_CLIENT_ID" \
  -d "client_secret=YOUR_CLIENT_SECRET" \
  -d "redirect_uri=https://www.amazon.com"
```

### Step 4: Extract Refresh Token
The response will look like:
```json
{
  "access_token": "Atza|...",
  "refresh_token": "Atzr|...",
  "token_type": "bearer",
  "expires_in": 3600
}
```

Copy the `refresh_token` value and save it as the secret.

⚠️ **Important Notes**:
- The authorization code expires in **5 minutes**
- If you get an error, start from Step 1 again
- The refresh token is **long-lived** (typically 1 year)
- Store it securely - it grants full API access

---

## 4. SUPABASE_URL

**Description**: Your Supabase project URL

**Format**: `https://YOUR_PROJECT_REF.supabase.co`

**How to obtain**:
- This is automatically available in Edge Functions as `Deno.env.get('SUPABASE_URL')`
- For reference: Supabase Dashboard → Settings → API → Project URL

---

## 5. SUPABASE_ANON_KEY

**Description**: Supabase anonymous/public API key

**Format**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` (JWT token)

**How to obtain**:
- This is automatically available in Edge Functions as `Deno.env.get('SUPABASE_ANON_KEY')`
- For reference: Supabase Dashboard → Settings → API → anon public key

---

## 6. SUPABASE_SERVICE_ROLE_KEY

**Description**: Supabase service role key with admin privileges

**Format**: `eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9...` (JWT token)

**How to obtain**:
1. Go to Supabase Dashboard
2. Navigate to Settings → API
3. Find "service_role" under "Project API keys"
4. Click "Reveal" and copy the value

⚠️ **Security Warning**: 
- This key bypasses Row Level Security
- Never expose in client-side code
- Only use in Edge Functions

---

## Adding Secrets to Supabase

### Method 1: Supabase Dashboard (Recommended)

1. Go to [Supabase Dashboard](https://supabase.com/dashboard)
2. Select your project
3. Navigate to **Settings** → **Edge Functions**
4. Scroll to **Secrets**
5. Click **New Secret**
6. Enter the secret name and value
7. Click **Add Secret**

### Method 2: Supabase CLI

```bash
# Set a single secret
supabase secrets set AMAZON_CLIENT_ID=your_client_id

# Set multiple secrets
supabase secrets set \
  AMAZON_CLIENT_ID=your_client_id \
  AMAZON_CLIENT_SECRET=your_client_secret \
  AMAZON_REFRESH_TOKEN=your_refresh_token

# List all secrets (names only)
supabase secrets list
```

---

## Verification Checklist

After adding all secrets, verify your setup:

- [ ] All 6 secrets are listed in Supabase Dashboard → Settings → Edge Functions → Secrets
- [ ] Test Amazon OAuth by calling the `list-amazon-profiles` edge function
- [ ] Verify Supabase connection by checking if data sync works

---

## Troubleshooting

### "Invalid client_id" Error
- Verify the Client ID is copied correctly (no extra spaces)
- Ensure the app is registered for Amazon Advertising API

### "Invalid refresh_token" Error
- The refresh token may have expired (after ~1 year)
- Repeat the OAuth flow to get a new refresh token
- Ensure you're using the correct Amazon account

### "Access Denied" from Amazon API
- Verify Amazon Advertising API access was approved
- Check if the profile has the correct permissions
- Ensure the refresh token was created with the right scope

### Edge Function Can't Read Secret
- Secret names are case-sensitive
- Ensure the secret was saved (not just created)
- Redeploy edge functions after adding new secrets

---

## Security Best Practices

1. **Never commit secrets to Git** - Use `.gitignore` for any local secret files
2. **Rotate secrets periodically** - Especially after team member changes
3. **Use minimum required permissions** - Only request necessary OAuth scopes
4. **Monitor API usage** - Check Amazon Advertising Console for unusual activity
5. **Audit secret access** - Review who has access to Supabase project settings

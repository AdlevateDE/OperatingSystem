-- Recreate foreign key with correct column name
ALTER TABLE campaign_metrics_sp
ADD CONSTRAINT campaign_metrics_sp_profile_id_fkey 
FOREIGN KEY (profile_id) 
REFERENCES amazon_accounts(id);
-- Drop the old campaign_metrics_sd table and recreate with proper structure
DROP TABLE IF EXISTS public.campaign_metrics_sd CASCADE;

-- Create new campaign_metrics_sd table with all SD columns
CREATE TABLE public.campaign_metrics_sd (
    id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
    profile_id TEXT,
    date DATE NOT NULL,
    campaign_id BIGINT,
    campaign_name TEXT,
    campaign_status TEXT,
    campaign_budget_amount NUMERIC,
    campaign_budget_currency_code TEXT,
    campaign_budget_type TEXT,
    cost_type TEXT,
    impressions BIGINT,
    clicks BIGINT,
    cost NUMERIC,
    purchases_clicks BIGINT,
    sales_clicks NUMERIC,
    units_sold_clicks BIGINT,
    detail_page_views_clicks BIGINT,
    add_to_cart_clicks BIGINT,
    new_to_brand_purchases_clicks BIGINT,
    new_to_brand_sales_clicks NUMERIC,
    new_to_brand_units_sold_clicks BIGINT,
    video_complete_views BIGINT,
    video_5_second_views BIGINT,
    unique_key TEXT UNIQUE,
    created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
    updated_at TIMESTAMP WITH TIME ZONE DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.campaign_metrics_sd ENABLE ROW LEVEL SECURITY;

-- RLS Policies (analog zu SP/SB)
CREATE POLICY "Users can view accessible metrics sd" 
ON public.campaign_metrics_sd 
FOR SELECT 
USING (
    profile_id IN (
        SELECT aa.profile_id 
        FROM amazon_accounts aa
        JOIN account_users au ON au.account_id = aa.id
        WHERE au.user_id = auth.uid()
    )
);

CREATE POLICY "Users can insert metrics sd" 
ON public.campaign_metrics_sd 
FOR INSERT 
WITH CHECK (
    profile_id IN (
        SELECT aa.profile_id 
        FROM amazon_accounts aa
        JOIN account_users au ON au.account_id = aa.id
        WHERE au.user_id = auth.uid()
    )
);

CREATE POLICY "Users can update accessible metrics sd" 
ON public.campaign_metrics_sd 
FOR UPDATE 
USING (
    profile_id IN (
        SELECT aa.profile_id 
        FROM amazon_accounts aa
        JOIN account_users au ON au.account_id = aa.id
        WHERE au.user_id = auth.uid()
    )
);

CREATE POLICY "Users can delete accessible metrics sd" 
ON public.campaign_metrics_sd 
FOR DELETE 
USING (
    profile_id IN (
        SELECT aa.profile_id 
        FROM amazon_accounts aa
        JOIN account_users au ON au.account_id = aa.id
        WHERE au.user_id = auth.uid()
    )
);

-- Create index for performance
CREATE INDEX idx_campaign_metrics_sd_profile_date ON public.campaign_metrics_sd(profile_id, date);
CREATE INDEX idx_campaign_metrics_sd_campaign_id ON public.campaign_metrics_sd(campaign_id);
CREATE INDEX idx_campaign_metrics_sd_unique_key ON public.campaign_metrics_sd(unique_key);
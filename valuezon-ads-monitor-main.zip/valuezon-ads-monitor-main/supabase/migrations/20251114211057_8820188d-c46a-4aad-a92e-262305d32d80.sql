-- Rename account_id to profile_id in campaign_metrics_sp
ALTER TABLE campaign_metrics_sp 
RENAME COLUMN account_id TO profile_id;

-- Rename the index as well
DROP INDEX IF EXISTS idx_campaign_metrics_sp_account_id;
CREATE INDEX idx_campaign_metrics_sp_profile_id ON campaign_metrics_sp(profile_id);
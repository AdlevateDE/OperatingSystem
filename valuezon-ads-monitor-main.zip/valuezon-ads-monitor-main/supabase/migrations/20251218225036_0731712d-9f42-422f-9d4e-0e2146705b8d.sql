-- Update Multi-Account rules to only use SP campaign type
UPDATE public.alert_rules 
SET campaign_types = ARRAY['sp']
WHERE rule_name IN ('MultiAccount_Cost_1%', 'MultiAccount_PreFilter_10EUR');
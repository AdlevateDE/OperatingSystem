
-- Add owner and last editor fields to alert_rules
ALTER TABLE public.alert_rules 
ADD COLUMN created_by uuid REFERENCES public.users(id),
ADD COLUMN last_edited_by uuid REFERENCES public.users(id),
ADD COLUMN last_edited_at timestamp with time zone DEFAULT now();

-- Create audit log table for rule changes
CREATE TABLE public.alert_rule_changes (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  rule_id uuid REFERENCES public.alert_rules(id) ON DELETE SET NULL,
  rule_name text NOT NULL,
  changed_by uuid REFERENCES public.users(id),
  changed_by_email text,
  changed_at timestamp with time zone DEFAULT now(),
  change_type text NOT NULL CHECK (change_type IN ('created', 'updated', 'deleted')),
  changes jsonb,
  previous_values jsonb,
  new_values jsonb
);

-- Enable RLS on the changes table
ALTER TABLE public.alert_rule_changes ENABLE ROW LEVEL SECURITY;

-- All authenticated users can view change history (as per requirement "alle User sollen alle Regeln sehen")
CREATE POLICY "All users can view rule changes"
ON public.alert_rule_changes
FOR SELECT
TO authenticated
USING (true);

-- Users can insert change records
CREATE POLICY "Users can insert rule changes"
ON public.alert_rule_changes
FOR INSERT
TO authenticated
WITH CHECK (changed_by = auth.uid());

-- Create index for faster lookups
CREATE INDEX idx_alert_rule_changes_rule_id ON public.alert_rule_changes(rule_id);
CREATE INDEX idx_alert_rule_changes_changed_at ON public.alert_rule_changes(changed_at DESC);

-- Update existing rules to set created_by from first account_user (best effort migration)
UPDATE public.alert_rules ar
SET created_by = (
  SELECT au.user_id 
  FROM public.account_users au 
  WHERE au.account_id = ar.account_id 
  ORDER BY au.created_at ASC 
  LIMIT 1
)
WHERE created_by IS NULL;

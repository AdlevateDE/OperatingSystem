-- Fix Evening-Cron-Job: Change from 19:00 UTC to 15:00 UTC (= 17:00 MEZ)
SELECT cron.alter_job(
  job_id := 3,
  schedule := '0 15 * * *'
);
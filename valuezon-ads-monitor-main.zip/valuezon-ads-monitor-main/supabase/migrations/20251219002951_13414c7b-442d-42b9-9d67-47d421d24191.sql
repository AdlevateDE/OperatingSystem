UPDATE pending_reports 
SET status = 'failed', error_message = 'Manually cancelled for testing'
WHERE status = 'pending';
-- Clean up orphaned pending_reports for deleted accounts (like Test1233/Castrol)
DELETE FROM pending_reports 
WHERE profile_id NOT IN (
  SELECT profile_id FROM amazon_accounts
) 
AND created_at < NOW() - INTERVAL '1 day';
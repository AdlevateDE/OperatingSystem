-- Enable required extensions
CREATE EXTENSION IF NOT EXISTS pg_cron WITH SCHEMA extensions;
CREATE EXTENSION IF NOT EXISTS pg_net WITH SCHEMA extensions;

-- Schedule process-pending-reports to run every minute
SELECT cron.schedule(
  'process-pending-reports-every-minute',
  '* * * * *',
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/process-pending-reports',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
  $$
);
-- Add slack_error column to alerts table to store error messages when Slack sending fails
ALTER TABLE alerts ADD COLUMN IF NOT EXISTS slack_error TEXT DEFAULT NULL;

-- Add comment for documentation
COMMENT ON COLUMN alerts.slack_error IS 'Stores error message when Slack notification fails to send';
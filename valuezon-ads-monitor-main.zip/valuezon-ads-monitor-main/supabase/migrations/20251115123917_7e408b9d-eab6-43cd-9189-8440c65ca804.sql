-- Add external_campaign_id to alert_items for Amazon Campaign ID (bigint)
ALTER TABLE alert_items 
ADD COLUMN external_campaign_id bigint;

-- Make campaign_id nullable since we'll use external_campaign_id for now
ALTER TABLE alert_items 
ALTER COLUMN campaign_id DROP NOT NULL;

-- Add index for better query performance
CREATE INDEX idx_alert_items_external_campaign_id ON alert_items(external_campaign_id);
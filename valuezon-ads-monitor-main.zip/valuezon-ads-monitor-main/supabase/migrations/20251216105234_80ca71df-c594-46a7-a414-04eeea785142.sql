-- Add daily SP data fetch cron job at 09:00 UTC (11:00 German winter time)
SELECT cron.schedule(
  'daily-sp-data-fetch-morning',
  '0 9 * * *',
  $$
  SELECT net.http_post(
    url:='https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/trigger-daily-report-sp',
    headers:='{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body:='{"trigger_all": true}'::jsonb
  ) AS request_id;
  $$
);
-- Add test rule for all campaign types (SP, SB, SD) for Third of Life only
INSERT INTO public.alert_rules (
  rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type,
  comparison_period, alert_direction, check_frequency, is_active, campaign_types,
  created_by, last_edited_by
) VALUES (
  'TOL_AllTypes_Cost_1%',
  '13b38e13-ed85-45bf-a921-946cd96f5102',
  ARRAY['13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[],
  'cost',
  1,
  'percentage',
  'yesterday',
  'both',
  'daily',
  true,
  ARRAY['sp', 'sb', 'sd'],
  '7c415601-f23d-49c5-8fbd-b74255463f5f',
  '7c415601-f23d-49c5-8fbd-b74255463f5f'
);
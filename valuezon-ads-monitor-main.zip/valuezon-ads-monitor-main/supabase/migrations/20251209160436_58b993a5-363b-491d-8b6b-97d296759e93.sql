-- Add adlevatede@gmail.com as editor to both accounts
INSERT INTO account_users (account_id, user_id, role)
VALUES 
  ('15a6a4d5-56e8-48ad-a46d-fd9cee66af3c', 'fae8ca77-8ade-43bc-99dc-a673c14626c4', 'editor'),
  ('c399c4e1-11ba-4988-a4fc-dc91c028592e', 'fae8ca77-8ade-43bc-99dc-a673c14626c4', 'editor')
ON CONFLICT DO NOTHING;
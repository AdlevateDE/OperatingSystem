-- Add campaign selection columns to alert_rules table
ALTER TABLE alert_rules 
ADD COLUMN selected_campaigns text[] DEFAULT NULL,
ADD COLUMN campaign_selection_mode text DEFAULT 'all';

-- Add comment for documentation
COMMENT ON COLUMN alert_rules.selected_campaigns IS 'Array of campaign names to include or exclude';
COMMENT ON COLUMN alert_rules.campaign_selection_mode IS 'all = no filter, include = only selected, exclude = all except selected';
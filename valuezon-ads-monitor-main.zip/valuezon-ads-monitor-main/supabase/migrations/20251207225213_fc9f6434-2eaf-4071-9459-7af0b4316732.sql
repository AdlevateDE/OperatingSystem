-- Add account_ids array column to alert_rules
ALTER TABLE public.alert_rules 
ADD COLUMN account_ids uuid[] DEFAULT NULL;

-- Migrate existing data: copy account_id to account_ids array
UPDATE public.alert_rules 
SET account_ids = ARRAY[account_id]
WHERE account_id IS NOT NULL AND account_ids IS NULL;

-- Create index for better performance on array queries
CREATE INDEX idx_alert_rules_account_ids ON public.alert_rules USING GIN(account_ids);

-- Update RLS policies to check against account_ids array

-- Drop existing policies
DROP POLICY IF EXISTS "Users can view accessible alert rules" ON public.alert_rules;
DROP POLICY IF EXISTS "Users can insert alert rules" ON public.alert_rules;
DROP POLICY IF EXISTS "Users can update accessible alert rules" ON public.alert_rules;
DROP POLICY IF EXISTS "Owners/editors can delete alert rules" ON public.alert_rules;

-- Recreate policies using account_ids array
CREATE POLICY "Users can view accessible alert rules" 
ON public.alert_rules 
FOR SELECT 
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = ANY(alert_rules.account_ids)
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert alert rules" 
ON public.alert_rules 
FOR INSERT 
WITH CHECK (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = ANY(alert_rules.account_ids)
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible alert rules" 
ON public.alert_rules 
FOR UPDATE 
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = ANY(alert_rules.account_ids)
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Owners/editors can delete alert rules" 
ON public.alert_rules 
FOR DELETE 
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = ANY(alert_rules.account_ids)
    AND account_users.user_id = auth.uid()
    AND account_users.role = ANY(ARRAY['owner'::account_role, 'editor'::account_role])
  )
);
-- Lösche alte falsche Cron-Jobs
SELECT cron.unschedule(2);
SELECT cron.unschedule(3);

-- Erstelle korrigierte Cron-Jobs mit richtigen Uhrzeiten
-- Morning: 10:00 UTC = 11:00 DE (Winterzeit)
SELECT cron.schedule(
  'check-alerts-morning',
  '0 10 * * *',
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/check-scheduled-alerts',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{"triggered_at": "morning"}'::jsonb
  ) as request_id;
  $$
);

-- Evening: 16:00 UTC = 17:00 DE (Winterzeit)
SELECT cron.schedule(
  'check-alerts-evening',
  '0 16 * * *',
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/check-scheduled-alerts',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{"triggered_at": "evening"}'::jsonb
  ) as request_id;
  $$
);
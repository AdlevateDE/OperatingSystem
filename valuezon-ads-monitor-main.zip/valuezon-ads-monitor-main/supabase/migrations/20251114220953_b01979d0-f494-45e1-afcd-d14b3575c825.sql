-- Link Twistout account to existing user
UPDATE amazon_accounts 
SET user_id = '7c415601-f23d-49c5-8fbd-b74255463f5f' 
WHERE account_name = 'Twistout' AND user_id IS NULL;
-- Step 1: Delete 10 old test rules
DELETE FROM public.alert_rules 
WHERE id IN (
  '3d478fb3-6237-49bf-8b25-e76b274ae071',
  '6384f5e7-0414-4284-9c85-781fdd78b0d7',
  '97c5456c-8100-41f2-88bc-e7bb6bbd8d7b',
  '8337f34b-4b31-4923-9d7c-3beccd0f8f98',
  'a5a228b1-fe29-42c4-8d73-d3d160433c42',
  'af8e24a8-c99d-428f-a5c7-ef1df25b8a9d',
  '0c66ae98-9f7a-4f27-a0f6-ed2725e8b25c',
  '9bb5dba3-b2ab-42e0-bb3b-a168864e0892',
  'a0cc4a3f-b57d-4f63-baff-92ec80e18e6f',
  '8f84f053-8de1-4593-94d0-897fa577773c'
);

-- Step 2: Insert 22 new test rules

-- Group 1: All Metrics (SP/Twistout) - 7 rules covering all 6 metrics + 1 absolute threshold
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode)
VALUES 
  ('SP_Cost_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Clicks_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'clicks', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Impressions_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'impressions', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_CPC_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cpc', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_CTR_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'ctr', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_ACoS_1%_7Tage', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'acos', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Cost_Absolut_1EUR', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 1, 'absolute', 'last_7_days', 'increases', ARRAY['sp'], true, 'daily', 'AND', 'all');

-- Group 2: All Comparison Periods (SP/Twistout)
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode)
VALUES 
  ('SP_Cost_Gestern_5%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'yesterday', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Cost_SameDayLastWeek_5%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'same_day_last_week', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Cost_14Tage_5%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_14_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all'),
  ('SP_Cost_30Tage_5%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_30_days', 'both', ARRAY['sp'], true, 'daily', 'AND', 'all');

-- Group 3: SB/SD Campaign Types (Third of Life)
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode)
VALUES 
  ('SB_Cost_1%_7Tage', '13b38e13-ed85-45bf-a921-946cd96f5102', ARRAY['13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'cost', 1, 'percentage', 'last_7_days', 'both', ARRAY['sb'], true, 'daily', 'AND', 'all'),
  ('SB_Clicks_1%_7Tage', '13b38e13-ed85-45bf-a921-946cd96f5102', ARRAY['13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'clicks', 1, 'percentage', 'last_7_days', 'both', ARRAY['sb'], true, 'daily', 'AND', 'all'),
  ('SD_Cost_1%_7Tage', '13b38e13-ed85-45bf-a921-946cd96f5102', ARRAY['13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'cost', 1, 'percentage', 'last_7_days', 'both', ARRAY['sd'], true, 'daily', 'AND', 'all'),
  ('SD_Clicks_1%_7Tage', '13b38e13-ed85-45bf-a921-946cd96f5102', ARRAY['13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'clicks', 1, 'percentage', 'last_7_days', 'both', ARRAY['sd'], true, 'daily', 'AND', 'all');

-- Group 4: Multi-Condition Logic (SP/Twistout)
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode, alert_conditions)
VALUES 
  ('MultiCond_AND_Cost+Clicks', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_7_days', 'increases', ARRAY['sp'], true, 'daily', 'AND', 'all', '[{"metric": "clicks", "direction": "decreases", "threshold": 5, "thresholdType": "percentage"}]'::jsonb),
  ('MultiCond_OR_Cost+ACoS', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 10, 'percentage', 'last_7_days', 'increases', ARRAY['sp'], true, 'daily', 'OR', 'all', '[{"metric": "acos", "direction": "increases", "threshold": 10, "thresholdType": "percentage"}]'::jsonb);

-- Group 5: Campaign Selection (inactive, need manual campaign selection)
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode, selected_campaigns)
VALUES 
  ('SP_Include_2Campaigns', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_7_days', 'both', ARRAY['sp'], false, 'daily', 'AND', 'include', ARRAY[]::text[]),
  ('SP_Exclude_1Campaign', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_7_days', 'both', ARRAY['sp'], false, 'daily', 'AND', 'exclude', ARRAY[]::text[]);

-- Group 6: Multi-Account & Directions
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode)
VALUES 
  ('MultiAccount_Cost_1%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e', '13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'cost', 1, 'percentage', 'last_7_days', 'both', ARRAY['sp', 'sb', 'sd'], true, 'daily', 'AND', 'all'),
  ('SP_Decreases_Only_5%', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e']::uuid[], 'cost', 5, 'percentage', 'last_7_days', 'decreases', ARRAY['sp'], true, 'daily', 'AND', 'all');

-- Multi-Account with Pre-Filter
INSERT INTO public.alert_rules (rule_name, account_id, account_ids, metric_name, threshold_percent, threshold_type, comparison_period, alert_direction, campaign_types, is_active, check_frequency, alert_conditions_logic, campaign_selection_mode, campaign_filters, campaign_filters_logic)
VALUES 
  ('MultiAccount_PreFilter_10EUR', 'c399c4e1-11ba-4988-a4fc-dc91c028592e', ARRAY['c399c4e1-11ba-4988-a4fc-dc91c028592e', '13b38e13-ed85-45bf-a921-946cd96f5102']::uuid[], 'cost', 5, 'percentage', 'last_7_days', 'both', ARRAY['sp', 'sb', 'sd'], true, 'daily', 'AND', 'all', '[{"metric": "cost", "operator": ">=", "value": 10}]'::jsonb, 'AND');
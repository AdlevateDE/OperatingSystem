-- 1. Erweitere alerts Tabelle
ALTER TABLE alerts 
ADD COLUMN IF NOT EXISTS run_type VARCHAR(20) CHECK (run_type IN ('scheduled', 'manual')),
ADD COLUMN IF NOT EXISTS is_all_clear BOOLEAN DEFAULT false;

-- Make rule_id nullable
ALTER TABLE alerts 
ALTER COLUMN rule_id DROP NOT NULL;

-- 2. Erweitere alert_items Tabelle
ALTER TABLE alert_items 
ADD COLUMN IF NOT EXISTS rule_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS account_name VARCHAR(255),
ADD COLUMN IF NOT EXISTS date DATE;

-- Update date column to NOT NULL after it's created (in case there's existing data)
-- We'll set a default for existing rows first
UPDATE alert_items SET date = CURRENT_DATE WHERE date IS NULL;
ALTER TABLE alert_items ALTER COLUMN date SET NOT NULL;

-- 3. Erstelle Indexe für bessere Performance
CREATE INDEX IF NOT EXISTS idx_alert_items_date ON alert_items(date);
CREATE INDEX IF NOT EXISTS idx_alerts_run_type ON alerts(run_type);

-- 4. Kommentar für Dokumentation
COMMENT ON COLUMN alert_items.date IS 'Das Datum der Metrik (für historische Daten im Google Sheet)';
COMMENT ON COLUMN alerts.run_type IS 'scheduled = automatisch um 9 Uhr, manual = manuell getriggert';
COMMENT ON COLUMN alerts.is_all_clear IS 'true wenn keine Alerts ausgelöst wurden (Alles grün)';
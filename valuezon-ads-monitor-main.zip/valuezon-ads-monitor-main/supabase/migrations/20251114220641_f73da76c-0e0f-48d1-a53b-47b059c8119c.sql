-- Remove check_time field from alert_rules
ALTER TABLE alert_rules DROP COLUMN IF EXISTS check_time;

-- Drop the index we created
DROP INDEX IF EXISTS idx_alert_rules_check_time;

-- Delete old hourly cron job
SELECT cron.unschedule('check-scheduled-alerts-hourly');
-- Fix RLS policy for amazon_accounts by recreating it
DROP POLICY IF EXISTS "Users can view accessible accounts" ON amazon_accounts;

CREATE POLICY "Users can view accessible accounts"
ON amazon_accounts
FOR SELECT
TO authenticated
USING (
  id IN (
    SELECT account_id 
    FROM account_users 
    WHERE user_id = auth.uid()
  )
);
-- Add check_schedule column to alert_rules table
ALTER TABLE alert_rules 
ADD COLUMN check_schedule TEXT DEFAULT 'both' CHECK (check_schedule IN ('morning', 'evening', 'both'));

-- Add comment for documentation
COMMENT ON COLUMN alert_rules.check_schedule IS 'Schedule for alert checks: morning (11:00), evening (17:00), or both';
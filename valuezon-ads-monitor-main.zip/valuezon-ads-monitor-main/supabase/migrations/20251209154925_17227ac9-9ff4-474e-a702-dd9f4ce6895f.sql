-- Fix pending_reports RLS: Only service role should have access, not all authenticated users
-- First drop the overly permissive policy
DROP POLICY IF EXISTS "Service role has full access to pending_reports" ON pending_reports;

-- Create proper restrictive policies for pending_reports
-- Users can only SELECT reports for their own profiles
CREATE POLICY "Users can view own pending reports"
ON pending_reports FOR SELECT TO authenticated
USING (
  profile_id IN (
    SELECT aa.profile_id FROM amazon_accounts aa
    JOIN account_users au ON au.account_id = aa.id
    WHERE au.user_id = auth.uid()
  )
);

-- Only service role can INSERT/UPDATE/DELETE (edge functions use service role)
-- No policy needed - by default authenticated users can't modify without a policy
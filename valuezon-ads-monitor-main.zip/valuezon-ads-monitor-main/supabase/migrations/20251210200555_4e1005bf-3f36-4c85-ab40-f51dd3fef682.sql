-- Alten Job löschen
SELECT cron.unschedule('process-pending-reports-every-5min');

-- Neuen Job mit korrektem Funktionsnamen erstellen
SELECT cron.schedule(
  'process-sp-reports',
  '*/5 * * * *',
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/process-pending-reports-sp',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{}'::jsonb
  ) AS request_id;
  $$
);
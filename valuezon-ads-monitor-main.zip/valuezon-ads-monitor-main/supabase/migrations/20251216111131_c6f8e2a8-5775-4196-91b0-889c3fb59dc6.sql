
-- Disable only the on_account_created trigger
ALTER TABLE amazon_accounts DISABLE TRIGGER on_account_created;

-- Insert Third of Life DE account
INSERT INTO amazon_accounts (
  account_name,
  profile_id,
  marketplace,
  currency_code,
  refresh_token_key,
  user_id,
  is_active
) VALUES (
  'Third of Life DE',
  '3414462264809817',
  'DE',
  'EUR',
  'AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE',
  '7c415601-f23d-49c5-8fbd-b74255463f5f',
  true
);

-- Re-enable the trigger
ALTER TABLE amazon_accounts ENABLE TRIGGER on_account_created;

-- Manually add the account_users entry
INSERT INTO account_users (account_id, user_id, role)
SELECT id, '7c415601-f23d-49c5-8fbd-b74255463f5f', 'owner'
FROM amazon_accounts 
WHERE profile_id = '3414462264809817';

-- Add campaign_types column to alert_rules table
ALTER TABLE alert_rules 
ADD COLUMN campaign_types text[] DEFAULT ARRAY['sp'];

-- Add check constraint to ensure only valid campaign types
ALTER TABLE alert_rules
ADD CONSTRAINT valid_campaign_types 
CHECK (campaign_types <@ ARRAY['sp', 'sb', 'sd']);

-- Update existing rules to have default value
UPDATE alert_rules 
SET campaign_types = ARRAY['sp'] 
WHERE campaign_types IS NULL;
-- Enable pg_cron extension if not already enabled
CREATE EXTENSION IF NOT EXISTS pg_cron;

-- Schedule hourly check for alert rules
SELECT cron.schedule(
  'check-scheduled-alerts-hourly',
  '0 * * * *', -- Every hour at minute 0
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/check-scheduled-alerts',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{}'::jsonb
  ) as request_id;
  $$
);
-- Add missing columns to campaign_metrics_sp table
ALTER TABLE campaign_metrics_sp
ADD COLUMN campaign_name text,
ADD COLUMN campaign_status text,
ADD COLUMN campaign_budget_type text,
ADD COLUMN campaign_budget_amount numeric,
ADD COLUMN campaign_budget_currency_code text;

-- Add index for better performance when searching by campaign name
CREATE INDEX idx_campaign_metrics_sp_campaign_name ON campaign_metrics_sp(campaign_name);
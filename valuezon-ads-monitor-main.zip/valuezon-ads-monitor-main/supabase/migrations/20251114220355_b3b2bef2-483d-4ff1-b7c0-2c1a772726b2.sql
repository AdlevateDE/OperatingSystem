-- Enable RLS on all public tables
ALTER TABLE users ENABLE ROW LEVEL SECURITY;
ALTER TABLE amazon_accounts ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaigns ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_metrics_sp ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_metrics_sb ENABLE ROW LEVEL SECURITY;
ALTER TABLE campaign_metrics_sd ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_rules ENABLE ROW LEVEL SECURITY;
ALTER TABLE alerts ENABLE ROW LEVEL SECURITY;
ALTER TABLE alert_items ENABLE ROW LEVEL SECURITY;
ALTER TABLE cleanup_trigger ENABLE ROW LEVEL SECURITY;

-- ========================================
-- USERS TABLE POLICIES (PII - sehr restriktiv)
-- ========================================

-- Users can read their own profile
CREATE POLICY "Users can view own profile"
ON users FOR SELECT
TO authenticated
USING (id = auth.uid());

-- Users can update their own profile
CREATE POLICY "Users can update own profile"
ON users FOR UPDATE
TO authenticated
USING (id = auth.uid())
WITH CHECK (id = auth.uid());

-- Users can insert their own profile (registration)
CREATE POLICY "Users can insert own profile"
ON users FOR INSERT
TO authenticated
WITH CHECK (id = auth.uid());

-- ========================================
-- AMAZON_ACCOUNTS TABLE POLICIES
-- ========================================

-- Users can view their own accounts
CREATE POLICY "Users can view own accounts"
ON amazon_accounts FOR SELECT
TO authenticated
USING (user_id = auth.uid());

-- Users can insert their own accounts
CREATE POLICY "Users can insert own accounts"
ON amazon_accounts FOR INSERT
TO authenticated
WITH CHECK (user_id = auth.uid());

-- Users can update their own accounts
CREATE POLICY "Users can update own accounts"
ON amazon_accounts FOR UPDATE
TO authenticated
USING (user_id = auth.uid())
WITH CHECK (user_id = auth.uid());

-- Users can delete their own accounts
CREATE POLICY "Users can delete own accounts"
ON amazon_accounts FOR DELETE
TO authenticated
USING (user_id = auth.uid());

-- ========================================
-- CAMPAIGNS TABLE POLICIES
-- ========================================

-- Users can view campaigns from their accounts
CREATE POLICY "Users can view own campaigns"
ON campaigns FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = campaigns.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- Users can insert campaigns to their accounts
CREATE POLICY "Users can insert own campaigns"
ON campaigns FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = campaigns.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- Users can update campaigns from their accounts
CREATE POLICY "Users can update own campaigns"
ON campaigns FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = campaigns.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = campaigns.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- Users can delete campaigns from their accounts
CREATE POLICY "Users can delete own campaigns"
ON campaigns FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = campaigns.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- CAMPAIGN_METRICS_SP TABLE POLICIES
-- ========================================

-- Users can view metrics from their campaigns
CREATE POLICY "Users can view own campaign metrics sp"
ON campaign_metrics_sp FOR SELECT
TO authenticated
USING (
  profile_id IN (
    SELECT profile_id FROM amazon_accounts
    WHERE user_id = auth.uid()
  )
);

-- Users can insert metrics to their campaigns
CREATE POLICY "Users can insert own campaign metrics sp"
ON campaign_metrics_sp FOR INSERT
TO authenticated
WITH CHECK (
  profile_id IN (
    SELECT profile_id FROM amazon_accounts
    WHERE user_id = auth.uid()
  )
);

-- Users can update metrics from their campaigns
CREATE POLICY "Users can update own campaign metrics sp"
ON campaign_metrics_sp FOR UPDATE
TO authenticated
USING (
  profile_id IN (
    SELECT profile_id FROM amazon_accounts
    WHERE user_id = auth.uid()
  )
)
WITH CHECK (
  profile_id IN (
    SELECT profile_id FROM amazon_accounts
    WHERE user_id = auth.uid()
  )
);

-- Users can delete metrics from their campaigns
CREATE POLICY "Users can delete own campaign metrics sp"
ON campaign_metrics_sp FOR DELETE
TO authenticated
USING (
  profile_id IN (
    SELECT profile_id FROM amazon_accounts
    WHERE user_id = auth.uid()
  )
);

-- ========================================
-- CAMPAIGN_METRICS_SB TABLE POLICIES
-- ========================================

CREATE POLICY "Users can view own campaign metrics sb"
ON campaign_metrics_sb FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sb.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert own campaign metrics sb"
ON campaign_metrics_sb FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sb.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update own campaign metrics sb"
ON campaign_metrics_sb FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sb.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sb.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete own campaign metrics sb"
ON campaign_metrics_sb FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sb.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- CAMPAIGN_METRICS_SD TABLE POLICIES
-- ========================================

CREATE POLICY "Users can view own campaign metrics sd"
ON campaign_metrics_sd FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sd.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert own campaign metrics sd"
ON campaign_metrics_sd FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sd.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update own campaign metrics sd"
ON campaign_metrics_sd FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sd.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sd.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete own campaign metrics sd"
ON campaign_metrics_sd FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns
    JOIN amazon_accounts ON campaigns.account_id = amazon_accounts.id
    WHERE campaigns.id = campaign_metrics_sd.campaign_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- ALERT_RULES TABLE POLICIES
-- ========================================

CREATE POLICY "Users can view own alert rules"
ON alert_rules FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alert_rules.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert own alert rules"
ON alert_rules FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alert_rules.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update own alert rules"
ON alert_rules FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alert_rules.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alert_rules.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete own alert rules"
ON alert_rules FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alert_rules.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- ALERTS TABLE POLICIES
-- ========================================

CREATE POLICY "Users can view own alerts"
ON alerts FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alerts.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert own alerts"
ON alerts FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alerts.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update own alerts"
ON alerts FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alerts.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alerts.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete own alerts"
ON alerts FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM amazon_accounts
    WHERE amazon_accounts.id = alerts.account_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- ALERT_ITEMS TABLE POLICIES
-- ========================================

CREATE POLICY "Users can view own alert items"
ON alert_items FOR SELECT
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts
    JOIN amazon_accounts ON alerts.account_id = amazon_accounts.id
    WHERE alerts.id = alert_items.alert_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert own alert items"
ON alert_items FOR INSERT
TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM alerts
    JOIN amazon_accounts ON alerts.account_id = amazon_accounts.id
    WHERE alerts.id = alert_items.alert_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update own alert items"
ON alert_items FOR UPDATE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts
    JOIN amazon_accounts ON alerts.account_id = amazon_accounts.id
    WHERE alerts.id = alert_items.alert_id
    AND amazon_accounts.user_id = auth.uid()
  )
)
WITH CHECK (
  EXISTS (
    SELECT 1 FROM alerts
    JOIN amazon_accounts ON alerts.account_id = amazon_accounts.id
    WHERE alerts.id = alert_items.alert_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete own alert items"
ON alert_items FOR DELETE
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts
    JOIN amazon_accounts ON alerts.account_id = amazon_accounts.id
    WHERE alerts.id = alert_items.alert_id
    AND amazon_accounts.user_id = auth.uid()
  )
);

-- ========================================
-- CLEANUP_TRIGGER TABLE POLICIES
-- ========================================
-- This is a system table, only service role should access it
CREATE POLICY "Only service role can access cleanup_trigger"
ON cleanup_trigger FOR ALL
TO service_role
USING (true)
WITH CHECK (true);
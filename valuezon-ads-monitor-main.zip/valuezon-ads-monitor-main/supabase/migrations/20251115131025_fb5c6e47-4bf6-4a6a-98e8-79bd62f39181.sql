-- Add campaign_name to alert_items table
ALTER TABLE alert_items
ADD COLUMN campaign_name text;
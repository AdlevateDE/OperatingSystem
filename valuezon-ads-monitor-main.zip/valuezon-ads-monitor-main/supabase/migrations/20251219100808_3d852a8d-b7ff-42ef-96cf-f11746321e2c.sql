-- Drop existing restrictive SELECT policies and replace with simpler ones for all authenticated users

-- 1. amazon_accounts - Allow all authenticated users to view all accounts
DROP POLICY IF EXISTS "Users can view accessible accounts" ON public.amazon_accounts;
CREATE POLICY "Authenticated users can view all accounts" 
ON public.amazon_accounts 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

-- 2. alert_rules - Allow all authenticated users to view, create, and update all rules
DROP POLICY IF EXISTS "Users can view accessible alert rules" ON public.alert_rules;
CREATE POLICY "Authenticated users can view all alert rules" 
ON public.alert_rules 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert alert rules" ON public.alert_rules;
CREATE POLICY "Authenticated users can insert alert rules" 
ON public.alert_rules 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible alert rules" ON public.alert_rules;
CREATE POLICY "Authenticated users can update alert rules" 
ON public.alert_rules 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- 3. alerts - Allow all authenticated users to view and manage alerts
DROP POLICY IF EXISTS "Users can view accessible alerts" ON public.alerts;
CREATE POLICY "Authenticated users can view all alerts" 
ON public.alerts 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert alerts" ON public.alerts;
CREATE POLICY "Authenticated users can insert alerts" 
ON public.alerts 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible alerts" ON public.alerts;
CREATE POLICY "Authenticated users can update alerts" 
ON public.alerts 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- 4. alert_items - Allow all authenticated users to view and manage alert items
DROP POLICY IF EXISTS "Users can view accessible alert items" ON public.alert_items;
CREATE POLICY "Authenticated users can view all alert items" 
ON public.alert_items 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert alert items" ON public.alert_items;
CREATE POLICY "Authenticated users can insert alert items" 
ON public.alert_items 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible alert items" ON public.alert_items;
CREATE POLICY "Authenticated users can update alert items" 
ON public.alert_items 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can delete accessible alert items" ON public.alert_items;
CREATE POLICY "Authenticated users can delete alert items" 
ON public.alert_items 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- 5. campaigns - Allow all authenticated users to view and manage campaigns
DROP POLICY IF EXISTS "Users can view accessible campaigns" ON public.campaigns;
CREATE POLICY "Authenticated users can view all campaigns" 
ON public.campaigns 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert campaigns" ON public.campaigns;
CREATE POLICY "Authenticated users can insert campaigns" 
ON public.campaigns 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible campaigns" ON public.campaigns;
CREATE POLICY "Authenticated users can update campaigns" 
ON public.campaigns 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

-- 6. campaign_metrics_sp - Allow all authenticated users to view and manage SP metrics
DROP POLICY IF EXISTS "Users can view accessible metrics sp" ON public.campaign_metrics_sp;
CREATE POLICY "Authenticated users can view all metrics sp" 
ON public.campaign_metrics_sp 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert metrics sp" ON public.campaign_metrics_sp;
CREATE POLICY "Authenticated users can insert metrics sp" 
ON public.campaign_metrics_sp 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible metrics sp" ON public.campaign_metrics_sp;
CREATE POLICY "Authenticated users can update metrics sp" 
ON public.campaign_metrics_sp 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can delete accessible metrics sp" ON public.campaign_metrics_sp;
CREATE POLICY "Authenticated users can delete metrics sp" 
ON public.campaign_metrics_sp 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- 7. campaign_metrics_sb - Allow all authenticated users to view and manage SB metrics
DROP POLICY IF EXISTS "Users can view accessible metrics sb" ON public.campaign_metrics_sb;
CREATE POLICY "Authenticated users can view all metrics sb" 
ON public.campaign_metrics_sb 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert metrics sb" ON public.campaign_metrics_sb;
CREATE POLICY "Authenticated users can insert metrics sb" 
ON public.campaign_metrics_sb 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible metrics sb" ON public.campaign_metrics_sb;
CREATE POLICY "Authenticated users can update metrics sb" 
ON public.campaign_metrics_sb 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can delete accessible metrics sb" ON public.campaign_metrics_sb;
CREATE POLICY "Authenticated users can delete metrics sb" 
ON public.campaign_metrics_sb 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- 8. campaign_metrics_sd - Allow all authenticated users to view and manage SD metrics
DROP POLICY IF EXISTS "Users can view accessible metrics sd" ON public.campaign_metrics_sd;
CREATE POLICY "Authenticated users can view all metrics sd" 
ON public.campaign_metrics_sd 
FOR SELECT 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can insert metrics sd" ON public.campaign_metrics_sd;
CREATE POLICY "Authenticated users can insert metrics sd" 
ON public.campaign_metrics_sd 
FOR INSERT 
WITH CHECK (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can update accessible metrics sd" ON public.campaign_metrics_sd;
CREATE POLICY "Authenticated users can update metrics sd" 
ON public.campaign_metrics_sd 
FOR UPDATE 
USING (auth.uid() IS NOT NULL);

DROP POLICY IF EXISTS "Users can delete accessible metrics sd" ON public.campaign_metrics_sd;
CREATE POLICY "Authenticated users can delete metrics sd" 
ON public.campaign_metrics_sd 
FOR DELETE 
USING (auth.uid() IS NOT NULL);

-- 9. pending_reports - Allow all authenticated users to view pending reports
DROP POLICY IF EXISTS "Users can view own pending reports" ON public.pending_reports;
CREATE POLICY "Authenticated users can view all pending reports" 
ON public.pending_reports 
FOR SELECT 
USING (auth.uid() IS NOT NULL);
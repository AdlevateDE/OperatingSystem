-- Drop old constraint and add new one with all valid comparison periods
ALTER TABLE public.alert_rules DROP CONSTRAINT IF EXISTS check_comparison_period;

ALTER TABLE public.alert_rules ADD CONSTRAINT check_comparison_period 
CHECK (comparison_period IN ('yesterday', 'same_day_last_week', 'last_7_days', 'last_14_days', 'last_30_days', 'none'));
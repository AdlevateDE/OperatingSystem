-- Add alert_direction column to alert_rules
ALTER TABLE alert_rules
ADD COLUMN alert_direction text DEFAULT 'both' CHECK (alert_direction IN ('increases', 'decreases', 'both'));

-- Add alert_direction to alert_items for historical tracking
ALTER TABLE alert_items
ADD COLUMN alert_direction text;
-- Create junction table with roles
CREATE TYPE account_role AS ENUM ('owner', 'editor', 'viewer');

CREATE TABLE account_users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  account_id UUID NOT NULL REFERENCES amazon_accounts(id) ON DELETE CASCADE,
  user_id UUID NOT NULL REFERENCES users(id) ON DELETE CASCADE,
  role account_role NOT NULL DEFAULT 'viewer',
  created_at TIMESTAMP WITH TIME ZONE DEFAULT now(),
  UNIQUE(account_id, user_id)
);

ALTER TABLE account_users ENABLE ROW LEVEL SECURITY;

-- Policies for account_users
CREATE POLICY "Users can view own memberships"
ON account_users FOR SELECT
TO authenticated
USING (user_id = auth.uid());

CREATE POLICY "Owners can manage memberships"
ON account_users FOR ALL
TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users au
    WHERE au.account_id = account_users.account_id
    AND au.user_id = auth.uid()
    AND au.role = 'owner'
  )
);

CREATE INDEX idx_account_users_user_id ON account_users(user_id);
CREATE INDEX idx_account_users_account_id ON account_users(account_id);

-- Migrate existing data
INSERT INTO account_users (account_id, user_id, role)
SELECT id, user_id, 'owner'
FROM amazon_accounts
WHERE user_id IS NOT NULL
ON CONFLICT (account_id, user_id) DO NOTHING;

-- Create trigger for auto-owner on insert
CREATE OR REPLACE FUNCTION add_account_owner()
RETURNS TRIGGER
LANGUAGE plpgsql
SECURITY DEFINER
SET search_path = public
AS $$
BEGIN
  INSERT INTO account_users (account_id, user_id, role)
  VALUES (NEW.id, auth.uid(), 'owner');
  RETURN NEW;
END;
$$;

CREATE TRIGGER on_account_created
AFTER INSERT ON amazon_accounts
FOR EACH ROW
EXECUTE FUNCTION add_account_owner();
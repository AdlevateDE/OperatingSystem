-- Fix function search_path for security
ALTER FUNCTION public.delete_last15days_spcampaigns(json) SET search_path = public, pg_temp;
ALTER FUNCTION public.trigger_cleanup_sp() SET search_path = public, pg_temp;
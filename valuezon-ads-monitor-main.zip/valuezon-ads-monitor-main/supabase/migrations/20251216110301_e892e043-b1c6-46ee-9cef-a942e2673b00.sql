-- Add refresh_token_key column to amazon_accounts for multi-tenant token management
-- NULL = uses default AMAZON_REFRESH_TOKEN, otherwise uses the specified secret name

ALTER TABLE public.amazon_accounts 
ADD COLUMN refresh_token_key TEXT DEFAULT NULL;

-- Add comment for documentation
COMMENT ON COLUMN public.amazon_accounts.refresh_token_key IS 'Name of the Supabase secret containing the refresh token for this account. NULL means use default AMAZON_REFRESH_TOKEN.';
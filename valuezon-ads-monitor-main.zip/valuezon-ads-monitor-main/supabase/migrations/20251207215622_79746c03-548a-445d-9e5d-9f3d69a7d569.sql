-- Add threshold_type column to alert_rules table
-- 'percentage' = prozentuale Abweichung vom Vergleichszeitraum (existing behavior)
-- 'absolute' = absoluter Schwellenwert ohne Vergleichsperiode
ALTER TABLE alert_rules 
ADD COLUMN IF NOT EXISTS threshold_type text DEFAULT 'percentage' 
CHECK (threshold_type IN ('percentage', 'absolute'));
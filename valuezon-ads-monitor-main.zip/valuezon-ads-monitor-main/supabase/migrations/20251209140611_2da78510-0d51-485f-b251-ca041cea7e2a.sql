-- Add campaign pre-filter fields to alert_rules table
ALTER TABLE public.alert_rules 
ADD COLUMN IF NOT EXISTS campaign_filters jsonb DEFAULT NULL,
ADD COLUMN IF NOT EXISTS campaign_filters_logic text DEFAULT 'AND';

-- Add comment for documentation
COMMENT ON COLUMN public.alert_rules.campaign_filters IS 'Array of filter objects: [{metric, operator, value, period_days}]';
COMMENT ON COLUMN public.alert_rules.campaign_filters_logic IS 'Logic for combining filters: AND or OR';
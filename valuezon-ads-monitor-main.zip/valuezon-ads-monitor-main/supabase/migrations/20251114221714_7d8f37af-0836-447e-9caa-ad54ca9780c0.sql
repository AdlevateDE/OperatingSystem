-- Functions to avoid recursive RLS lookups and loosen access checks
create or replace function public.has_account_access(_account_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.account_users
    where account_id = _account_id
      and user_id = auth.uid()
  );
$$;

create or replace function public.has_account_editor_or_owner(_account_id uuid)
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.account_users
    where account_id = _account_id
      and user_id = auth.uid()
      and role = any (array['owner','editor']::public.account_role[])
  );
$$;

create or replace function public.is_account_owner(_account_id uuid, _user_id uuid default auth.uid())
returns boolean
language sql
stable
security definer
set search_path = public
as $$
  select exists (
    select 1 from public.account_users
    where account_id = _account_id
      and user_id = _user_id
      and role = 'owner'
  );
$$;

-- Recreate amazon_accounts policies using definer functions
DROP POLICY IF EXISTS "Users can view accessible accounts" ON public.amazon_accounts;
CREATE POLICY "Users can view accessible accounts" ON public.amazon_accounts
FOR SELECT TO authenticated
USING (public.has_account_access(id));

DROP POLICY IF EXISTS "Owners/editors can update accounts" ON public.amazon_accounts;
CREATE POLICY "Owners/editors can update accounts" ON public.amazon_accounts
FOR UPDATE TO authenticated
USING (public.has_account_editor_or_owner(id));

DROP POLICY IF EXISTS "Owners can delete accounts" ON public.amazon_accounts;
CREATE POLICY "Owners can delete accounts" ON public.amazon_accounts
FOR DELETE TO authenticated
USING (public.is_account_owner(id));

-- Fix recursive policy on account_users
DROP POLICY IF EXISTS "Owners can manage memberships" ON public.account_users;
CREATE POLICY "Owners can manage memberships" ON public.account_users
FOR ALL TO authenticated
USING (public.is_account_owner(account_id))
WITH CHECK (public.is_account_owner(account_id));

-- Create table for pending report jobs
CREATE TABLE public.pending_reports (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  profile_id TEXT NOT NULL,
  report_id TEXT NOT NULL,
  start_date DATE NOT NULL,
  end_date DATE NOT NULL,
  status TEXT NOT NULL DEFAULT 'pending',
  attempts INTEGER NOT NULL DEFAULT 0,
  last_attempt_at TIMESTAMP WITH TIME ZONE,
  download_url TEXT,
  error_message TEXT,
  trigger_alert_check BOOLEAN DEFAULT false,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  completed_at TIMESTAMP WITH TIME ZONE
);

-- Enable RLS
ALTER TABLE public.pending_reports ENABLE ROW LEVEL SECURITY;

-- Allow service role full access (edge functions use service role)
CREATE POLICY "Service role has full access to pending_reports"
ON public.pending_reports
FOR ALL
USING (true)
WITH CHECK (true);

-- Create index for efficient polling
CREATE INDEX idx_pending_reports_status ON public.pending_reports(status) WHERE status = 'pending';
CREATE INDEX idx_pending_reports_profile ON public.pending_reports(profile_id);
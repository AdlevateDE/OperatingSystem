-- Make user_id nullable in amazon_accounts table
ALTER TABLE amazon_accounts 
ALTER COLUMN user_id DROP NOT NULL;
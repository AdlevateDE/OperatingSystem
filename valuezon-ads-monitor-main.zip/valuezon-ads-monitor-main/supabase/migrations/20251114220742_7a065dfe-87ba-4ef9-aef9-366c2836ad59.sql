-- Create two cron jobs for 09:00 and 19:00
SELECT cron.schedule(
  'check-alerts-morning',
  '0 9 * * *', -- Every day at 09:00
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/check-scheduled-alerts',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{"triggered_at": "09:00"}'::jsonb
  ) as request_id;
  $$
);

SELECT cron.schedule(
  'check-alerts-evening',
  '0 19 * * *', -- Every day at 19:00
  $$
  SELECT net.http_post(
    url := 'https://zczzfbjlaxbhutttnvox.supabase.co/functions/v1/check-scheduled-alerts',
    headers := '{"Content-Type": "application/json", "Authorization": "Bearer eyJhbGciOiJIUzI1NiIsInR5cCI6IkpXVCJ9.eyJpc3MiOiJzdXBhYmFzZSIsInJlZiI6InpjenpmYmpsYXhiaHV0dHRudm94Iiwicm9sZSI6ImFub24iLCJpYXQiOjE3NjMwNjE1NzgsImV4cCI6MjA3ODYzNzU3OH0.CJ8saU_ZCFZ6a1SOTzVCPgqpyQrfFGymQPLFeZQMeyQ"}'::jsonb,
    body := '{"triggered_at": "19:00"}'::jsonb
  ) as request_id;
  $$
);
-- Create function_runs table for robust run logging (blackbox recorder)
CREATE TABLE public.function_runs (
  id UUID NOT NULL DEFAULT gen_random_uuid() PRIMARY KEY,
  function_name TEXT NOT NULL,
  started_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now(),
  finished_at TIMESTAMP WITH TIME ZONE,
  status TEXT NOT NULL DEFAULT 'running', -- running, success, failed, timeout
  trigger_source TEXT, -- morning_cron, evening_cron, manual, retry
  error_message TEXT,
  error_stack TEXT,
  metadata JSONB DEFAULT '{}'::jsonb,
  duration_ms INTEGER,
  created_at TIMESTAMP WITH TIME ZONE NOT NULL DEFAULT now()
);

-- Enable RLS
ALTER TABLE public.function_runs ENABLE ROW LEVEL SECURITY;

-- Allow service role full access (edge functions use service role)
CREATE POLICY "Service role can manage function_runs"
  ON public.function_runs
  FOR ALL
  USING (true)
  WITH CHECK (true);

-- Create index for quick lookups
CREATE INDEX idx_function_runs_function_name ON public.function_runs(function_name);
CREATE INDEX idx_function_runs_status ON public.function_runs(status);
CREATE INDEX idx_function_runs_started_at ON public.function_runs(started_at DESC);

-- Add comment
COMMENT ON TABLE public.function_runs IS 'Tracks edge function executions for debugging when edge logs are unavailable';
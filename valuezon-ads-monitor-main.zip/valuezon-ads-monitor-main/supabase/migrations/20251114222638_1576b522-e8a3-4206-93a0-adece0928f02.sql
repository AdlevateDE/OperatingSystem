-- Step 1: Temporarily change the email of the old user to avoid unique constraint violation
UPDATE public.users 
SET email = 'old_' || email
WHERE email = 'kundenservice@adlevate.de' 
  AND id = '7c415601-f23d-49c5-8fbd-b7425546f5f2';

-- Step 2: Insert new user entry with correct ID matching auth.users
INSERT INTO public.users (id, email, full_name)
VALUES (
  '7c415601-f23d-49c5-8fbd-b74255463f5f',
  'kundenservice@adlevate.de',
  'Kundenservice'
);

-- Step 3: Update amazon_accounts to use correct user_id
UPDATE public.amazon_accounts
SET user_id = '7c415601-f23d-49c5-8fbd-b74255463f5f'
WHERE user_id = '7c415601-f23d-49c5-8fbd-b7425546f5f2';

-- Step 4: Update account_users entries
UPDATE public.account_users
SET user_id = '7c415601-f23d-49c5-8fbd-b74255463f5f'
WHERE user_id = '7c415601-f23d-49c5-8fbd-b7425546f5f2';

-- Step 5: Delete the old user entry
DELETE FROM public.users
WHERE id = '7c415601-f23d-49c5-8fbd-b7425546f5f2';

-- Step 6: Add unique constraint to prevent duplicate memberships
DO $$ 
BEGIN
  IF NOT EXISTS (
    SELECT 1 FROM pg_constraint 
    WHERE conname = 'account_users_account_user_unique'
  ) THEN
    ALTER TABLE public.account_users 
    ADD CONSTRAINT account_users_account_user_unique 
    UNIQUE (account_id, user_id);
  END IF;
END $$;
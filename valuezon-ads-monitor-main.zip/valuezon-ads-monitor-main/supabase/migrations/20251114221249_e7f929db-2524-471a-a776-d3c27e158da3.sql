-- Fix user_id mismatch first
-- Step 1: Create new user with correct ID from JWT
INSERT INTO users (id, email, full_name)
VALUES (
  '7c415601-f23d-49c5-8fbd-b7425546f5f2', 
  'kundenservice+temp@adlevate.de',
  'Kundenservice'
);

-- Step 2: Update amazon_accounts to use correct user_id  
UPDATE amazon_accounts 
SET user_id = '7c415601-f23d-49c5-8fbd-b7425546f5f2' 
WHERE user_id = '7c415601-f23d-49c5-8fbd-b74255463f5f';

-- Step 3: Delete old user
DELETE FROM users WHERE id = '7c415601-f23d-49c5-8fbd-b74255463f5f';

-- Step 4: Fix email
UPDATE users 
SET email = 'kundenservice@adlevate.de'
WHERE id = '7c415601-f23d-49c5-8fbd-b7425546f5f2';
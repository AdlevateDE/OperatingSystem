-- Insert Twistout account
INSERT INTO amazon_accounts (account_name, profile_id, marketplace, currency_code, is_active)
VALUES ('Twistout', '2217651676157211', 'DE', 'EUR', true);
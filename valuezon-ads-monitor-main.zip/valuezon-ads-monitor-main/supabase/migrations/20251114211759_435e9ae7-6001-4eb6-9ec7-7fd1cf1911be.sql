-- Drop ALL foreign key constraints on profile_id
ALTER TABLE campaign_metrics_sp
DROP CONSTRAINT IF EXISTS campaign_metrics_sp_profile_id_fkey;

ALTER TABLE campaign_metrics_sp
DROP CONSTRAINT IF EXISTS campaign_metrics_sp_account_id_fkey;

-- Change profile_id from UUID to TEXT
ALTER TABLE campaign_metrics_sp
ALTER COLUMN profile_id TYPE TEXT USING profile_id::TEXT;

-- Update existing data: replace UUID with actual Amazon profile_id
UPDATE campaign_metrics_sp
SET profile_id = (
  SELECT profile_id 
  FROM amazon_accounts 
  WHERE id::TEXT = campaign_metrics_sp.profile_id
  LIMIT 1
);

-- Recreate index
DROP INDEX IF EXISTS idx_campaign_metrics_sp_profile_id;
CREATE INDEX idx_campaign_metrics_sp_profile_id ON campaign_metrics_sp(profile_id);

-- Add comment to clarify what profile_id now stores
COMMENT ON COLUMN campaign_metrics_sp.profile_id IS 'Amazon Advertising Profile ID (e.g., 2217651676157211)';
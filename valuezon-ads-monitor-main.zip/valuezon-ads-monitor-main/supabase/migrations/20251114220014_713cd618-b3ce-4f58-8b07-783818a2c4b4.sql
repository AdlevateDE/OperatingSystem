-- Add check_time field to alert_rules table
ALTER TABLE alert_rules
ADD COLUMN check_time time without time zone DEFAULT '09:00:00' NOT NULL;

-- Add comment
COMMENT ON COLUMN alert_rules.check_time IS 'Time of day when the alert rule should be checked (format: HH:MM:SS)';

-- Create index for faster lookups by time
CREATE INDEX idx_alert_rules_check_time ON alert_rules(check_time) WHERE is_active = true;
-- Trigger temporär deaktivieren
ALTER TABLE amazon_accounts DISABLE TRIGGER on_account_created;

-- Account einfügen
INSERT INTO amazon_accounts (
  user_id,
  profile_id,
  account_name,
  marketplace,
  currency_code,
  is_active
)
VALUES (
  '7c415601-f23d-49c5-8fbd-b74255463f5f',
  '7777777777777777',
  'Liqui Moly',
  'DE',
  'EUR',
  true
);

-- Account-User Beziehung manuell einfügen
INSERT INTO account_users (account_id, user_id, role)
SELECT id, '7c415601-f23d-49c5-8fbd-b74255463f5f', 'owner'
FROM amazon_accounts
WHERE profile_id = '7777777777777777'
AND NOT EXISTS (
  SELECT 1 FROM account_users 
  WHERE account_id = amazon_accounts.id
);

-- Trigger wieder aktivieren
ALTER TABLE amazon_accounts ENABLE TRIGGER on_account_created;
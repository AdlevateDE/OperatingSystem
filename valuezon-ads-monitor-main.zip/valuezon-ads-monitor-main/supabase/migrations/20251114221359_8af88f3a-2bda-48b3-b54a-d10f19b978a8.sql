-- Update campaign_metrics_sp policies
DROP POLICY IF EXISTS "Users can view own campaign metrics sp" ON campaign_metrics_sp;
DROP POLICY IF EXISTS "Users can insert own campaign metrics sp" ON campaign_metrics_sp;
DROP POLICY IF EXISTS "Users can update own campaign metrics sp" ON campaign_metrics_sp;
DROP POLICY IF EXISTS "Users can delete own campaign metrics sp" ON campaign_metrics_sp;

CREATE POLICY "Users can view accessible metrics sp"
ON campaign_metrics_sp FOR SELECT TO authenticated
USING (
  profile_id IN (
    SELECT aa.profile_id 
    FROM amazon_accounts aa
    JOIN account_users au ON au.account_id = aa.id
    WHERE au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert metrics sp"
ON campaign_metrics_sp FOR INSERT TO authenticated
WITH CHECK (
  profile_id IN (
    SELECT aa.profile_id 
    FROM amazon_accounts aa
    JOIN account_users au ON au.account_id = aa.id
    WHERE au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible metrics sp"
ON campaign_metrics_sp FOR UPDATE TO authenticated
USING (
  profile_id IN (
    SELECT aa.profile_id 
    FROM amazon_accounts aa
    JOIN account_users au ON au.account_id = aa.id
    WHERE au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete accessible metrics sp"
ON campaign_metrics_sp FOR DELETE TO authenticated
USING (
  profile_id IN (
    SELECT aa.profile_id 
    FROM amazon_accounts aa
    JOIN account_users au ON au.account_id = aa.id
    WHERE au.user_id = auth.uid()
  )
);

-- Update campaign_metrics_sb policies
DROP POLICY IF EXISTS "Users can view own campaign metrics sb" ON campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can insert own campaign metrics sb" ON campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can update own campaign metrics sb" ON campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can delete own campaign metrics sb" ON campaign_metrics_sb;

CREATE POLICY "Users can view accessible metrics sb"
ON campaign_metrics_sb FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sb.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert metrics sb"
ON campaign_metrics_sb FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sb.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible metrics sb"
ON campaign_metrics_sb FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sb.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete accessible metrics sb"
ON campaign_metrics_sb FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sb.campaign_id
    AND au.user_id = auth.uid()
  )
);

-- Update campaign_metrics_sd policies
DROP POLICY IF EXISTS "Users can view own campaign metrics sd" ON campaign_metrics_sd;
DROP POLICY IF EXISTS "Users can insert own campaign metrics sd" ON campaign_metrics_sd;
DROP POLICY IF EXISTS "Users can update own campaign metrics sd" ON campaign_metrics_sd;
DROP POLICY IF EXISTS "Users can delete own campaign metrics sd" ON campaign_metrics_sd;

CREATE POLICY "Users can view accessible metrics sd"
ON campaign_metrics_sd FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sd.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert metrics sd"
ON campaign_metrics_sd FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sd.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible metrics sd"
ON campaign_metrics_sd FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sd.campaign_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete accessible metrics sd"
ON campaign_metrics_sd FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM campaigns c
    JOIN account_users au ON au.account_id = c.account_id
    WHERE c.id = campaign_metrics_sd.campaign_id
    AND au.user_id = auth.uid()
  )
);

-- Update alert_items policies
DROP POLICY IF EXISTS "Users can view own alert items" ON alert_items;
DROP POLICY IF EXISTS "Users can insert own alert items" ON alert_items;
DROP POLICY IF EXISTS "Users can update own alert items" ON alert_items;
DROP POLICY IF EXISTS "Users can delete own alert items" ON alert_items;

CREATE POLICY "Users can view accessible alert items"
ON alert_items FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts a
    JOIN account_users au ON au.account_id = a.account_id
    WHERE a.id = alert_items.alert_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert alert items"
ON alert_items FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM alerts a
    JOIN account_users au ON au.account_id = a.account_id
    WHERE a.id = alert_items.alert_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible alert items"
ON alert_items FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts a
    JOIN account_users au ON au.account_id = a.account_id
    WHERE a.id = alert_items.alert_id
    AND au.user_id = auth.uid()
  )
);

CREATE POLICY "Users can delete accessible alert items"
ON alert_items FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM alerts a
    JOIN account_users au ON au.account_id = a.account_id
    WHERE a.id = alert_items.alert_id
    AND au.user_id = auth.uid()
  )
);
-- Delete the Castrol account
DELETE FROM account_users WHERE account_id = '25258ec9-df1c-4061-9bee-48d6f5f6abb4';
DELETE FROM amazon_accounts WHERE id = '25258ec9-df1c-4061-9bee-48d6f5f6abb4';
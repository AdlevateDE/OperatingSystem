-- First drop all dependent policies
DROP POLICY IF EXISTS "Users can view accessible metrics sb" ON public.campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can insert metrics sb" ON public.campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can update accessible metrics sb" ON public.campaign_metrics_sb;
DROP POLICY IF EXISTS "Users can delete accessible metrics sb" ON public.campaign_metrics_sb;

-- Now we can safely modify the table
-- Drop the old uuid-based campaign_id column
ALTER TABLE public.campaign_metrics_sb 
  DROP COLUMN IF EXISTS campaign_id CASCADE,
  DROP COLUMN IF EXISTS impressions CASCADE;

-- Add all the new columns for SB metrics
ALTER TABLE public.campaign_metrics_sb
  ADD COLUMN profile_id text,
  ADD COLUMN campaign_id bigint,
  ADD COLUMN campaign_name text,
  ADD COLUMN campaign_status text,
  ADD COLUMN campaign_budget_amount numeric,
  ADD COLUMN campaign_budget_currency_code text,
  ADD COLUMN campaign_budget_type text,
  ADD COLUMN cost_type text,
  ADD COLUMN impressions bigint,
  ADD COLUMN clicks bigint,
  ADD COLUMN cost numeric,
  ADD COLUMN purchases bigint,
  ADD COLUMN sales numeric,
  ADD COLUMN units_sold bigint,
  ADD COLUMN top_of_search_impression_share numeric,
  ADD COLUMN detail_page_views bigint,
  ADD COLUMN add_to_cart bigint,
  ADD COLUMN new_to_brand_purchases bigint,
  ADD COLUMN new_to_brand_sales numeric,
  ADD COLUMN new_to_brand_units_sold bigint,
  ADD COLUMN video_complete_views bigint,
  ADD COLUMN video_5_second_views bigint,
  ADD COLUMN unique_key text;

-- Create unique constraint for upsert logic
ALTER TABLE public.campaign_metrics_sb
  ADD CONSTRAINT campaign_metrics_sb_unique_key UNIQUE (unique_key);

-- Add report_type column to pending_reports for SP/SB distinction
ALTER TABLE public.pending_reports
  ADD COLUMN report_type text DEFAULT 'sp';

-- Create new RLS policies using profile_id (like SP table)
CREATE POLICY "Users can view accessible metrics sb" 
ON public.campaign_metrics_sb 
FOR SELECT 
USING (profile_id IN (
  SELECT aa.profile_id 
  FROM amazon_accounts aa
  JOIN account_users au ON au.account_id = aa.id
  WHERE au.user_id = auth.uid()
));

CREATE POLICY "Users can insert metrics sb" 
ON public.campaign_metrics_sb 
FOR INSERT 
WITH CHECK (profile_id IN (
  SELECT aa.profile_id 
  FROM amazon_accounts aa
  JOIN account_users au ON au.account_id = aa.id
  WHERE au.user_id = auth.uid()
));

CREATE POLICY "Users can update accessible metrics sb" 
ON public.campaign_metrics_sb 
FOR UPDATE 
USING (profile_id IN (
  SELECT aa.profile_id 
  FROM amazon_accounts aa
  JOIN account_users au ON au.account_id = aa.id
  WHERE au.user_id = auth.uid()
));

CREATE POLICY "Users can delete accessible metrics sb" 
ON public.campaign_metrics_sb 
FOR DELETE 
USING (profile_id IN (
  SELECT aa.profile_id 
  FROM amazon_accounts aa
  JOIN account_users au ON au.account_id = aa.id
  WHERE au.user_id = auth.uid()
));
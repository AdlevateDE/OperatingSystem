-- Add batch_id column to pending_reports table
-- This allows grouping reports that were triggered together
ALTER TABLE public.pending_reports 
ADD COLUMN batch_id uuid DEFAULT NULL;

-- Add index for efficient queries on batch_id
CREATE INDEX IF NOT EXISTS idx_pending_reports_batch_id 
ON public.pending_reports(batch_id) 
WHERE batch_id IS NOT NULL;
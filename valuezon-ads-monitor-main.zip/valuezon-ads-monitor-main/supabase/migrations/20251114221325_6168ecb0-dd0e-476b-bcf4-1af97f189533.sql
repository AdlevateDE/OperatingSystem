-- Update amazon_accounts policies
DROP POLICY IF EXISTS "Users can view own accounts" ON amazon_accounts;
DROP POLICY IF EXISTS "Users can insert own accounts" ON amazon_accounts;
DROP POLICY IF EXISTS "Users can update own accounts" ON amazon_accounts;
DROP POLICY IF EXISTS "Users can delete own accounts" ON amazon_accounts;

CREATE POLICY "Users can view accessible accounts"
ON amazon_accounts FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = amazon_accounts.id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert accounts"
ON amazon_accounts FOR INSERT TO authenticated
WITH CHECK (true);

CREATE POLICY "Owners/editors can update accounts"
ON amazon_accounts FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = amazon_accounts.id
    AND account_users.user_id = auth.uid()
    AND account_users.role IN ('owner', 'editor')
  )
);

CREATE POLICY "Owners can delete accounts"
ON amazon_accounts FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = amazon_accounts.id
    AND account_users.user_id = auth.uid()
    AND account_users.role = 'owner'
  )
);

-- Update campaigns policies
DROP POLICY IF EXISTS "Users can view own campaigns" ON campaigns;
DROP POLICY IF EXISTS "Users can insert own campaigns" ON campaigns;
DROP POLICY IF EXISTS "Users can update own campaigns" ON campaigns;
DROP POLICY IF EXISTS "Users can delete own campaigns" ON campaigns;

CREATE POLICY "Users can view accessible campaigns"
ON campaigns FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = campaigns.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert campaigns"
ON campaigns FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = campaigns.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible campaigns"
ON campaigns FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = campaigns.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Owners/editors can delete campaigns"
ON campaigns FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = campaigns.account_id
    AND account_users.user_id = auth.uid()
    AND account_users.role IN ('owner', 'editor')
  )
);

-- Update alert_rules policies
DROP POLICY IF EXISTS "Users can view own alert rules" ON alert_rules;
DROP POLICY IF EXISTS "Users can insert own alert rules" ON alert_rules;
DROP POLICY IF EXISTS "Users can update own alert rules" ON alert_rules;
DROP POLICY IF EXISTS "Users can delete own alert rules" ON alert_rules;

CREATE POLICY "Users can view accessible alert rules"
ON alert_rules FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alert_rules.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert alert rules"
ON alert_rules FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alert_rules.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible alert rules"
ON alert_rules FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alert_rules.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Owners/editors can delete alert rules"
ON alert_rules FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alert_rules.account_id
    AND account_users.user_id = auth.uid()
    AND account_users.role IN ('owner', 'editor')
  )
);

-- Update alerts policies
DROP POLICY IF EXISTS "Users can view own alerts" ON alerts;
DROP POLICY IF EXISTS "Users can insert own alerts" ON alerts;
DROP POLICY IF EXISTS "Users can update own alerts" ON alerts;
DROP POLICY IF EXISTS "Users can delete own alerts" ON alerts;

CREATE POLICY "Users can view accessible alerts"
ON alerts FOR SELECT TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alerts.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can insert alerts"
ON alerts FOR INSERT TO authenticated
WITH CHECK (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alerts.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Users can update accessible alerts"
ON alerts FOR UPDATE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alerts.account_id
    AND account_users.user_id = auth.uid()
  )
);

CREATE POLICY "Owners/editors can delete alerts"
ON alerts FOR DELETE TO authenticated
USING (
  EXISTS (
    SELECT 1 FROM account_users
    WHERE account_users.account_id = alerts.account_id
    AND account_users.user_id = auth.uid()
    AND account_users.role IN ('owner', 'editor')
  )
);
-- Add account_id column to campaign_metrics_sp table
ALTER TABLE campaign_metrics_sp 
ADD COLUMN account_id uuid REFERENCES amazon_accounts(id);

-- Update all existing rows to use Twistout account
UPDATE campaign_metrics_sp 
SET account_id = (
  SELECT id 
  FROM amazon_accounts 
  WHERE account_name = 'Twistout' 
  LIMIT 1
)
WHERE account_id IS NULL;

-- Create index for better performance
CREATE INDEX idx_campaign_metrics_sp_account_id ON campaign_metrics_sp(account_id);
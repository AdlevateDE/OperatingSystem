-- Add triggered_by_email column to store the email of the user who triggered manual alerts
ALTER TABLE alerts ADD COLUMN triggered_by_email text;
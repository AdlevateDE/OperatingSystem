-- Add alert_conditions JSONB field to store multiple conditions
ALTER TABLE public.alert_rules 
ADD COLUMN alert_conditions jsonb DEFAULT NULL;

-- Add alert_conditions_logic field for AND/OR logic
ALTER TABLE public.alert_rules 
ADD COLUMN alert_conditions_logic text DEFAULT 'AND';

-- Add comment explaining the structure
COMMENT ON COLUMN public.alert_rules.alert_conditions IS 'Array of conditions: [{metric_name, threshold_value, threshold_type, alert_direction, comparison_period}]';
COMMENT ON COLUMN public.alert_rules.alert_conditions_logic IS 'Logic to combine conditions: AND or OR';
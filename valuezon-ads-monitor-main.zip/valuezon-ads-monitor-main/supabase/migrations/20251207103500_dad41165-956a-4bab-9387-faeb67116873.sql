-- Add dashboard_url field to users table
ALTER TABLE public.users ADD COLUMN dashboard_url text;
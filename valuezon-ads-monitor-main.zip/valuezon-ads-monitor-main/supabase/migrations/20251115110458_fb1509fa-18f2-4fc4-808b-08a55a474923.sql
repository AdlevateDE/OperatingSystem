-- Set profile_id for all existing campaign_metrics_sp records
UPDATE campaign_metrics_sp 
SET profile_id = '2217651676157211' 
WHERE profile_id IS NULL OR profile_id = '';
-- Add unique constraint on unique_key for upsert functionality
ALTER TABLE campaign_metrics_sp ADD CONSTRAINT campaign_metrics_sp_unique_key_unique UNIQUE (unique_key);
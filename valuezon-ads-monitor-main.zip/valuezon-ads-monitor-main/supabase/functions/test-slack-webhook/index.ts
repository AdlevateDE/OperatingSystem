import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { webhook_url, language = 'en', dashboard_url } = await req.json();

    if (!webhook_url) {
      console.error('No webhook URL provided');
      return new Response(
        JSON.stringify({ success: false, error: 'No webhook URL provided' }),
        { status: 400, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Testing Slack webhook connection...');

    const blocks = [
      {
        type: "section",
        text: {
          type: "mrkdwn",
          text: language === 'de' 
            ? "✅ *Verbindung erfolgreich!*\n\nDie Slack-Integration funktioniert korrekt."
            : "✅ *Connection successful!*\n\nThe Slack integration is working correctly.",
        },
      },
    ];

    // Add dashboard URL button if configured
    if (dashboard_url) {
      blocks.push({
        type: "section",
        text: {
          type: "mrkdwn",
          text: language === 'de' 
            ? `📊 *Dashboard-URL:* ${dashboard_url}`
            : `📊 *Dashboard URL:* ${dashboard_url}`,
        },
      });
      blocks.push({
        type: "actions",
        elements: [
          {
            type: "button",
            text: {
              type: "plain_text",
              text: language === 'de' ? "Dashboard öffnen" : "Open Dashboard",
              emoji: true,
            },
            url: dashboard_url,
            style: "primary",
          },
        ],
      } as any);
    }

    const testMessage = {
      text: language === 'de' ? "🧪 Test-Nachricht von Amazon Alerts" : "🧪 Test message from Amazon Alerts",
      blocks,
    };

    const response = await fetch(webhook_url, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(testMessage),
    });

    if (!response.ok) {
      const errorText = await response.text();
      console.error('Slack API error:', response.status, errorText);
      return new Response(
        JSON.stringify({ success: false, error: `Slack API Error: ${response.status}` }),
        { status: 200, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Test message sent successfully to Slack');

    return new Response(
      JSON.stringify({ success: true }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in test-slack-webhook:', errorMessage);
    return new Response(
      JSON.stringify({ success: false, error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_TOKEN_URL = 'https://api.amazon.com/auth/o2/token';
const AMAZON_ADS_API_URL = 'https://advertising-api-eu.amazon.com';

/**
 * Isolierte Test-Funktion für Third of Life Auth
 * Nutzt AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE (neuer Mandant)
 * Lässt bestehenden AMAZON_REFRESH_TOKEN (Twistout) komplett unberührt
 */

async function refreshAccessToken(refreshTokenKey: string): Promise<string> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');
  const refreshToken = Deno.env.get(refreshTokenKey);

  console.log(`[Third of Life Test] Using refresh token key: ${refreshTokenKey}`);
  console.log(`[Third of Life Test] Client ID present: ${!!clientId}`);
  console.log(`[Third of Life Test] Client Secret present: ${!!clientSecret}`);
  console.log(`[Third of Life Test] Refresh Token present: ${!!refreshToken}`);

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error(`Missing credentials. ClientID: ${!!clientId}, ClientSecret: ${!!clientSecret}, RefreshToken (${refreshTokenKey}): ${!!refreshToken}`);
  }

  console.log('[Third of Life Test] Requesting new access token...');

  const response = await fetch(AMAZON_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
    }),
  });

  const responseText = await response.text();
  console.log(`[Third of Life Test] Token response status: ${response.status}`);

  if (!response.ok) {
    console.error(`[Third of Life Test] Token error response: ${responseText}`);
    throw new Error(`Failed to refresh access token: ${response.status} - ${responseText}`);
  }

  const data = JSON.parse(responseText);
  console.log('[Third of Life Test] Access token obtained successfully');
  
  return data.access_token;
}

async function fetchProfiles(accessToken: string): Promise<any> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');

  console.log('[Third of Life Test] Fetching profiles from Amazon Ads API...');

  const response = await fetch(`${AMAZON_ADS_API_URL}/v2/profiles`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': clientId!,
      'Content-Type': 'application/json',
    },
  });

  const responseText = await response.text();
  console.log(`[Third of Life Test] Profiles response status: ${response.status}`);

  if (!response.ok) {
    console.error(`[Third of Life Test] Profiles error response: ${responseText}`);
    throw new Error(`Failed to fetch profiles: ${response.status} - ${responseText}`);
  }

  const profiles = JSON.parse(responseText);
  console.log(`[Third of Life Test] Found ${profiles.length} profiles`);

  return profiles;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('========================================');
    console.log('[Third of Life Test] Starting isolated auth test');
    console.log('[Third of Life Test] This test uses AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE');
    console.log('[Third of Life Test] Existing Twistout token (AMAZON_REFRESH_TOKEN) is NOT touched');
    console.log('========================================');

    // Step 1: Get access token using Third of Life's refresh token
    const accessToken = await refreshAccessToken('AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE');

    // Step 2: Fetch all available profiles
    const profiles = await fetchProfiles(accessToken);

    // Step 3: Analyze and format results
    const analysis = {
      totalProfiles: profiles.length,
      profiles: profiles.map((p: any) => ({
        profileId: p.profileId,
        countryCode: p.countryCode,
        currencyCode: p.currencyCode,
        timezone: p.timezone,
        accountInfo: p.accountInfo ? {
          id: p.accountInfo.id,
          name: p.accountInfo.name,
          type: p.accountInfo.type,
          marketplaceStringId: p.accountInfo.marketplaceStringId,
        } : null,
      })),
      marketplaces: [...new Set(profiles.map((p: any) => p.countryCode))],
      accountTypes: [...new Set(profiles.map((p: any) => p.accountInfo?.type).filter(Boolean))],
    };

    console.log('[Third of Life Test] Analysis complete');
    console.log(`[Third of Life Test] Found ${analysis.totalProfiles} profiles`);
    console.log(`[Third of Life Test] Marketplaces: ${analysis.marketplaces.join(', ')}`);
    console.log(`[Third of Life Test] Account types: ${analysis.accountTypes.join(', ')}`);

    return new Response(JSON.stringify({
      success: true,
      message: 'Third of Life auth test successful',
      note: 'This test used AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE - Twistout token was NOT used',
      analysis,
      rawProfiles: profiles,
    }, null, 2), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });

  } catch (error) {
    console.error('[Third of Life Test] Error:', error);
    const errorMessage = error instanceof Error ? error.message : String(error);
    
    return new Response(JSON.stringify({
      success: false,
      error: errorMessage,
      note: 'Test failed - check if AMAZON_REFRESH_TOKEN_THIRD_OF_LIFE is correctly configured',
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
    });
  }
});

import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Delay helper for rate limiting between SP/SB/SD
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  console.log('=== SYNC-DAILY-DATA STARTED ===');

  try {
    const body = await req.json().catch(() => ({}));
    const source = body.source || 'manual';
    console.log(`[INFO] Triggered by: ${source}`);

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get all active amazon accounts with profile_id
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('id, profile_id, account_name, is_active')
      .eq('is_active', true);

    if (accountsError) {
      console.error('[ERROR] Failed to fetch amazon_accounts:', accountsError);
      throw accountsError;
    }

    if (!accounts || accounts.length === 0) {
      console.log('[INFO] No active Amazon accounts found');
      return new Response(
        JSON.stringify({ 
          success: true,
          message: 'No active accounts to sync',
          triggered_at: new Date().toISOString(),
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Extract unique profile IDs
    const profileIds = [...new Set(accounts.map(a => a.profile_id).filter(Boolean))];
    console.log(`[INFO] Found ${accounts.length} active accounts with ${profileIds.length} unique profiles`);
    console.log(`[INFO] Profile IDs: ${profileIds.join(', ')}`);
    console.log('[INFO] Accounts:');
    accounts.forEach(a => console.log(`  - ${a.account_name}: profile_id=${a.profile_id}`));

    // Get today's date
    const today = new Date().toISOString().split('T')[0];
    console.log(`[INFO] Syncing data for date: ${today}`);

    // Generate batch_id for this sync run
    const batchId = crypto.randomUUID();
    console.log(`[INFO] Batch ID: ${batchId}`);

    const fetchResults = {
      sp: { success: false, error: null as string | null, data: null as any },
      sb: { success: false, error: null as string | null, data: null as any },
      sd: { success: false, error: null as string | null, data: null as any },
    };

    // Fetch SP data
    console.log('[FETCH] Starting SP data fetch...');
    try {
      const fetchResponseSP = await supabase.functions.invoke('fetch-amazon-data-sp', {
        body: {
          profileIds: profileIds,
          startDate: today,
          endDate: today,
          triggeredBy: 'sync-daily-data',
          triggerAlertCheck: false,
          batch_id: batchId,
        },
      });

      if (fetchResponseSP.error) {
        fetchResults.sp.error = fetchResponseSP.error.message || JSON.stringify(fetchResponseSP.error);
        console.error('[FETCH] SP FAILED:', fetchResults.sp.error);
      } else {
        fetchResults.sp.success = true;
        fetchResults.sp.data = fetchResponseSP.data;
        console.log('[FETCH] SP SUCCESS:', JSON.stringify(fetchResponseSP.data));
      }
    } catch (spError: any) {
      fetchResults.sp.error = spError.message || 'Unknown SP error';
      console.error('[FETCH] SP EXCEPTION:', fetchResults.sp.error);
    }

    // Wait 5 seconds before SB fetch to avoid API throttling
    console.log('[RATE LIMIT] Waiting 5s before SB fetch...');
    await delay(5000);

    // Fetch SB data
    console.log('[FETCH] Starting SB data fetch...');
    try {
      const fetchResponseSB = await supabase.functions.invoke('fetch-amazon-data-sb', {
        body: {
          profileIds: profileIds,
          startDate: today,
          endDate: today,
          triggeredBy: 'sync-daily-data',
          triggerAlertCheck: false,
          batch_id: batchId,
        },
      });

      if (fetchResponseSB.error) {
        fetchResults.sb.error = fetchResponseSB.error.message || JSON.stringify(fetchResponseSB.error);
        console.error('[FETCH] SB FAILED:', fetchResults.sb.error);
      } else {
        fetchResults.sb.success = true;
        fetchResults.sb.data = fetchResponseSB.data;
        console.log('[FETCH] SB SUCCESS:', JSON.stringify(fetchResponseSB.data));
      }
    } catch (sbError: any) {
      fetchResults.sb.error = sbError.message || 'Unknown SB error';
      console.error('[FETCH] SB EXCEPTION:', fetchResults.sb.error);
    }

    // Wait 5 seconds before SD fetch to avoid API throttling
    console.log('[RATE LIMIT] Waiting 5s before SD fetch...');
    await delay(5000);

    // Fetch SD data
    console.log('[FETCH] Starting SD data fetch...');
    try {
      const fetchResponseSD = await supabase.functions.invoke('fetch-amazon-data-sd', {
        body: {
          profileIds: profileIds,
          startDate: today,
          endDate: today,
          triggeredBy: 'sync-daily-data',
          triggerAlertCheck: false,
          batch_id: batchId,
        },
      });

      if (fetchResponseSD.error) {
        fetchResults.sd.error = fetchResponseSD.error.message || JSON.stringify(fetchResponseSD.error);
        console.error('[FETCH] SD FAILED:', fetchResults.sd.error);
      } else {
        fetchResults.sd.success = true;
        fetchResults.sd.data = fetchResponseSD.data;
        console.log('[FETCH] SD SUCCESS:', JSON.stringify(fetchResponseSD.data));
      }
    } catch (sdError: any) {
      fetchResults.sd.error = sdError.message || 'Unknown SD error';
      console.error('[FETCH] SD EXCEPTION:', fetchResults.sd.error);
    }

    // Log summary
    const successCount = [fetchResults.sp.success, fetchResults.sb.success, fetchResults.sd.success].filter(Boolean).length;
    console.log(`[INFO] Fetch summary: ${successCount}/3 succeeded (SP: ${fetchResults.sp.success}, SB: ${fetchResults.sb.success}, SD: ${fetchResults.sd.success})`);

    const duration = Date.now() - startTime;
    console.log(`=== SYNC-DAILY-DATA COMPLETED in ${duration}ms ===`);

    return new Response(
      JSON.stringify({
        success: successCount > 0,
        message: `Created pending reports for ${profileIds.length} profiles`,
        source: source,
        triggered_at: new Date().toISOString(),
        duration_ms: duration,
        batch_id: batchId,
        profiles_count: profileIds.length,
        profile_ids: profileIds,
        fetch_results: fetchResults,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    const duration = Date.now() - startTime;
    console.error(`=== SYNC-DAILY-DATA FAILED after ${duration}ms ===`);
    console.error('[ERROR] Unhandled exception:', error.message);
    console.error('[ERROR] Stack:', error.stack);

    return new Response(
      JSON.stringify({
        success: false,
        error: error.message,
        duration_ms: duration,
      }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

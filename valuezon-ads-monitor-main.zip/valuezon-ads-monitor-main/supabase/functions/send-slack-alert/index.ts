import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface SlackAlertRequest {
  alert_id: string
  user_id: string
  run_type: 'manual' | 'scheduled'
  rule_id?: string
  has_alerts: boolean
  is_no_data?: boolean // NEW: Flag for missing data warning
  summary?: {
    total_rules_checked: number
    rules_triggered: string[]
    accounts_affected: string[]
    accounts_checked?: string[] // All accounts that were checked, not just affected
  }
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const { alert_id, user_id, run_type, rule_id, has_alerts, is_no_data, summary } = await req.json() as SlackAlertRequest

    console.log('Sending Slack alert:', { alert_id, user_id, run_type, rule_id, has_alerts, is_no_data })

    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )

    // Fetch alert details
    const { data: alert, error: alertError } = await supabaseAdmin
      .from('alerts')
      .select(`
        *,
        alert_items (*)
      `)
      .eq('id', alert_id)
      .single()

    if (alertError || !alert) {
      throw new Error(`Alert not found: ${alertError?.message}`)
    }

    // Get the account owner's Slack webhook URL (not the triggering user's)
    // First, find the account owner via account_users table
    const { data: ownerData, error: ownerError } = await supabaseAdmin
      .from('account_users')
      .select(`
        user_id,
        users!account_users_user_id_fkey (
          slack_webhook_url,
          email,
          dashboard_url
        )
      `)
      .eq('account_id', alert.account_id)
      .eq('role', 'owner')
      .maybeSingle()

    if (ownerError) {
      console.error('Error fetching account owner:', ownerError)
      throw new Error(`Error fetching account owner: ${ownerError.message}`)
    }

    // Type assertion for the nested user data (it's an object, not array, due to maybeSingle)
    const ownerUser = (ownerData?.users as unknown) as { slack_webhook_url: string | null, email: string, dashboard_url: string | null } | null

    if (!ownerUser?.slack_webhook_url) {
      throw new Error('Slack Webhook URL nicht konfiguriert. Der Account-Owner muss diese in den Einstellungen hinterlegen.')
    }
    
    // Remove trailing slash to prevent double-slash in URLs (e.g., /status)
    const dashboardUrl = ownerUser.dashboard_url?.replace(/\/+$/, '') || null
    const slackWebhookUrl = ownerUser.slack_webhook_url

    console.log('Slack webhook found for account owner:', ownerUser.email)

    const metricNames: Record<string, string> = {
      cost: 'Kosten',
      clicks: 'Klicks',
      impressions: 'Impressionen',
      cost_per_click: 'CPC',
      click_through_rate: 'CTR',
      acos_clicks_14d: 'ACoS',
    }

    let slackMessage: any
    
    // Determine if this is a batch run (scheduled OR manual without specific rule_id)
    const isBatchRun = run_type === 'scheduled' || (run_type === 'manual' && !rule_id)

    // MEZ timezone options for consistent German time display
    const mezTimeOptions: Intl.DateTimeFormatOptions = { 
      timeZone: 'Europe/Berlin',
      hour: '2-digit',
      minute: '2-digit'
    };
    const mezFullOptions: Intl.DateTimeFormatOptions = { 
      timeZone: 'Europe/Berlin',
      day: '2-digit',
      month: '2-digit',
      year: 'numeric',
      hour: '2-digit',
      minute: '2-digit'
    };
    
    const formattedTime = new Date().toLocaleTimeString('de-DE', mezTimeOptions);
    const formattedDateTime = new Date().toLocaleString('de-DE', mezFullOptions);

    // ⚠️ KEINE DATEN VERFÜGBAR Message
    if (is_no_data || alert.is_no_data) {
      const accountsList = summary?.accounts_checked?.join(', ') || 'Keine';
      const statusPageUrl = dashboardUrl ? `${dashboardUrl}/status` : null;
      
      const blocks: any[] = [
        {
          type: 'header',
          text: {
            type: 'plain_text',
            text: '⚠️ Warnung: Keine Daten verfügbar',
            emoji: true,
          },
        },
        {
          type: 'section',
          text: {
            type: 'mrkdwn',
            text: `*Es sind keine Kampagnen-Daten für heute vorhanden.*\n\nBitte prüfe den Report-Status, um sicherzustellen dass die Daten-Synchronisierung erfolgreich war.\n\n*Geprüfte Accounts:* ${accountsList}\n*Regeln:* ${summary?.total_rules_checked || 0}`,
          },
        },
      ];
      
      if (statusPageUrl) {
        blocks.push({
          type: 'actions',
          elements: [{
            type: 'button',
            text: { type: 'plain_text', text: '🔍 Report-Status prüfen', emoji: true },
            url: statusPageUrl,
            style: 'danger'
          }]
        });
      }
      
      slackMessage = {
        text: '⚠️ Warnung: Keine Daten verfügbar',
        blocks,
      };
    } else if (alert.is_all_clear) {
      // ✅ Alles grün Message
      let messageText: string;
      
      if (rule_id) {
        // Single Rule Check: Hole den Regelnamen
        const { data: rule } = await supabaseAdmin
          .from('alert_rules')
          .select('rule_name')
          .eq('id', rule_id)
          .single();
        
        const ruleName = rule?.rule_name || 'Unbekannte Regel';
        messageText = `*✅ Alles im grünen Bereich*\n\n*Geprüfte Regel:* ${ruleName}\nKeine Auffälligkeiten bei der Prüfung um ${formattedTime} Uhr (MEZ)`;
      } else {
        // Batch Run: Zeige alle geprüften Accounts
        const accountsList = summary?.accounts_checked?.join(', ') || 'Keine';
        messageText = `*✅ Alles im grünen Bereich*\n\n*Geprüfte Accounts:* ${accountsList}\n*Regeln geprüft:* ${summary?.total_rules_checked || 0}\nKeine Auffälligkeiten bei der Prüfung um ${formattedTime} Uhr (MEZ)`;
      }
      
      slackMessage = {
        text: '✅ Alles im grünen Bereich',
        blocks: [
          {
            type: 'section',
            text: {
              type: 'mrkdwn',
              text: messageText,
            },
          },
        ],
      };
    } else if (isBatchRun) {
      // 📊 Aggregierte Message (Batch Runs)
      const blocks: any[] = [
        {
          type: 'header',
          text: {
            type: 'plain_text',
            text: '⚠️ Performance Alerts',
            emoji: true,
          },
        },
        {
          type: 'section',
          fields: [
            {
              type: 'mrkdwn',
              text: `*Ausgelöste Regeln:*\n${summary?.rules_triggered.join(', ') || 'Keine'}`,
            },
            {
              type: 'mrkdwn',
              text: `*Betroffene Accounts:*\n${summary?.accounts_affected.join(', ') || 'Keine'}`,
            },
            {
              type: 'mrkdwn',
              text: `*Betroffene Kampagnen:*\n${alert.total_items} Kampagnen`,
            },
            {
              type: 'mrkdwn',
              text: `*Zeitpunkt:*\n${formattedDateTime} Uhr (MEZ)`,
            },
          ],
        },
      ]
      
      // Add dashboard button if URL is configured
      if (dashboardUrl) {
        blocks.push({
          type: 'actions',
          elements: [{
            type: 'button',
            text: { type: 'plain_text', text: '📊 Dashboard öffnen', emoji: true },
            url: dashboardUrl,
            style: 'primary'
          }]
        })
      }

      slackMessage = {
        text: '⚠️ Performance Alerts',
        blocks,
      }
    } else {
      // 🎯 Spezifische Regel Message (Manual)
      const firstItem = alert.alert_items?.[0]
      
      const blocks: any[] = [
        {
          type: 'header',
          text: {
            type: 'plain_text',
            text: `⚠️ Alert: ${firstItem?.rule_name || 'Regelname'}`,
            emoji: true,
          },
        },
        {
          type: 'section',
          fields: [
            {
              type: 'mrkdwn',
              text: `*Account:*\n${firstItem?.account_name || 'N/A'}`,
            },
            {
              type: 'mrkdwn',
              text: `*Betroffene Kampagnen:*\n${alert.total_items} Kampagnen`,
            },
            {
              type: 'mrkdwn',
              text: `*Metrik:*\n${metricNames[firstItem?.metric_name] || firstItem?.metric_name || 'N/A'}`,
            },
            {
              type: 'mrkdwn',
              text: `*Threshold:*\n±${firstItem?.threshold_percent || 0}%`,
            },
          ],
        },
      ]
      
      // Add dashboard button if URL is configured
      if (dashboardUrl) {
        blocks.push({
          type: 'actions',
          elements: [{
            type: 'button',
            text: { type: 'plain_text', text: '📊 Dashboard öffnen', emoji: true },
            url: dashboardUrl,
            style: 'primary'
          }]
        })
      }

      slackMessage = {
        text: `⚠️ Alert: ${firstItem?.rule_name || 'Regelname'}`,
        blocks,
      }
    }

    // Send to Slack with 10-second timeout
    const controller = new AbortController()
    const timeoutId = setTimeout(() => controller.abort(), 10000)
    
    console.log(`Sending to Slack webhook (${slackWebhookUrl.substring(0, 50)}...)`)
    console.log(`Message has ${slackMessage.blocks?.length || 0} blocks`)
    
    let slackResponse: Response
    try {
      slackResponse = await fetch(slackWebhookUrl, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(slackMessage),
        signal: controller.signal,
      })
      clearTimeout(timeoutId)
    } catch (fetchError: any) {
      clearTimeout(timeoutId)
      if (fetchError.name === 'AbortError') {
        console.error('Slack request timed out after 10 seconds')
        throw new Error('Slack request timed out after 10 seconds')
      }
      console.error('Slack fetch error:', fetchError.message)
      throw new Error(`Slack network error: ${fetchError.message}`)
    }

    console.log(`Slack response status: ${slackResponse.status}`)
    
    if (!slackResponse.ok) {
      const errorText = await slackResponse.text()
      console.error(`Slack error response: ${errorText}`)
      
      // Parse common Slack error codes for better messaging
      if (slackResponse.status === 429) {
        throw new Error(`Slack rate limit exceeded (429) - ${errorText}`)
      }
      if (slackResponse.status === 404) {
        throw new Error(`Slack webhook not found (404) - Webhook URL may be invalid`)
      }
      throw new Error(`Slack API error: ${slackResponse.status} - ${errorText}`)
    }

    // Update alert as sent and clear any previous error
    await supabaseAdmin
      .from('alerts')
      .update({ slack_sent: true, sent_at: new Date().toISOString(), slack_error: null })
      .eq('id', alert_id)

    console.log('Slack message sent successfully')

    return new Response(JSON.stringify({ 
      success: true, 
      message: 'Alert erfolgreich gesendet' 
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 200,
    })
  } catch (error) {
    console.error('Error sending Slack alert:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unbekannter Fehler'
    return new Response(JSON.stringify({ 
      success: false, 
      error: errorMessage,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' },
      status: 500,
    })
  }
})

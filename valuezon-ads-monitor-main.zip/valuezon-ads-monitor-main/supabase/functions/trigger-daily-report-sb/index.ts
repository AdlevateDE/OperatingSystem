import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== trigger-daily-report-sb started ===');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get authenticated user
    const authHeader = req.headers.get('Authorization');
    if (!authHeader) {
      throw new Error('Unauthorized - no auth header');
    }
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const body = await req.json().catch(() => ({}));
    const { rule_id, trigger_all, batch_id } = body;
    const run_type = rule_id ? 'manual' : 'scheduled';
    
    console.log(`trigger-daily-report-sb: batch_id=${batch_id}, rule_id=${rule_id}, trigger_all=${trigger_all}`);

    let profileIds: string[] = [];

    if (rule_id) {
      // Single rule trigger - get profile_id(s) for this rule's accounts only
      console.log(`Processing single rule: ${rule_id}`);
      
      const { data: rule, error } = await supabase
        .from('alert_rules')
        .select(`
          id,
          account_id,
          account_ids,
          campaign_types,
          amazon_accounts!inner(profile_id)
        `)
        .eq('id', rule_id)
        .single();

      if (error) throw error;
      if (!rule) throw new Error('Rule not found');

      // Check if rule has SB in campaign_types
      const campaignTypes = (rule as any).campaign_types || ['sp'];
      if (!campaignTypes.includes('sb')) {
        console.log(`Rule ${rule_id} does not include SB campaign type, skipping`);
        return new Response(
          JSON.stringify({ 
            success: true, 
            message: 'Rule does not include SB campaign type',
            skipped: true
          }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      // Get all account_ids from the rule (support both single and multi-account)
      const accountIds: string[] = (rule as any).account_ids || [(rule as any).account_id];

      // Verify user has access to at least one of these accounts via account_users
      const { data: access, error: accessError } = await supabase
        .from('account_users')
        .select('account_id')
        .in('account_id', accountIds)
        .eq('user_id', user.id);

      if (accessError || !access || access.length === 0) {
        throw new Error('Unauthorized - no access to accounts for this rule');
      }

      // Get profile_ids for all accounts the user has access to
      const accessibleAccountIds = access.map(a => a.account_id);
      const { data: accountsWithProfiles } = await supabase
        .from('amazon_accounts')
        .select('profile_id')
        .in('id', accessibleAccountIds)
        .eq('is_active', true);

      profileIds = accountsWithProfiles?.map(a => a.profile_id) || [];
      console.log(`Single rule ${rule_id}: Using ${profileIds.length} profile_ids from ${accessibleAccountIds.length} accounts`);
      
    } else if (trigger_all) {
      // Batch trigger - get all unique profile_ids from active rules with SB
      console.log('Processing trigger_all for SB');
      
      const { data: userAccounts, error: accountError } = await supabase
        .from('account_users')
        .select('account_id')
        .eq('user_id', user.id);

      if (accountError) throw accountError;

      const accountIds = userAccounts?.map(a => a.account_id) || [];

      if (accountIds.length === 0) {
        throw new Error('No accounts found for user');
      }

      // Get all active rules with SB campaign type
      const { data: rules, error } = await supabase
        .from('alert_rules')
        .select(`
          id,
          account_id,
          campaign_types,
          amazon_accounts!inner(profile_id)
        `)
        .eq('is_active', true)
        .in('account_id', accountIds)
        .contains('campaign_types', ['sb']);

      if (error) throw error;

      // Get unique profile_ids from rules that have SB
      profileIds = [...new Set(rules?.map((r: any) => r.amazon_accounts.profile_id) || [])];
      console.log(`Batch trigger: Found ${profileIds.length} unique profile_ids with SB rules`);
      
    } else {
      throw new Error('Either rule_id or trigger_all must be provided');
    }

    if (profileIds.length === 0) {
      console.log('No profile IDs found for SB data fetch');
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No profiles with SB campaign type found',
          profile_ids: []
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Get today's date in YYYY-MM-DD format
    const today = new Date();
    const todayString = today.toISOString().split('T')[0];

    console.log(`Triggering SB fetch for profile_ids: ${profileIds.join(', ')}, date: ${todayString}`);

    // Call fetch-amazon-data-sb
    const sbResponse = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sb`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        profileIds: profileIds,
        startDate: todayString,
        endDate: todayString,
        triggerAlertCheck: true,
        run_type: run_type,
        rule_id: rule_id || null,
        batch_id: batch_id || null,
      }),
    });

    let fetchResult;
    if (!sbResponse.ok) {
      const errorText = await sbResponse.text();
      console.error(`fetch-amazon-data-sb failed: ${sbResponse.status} - ${errorText}`);
      fetchResult = { error: errorText };
    } else {
      fetchResult = await sbResponse.json();
      console.log('fetch-amazon-data-sb response:', fetchResult);
    }

    console.log('=== trigger-daily-report-sb completed ===');

    return new Response(
      JSON.stringify({ 
        success: true, 
        profile_ids: profileIds,
        run_type: run_type,
        date: todayString,
        message: 'SB data sync started. Reports will be processed automatically.',
        fetch_result: fetchResult
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: any) {
    console.error('Error in trigger-daily-report-sb:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }
});

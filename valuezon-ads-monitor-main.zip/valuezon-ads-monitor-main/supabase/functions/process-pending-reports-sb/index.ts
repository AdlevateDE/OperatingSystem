import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { gunzip } from "https://deno.land/x/compress@v0.4.5/gzip/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_TOKEN_URL = 'https://api.amazon.com/auth/o2/token';
const AMAZON_ADS_API_URL = 'https://advertising-api-eu.amazon.com';
const MAX_ATTEMPTS = 15;

// Interface for SB report metrics
interface SBReportMetric {
  date: string;
  campaignId: number;
  campaignName: string;
  campaignStatus?: string;
  campaignBudgetAmount?: number;
  campaignBudgetCurrencyCode?: string;
  campaignBudgetType?: string;
  costType?: string;
  impressions?: number;
  clicks?: number;
  cost?: number;
  purchases?: number;
  sales?: number;
  unitsSold?: number;
  topOfSearchImpressionShare?: number;
  detailPageViews?: number;
  addToCart?: number;
  newToBrandPurchases?: number;
  newToBrandSales?: number;
  newToBrandUnitsSold?: number;
  videoCompleteViews?: number;
  video5SecondViews?: number;
}

// Refresh OAuth token - now accepts dynamic refresh token key
async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');
  
  // Use custom refresh token key if provided, otherwise default
  const tokenEnvKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenEnvKey);

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error(`Missing Amazon API credentials (token key: ${tokenEnvKey})`);
  }

  console.log(`Refreshing Amazon access token for SB processing using ${tokenEnvKey}...`);
  
  const response = await fetch(AMAZON_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
    }),
  });

  if (!response.ok) {
    throw new Error(`Failed to refresh token: ${await response.text()}`);
  }

  const data = await response.json();
  return data.access_token;
}

async function checkReportStatus(accessToken: string, profileId: string, reportId: string) {
  console.log(`Checking SB report status for ${reportId}...`);
  
  const response = await fetch(`${AMAZON_ADS_API_URL}/reporting/reports/${reportId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`SB Report status check failed: ${errorText}`);
    throw new Error(`Failed to check SB report status: ${errorText}`);
  }

  const data = await response.json();
  console.log(`SB Report ${reportId} status: ${data.status}`);
  
  return {
    status: data.status,
    url: data.url,
    failureReason: data.failureReason
  };
}

async function downloadReport(url: string): Promise<SBReportMetric[]> {
  console.log('Downloading SB report...');
  
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download SB report: ${response.status}`);
  }

  const compressedData = new Uint8Array(await response.arrayBuffer());
  console.log(`Downloaded ${compressedData.length} bytes of compressed SB data`);
  
  const decompressedData = gunzip(compressedData);
  const jsonString = new TextDecoder().decode(decompressedData);
  console.log(`Decompressed to ${jsonString.length} characters`);
  
  const metrics = JSON.parse(jsonString) as SBReportMetric[];
  console.log(`Parsed ${metrics.length} SB metric rows`);
  
  return metrics;
}

async function saveSBMetrics(supabase: any, profileId: string, metrics: SBReportMetric[]): Promise<number> {
  console.log(`Saving ${metrics.length} SB metrics for profile ${profileId}...`);
  
  const BATCH_SIZE = 500;
  let totalSaved = 0;

  for (let i = 0; i < metrics.length; i += BATCH_SIZE) {
    const batch = metrics.slice(i, i + BATCH_SIZE);
    
    const records = batch.map(m => {
      // CRITICAL: Use campaignId as string to generate unique_key consistently
      // JavaScript loses precision with numbers > 2^53-1 (9007199254740991)
      const campaignIdStr = String(m.campaignId);
      return {
        profile_id: profileId,
        date: m.date,
        campaign_id: campaignIdStr, // PostgreSQL bigint can handle the string conversion
        campaign_name: m.campaignName,
        campaign_status: m.campaignStatus,
        campaign_budget_amount: m.campaignBudgetAmount,
        campaign_budget_currency_code: m.campaignBudgetCurrencyCode,
        campaign_budget_type: m.campaignBudgetType,
        cost_type: m.costType,
        impressions: m.impressions,
        clicks: m.clicks,
        cost: m.cost,
        purchases: m.purchases,
        sales: m.sales,
        units_sold: m.unitsSold,
        top_of_search_impression_share: m.topOfSearchImpressionShare,
        detail_page_views: m.detailPageViews,
        add_to_cart: m.addToCart,
        new_to_brand_purchases: m.newToBrandPurchases,
        new_to_brand_sales: m.newToBrandSales,
        new_to_brand_units_sold: m.newToBrandUnitsSold,
        video_complete_views: m.videoCompleteViews,
        video_5_second_views: m.video5SecondViews,
        unique_key: `${profileId}_${campaignIdStr}_${m.date}`,
        updated_at: new Date().toISOString()
      };
    });

    const { error } = await supabase
      .from('campaign_metrics_sb')
      .upsert(records, { 
        onConflict: 'unique_key',
        ignoreDuplicates: false 
      });

    if (error) {
      console.error(`Error upserting SB batch ${i}-${i + batch.length}:`, error);
      throw error;
    }

    totalSaved += batch.length;
    console.log(`Saved SB batch ${i}-${i + batch.length}, total: ${totalSaved}`);
  }

  return totalSaved;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== process-pending-reports-sb started ===');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch pending SB reports only
    const { data: pendingReports, error: fetchError } = await supabase
      .from('pending_reports')
      .select('*')
      .eq('status', 'pending')
      .eq('report_type', 'sb')
      .order('created_at', { ascending: true })
      .limit(10);

    if (fetchError) {
      throw new Error(`Failed to fetch pending SB reports: ${fetchError.message}`);
    }

    if (!pendingReports || pendingReports.length === 0) {
      console.log('No pending SB reports to process');
      return new Response(
        JSON.stringify({ success: true, message: 'No pending SB reports' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${pendingReports.length} pending SB reports`);

    // Get all unique profile_ids and their refresh_token_keys
    const profileIds = [...new Set(pendingReports.map(r => r.profile_id))];
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    if (accountsError) {
      console.error('Error fetching accounts:', accountsError);
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    // Create a map of profile_id -> refresh_token_key
    const tokenKeyMap = new Map<string, string | null>();
    for (const account of accounts || []) {
      tokenKeyMap.set(account.profile_id, account.refresh_token_key);
    }

    console.log('Token key mapping:', Object.fromEntries(tokenKeyMap));

    // Cache access tokens by refresh_token_key
    const accessTokenCache = new Map<string, string>();

    const results = [];

    for (const report of pendingReports) {
      try {
        console.log(`Processing SB report ${report.report_id} for profile ${report.profile_id}`);
        
        // Get the appropriate access token
        const tokenKey = tokenKeyMap.get(report.profile_id) || 'AMAZON_REFRESH_TOKEN';
        let accessToken = accessTokenCache.get(tokenKey);
        
        if (!accessToken) {
          accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
          accessTokenCache.set(tokenKey, accessToken);
        }

        const status = await checkReportStatus(accessToken, report.profile_id, report.report_id);

        if (status.status === 'COMPLETED' && status.url) {
          // Download and save metrics
          const metrics = await downloadReport(status.url);
          const savedCount = await saveSBMetrics(supabase, report.profile_id, metrics);

          // Update last_sync_at for the amazon account
          const { error: updateAccountError } = await supabase
            .from('amazon_accounts')
            .update({ last_sync_at: new Date().toISOString() })
            .eq('profile_id', report.profile_id);

          if (updateAccountError) {
            console.error(`Error updating last_sync_at for ${report.profile_id}:`, updateAccountError);
          }

          // Mark report as completed
          await supabase
            .from('pending_reports')
            .update({ 
              status: 'completed',
              completed_at: new Date().toISOString(),
              download_url: status.url
            })
            .eq('id', report.id);

          results.push({ 
            reportId: report.report_id, 
            success: true, 
            metricsCount: savedCount 
          });

          console.log(`SB Report ${report.report_id} completed, saved ${savedCount} metrics`);

          // Trigger alert checks if requested - but only if ALL reports in batch are done
          if (report.trigger_alert_check) {
            let shouldTriggerAlert = true;
            
            // If this report has a batch_id, check if all reports in the batch are completed
            if (report.batch_id) {
              const { data: batchReports, error: batchError } = await supabase
                .from('pending_reports')
                .select('id, status, report_type')
                .eq('batch_id', report.batch_id);
              
              if (!batchError && batchReports) {
                const stillPending = batchReports.filter(r => r.status === 'pending');
                if (stillPending.length > 0) {
                  shouldTriggerAlert = false;
                  console.log(`⏳ SB: Waiting for ${stillPending.length} more reports in batch ${report.batch_id}: ${stillPending.map(r => r.report_type).join(', ')}`);
                } else {
                  console.log(`✅ SB: All ${batchReports.length} reports in batch ${report.batch_id} completed - triggering alert checks`);
                }
              }
            }
            
            if (shouldTriggerAlert) {
              console.log('SB: Triggering alert checks for all profiles in batch...');
              
              // Collect ALL unique profile_ids from the batch
              const { data: batchProfileData } = await supabase
                .from('pending_reports')
                .select('profile_id')
                .eq('batch_id', report.batch_id);
              
              const allProfileIds = [...new Set((batchProfileData || []).map(r => r.profile_id))];
              console.log(`SB: Found ${allProfileIds.length} unique profiles in batch: ${allProfileIds.join(', ')}`);
              
              // Get user_id from amazon_accounts via account_users (using first profile)
              const { data: accountUser } = await supabase
                .from('amazon_accounts')
                .select('id, account_users!inner(user_id)')
                .eq('profile_id', report.profile_id)
                .limit(1)
                .single();
              
              if (accountUser?.account_users?.[0]?.user_id) {
                const userId = accountUser.account_users[0].user_id;
                console.log(`SB: Triggering run-alert-checks for user ${userId}, profiles: ${allProfileIds.join(', ')}`);
                
                await supabase.functions.invoke('run-alert-checks', {
                  body: { 
                    user_id: userId,
                    profile_ids: allProfileIds,  // ALL profile IDs in batch
                    run_type: 'scheduled'
                  },
                });
              } else {
                console.log(`SB: No user found for profile ${report.profile_id}, skipping alert check`);
              }
            }
          }

        } else if (status.status === 'FAILED') {
          // Mark as failed
          await supabase
            .from('pending_reports')
            .update({ 
              status: 'failed',
              error_message: status.failureReason || 'Unknown error'
            })
            .eq('id', report.id);

          results.push({ 
            reportId: report.report_id, 
            success: false, 
            error: status.failureReason 
          });

          console.log(`SB Report ${report.report_id} failed: ${status.failureReason}`);

        } else {
          // Still pending, increment attempts
          const newAttempts = report.attempts + 1;
          
          if (newAttempts >= MAX_ATTEMPTS) {
            await supabase
              .from('pending_reports')
              .update({ 
                status: 'failed',
                error_message: 'Max attempts reached',
                attempts: newAttempts,
                last_attempt_at: new Date().toISOString()
              })
              .eq('id', report.id);

            results.push({ 
              reportId: report.report_id, 
              success: false, 
              error: 'Max attempts reached' 
            });
          } else {
            await supabase
              .from('pending_reports')
              .update({ 
                attempts: newAttempts,
                last_attempt_at: new Date().toISOString()
              })
              .eq('id', report.id);

            results.push({ 
              reportId: report.report_id, 
              success: false, 
              status: 'still_pending',
              attempts: newAttempts 
            });
          }

          console.log(`SB Report ${report.report_id} still pending, attempt ${newAttempts}/${MAX_ATTEMPTS}`);
        }

      } catch (error) {
        const errMsg = error instanceof Error ? error.message : String(error);
        console.error(`Error processing SB report ${report.report_id}:`, error);
        
        await supabase
          .from('pending_reports')
          .update({ 
            attempts: report.attempts + 1,
            last_attempt_at: new Date().toISOString(),
            error_message: errMsg
          })
          .eq('id', report.id);

        results.push({ 
          reportId: report.report_id, 
          success: false, 
          error: errMsg 
        });
      }
    }

    console.log('=== process-pending-reports-sb completed ===');
    console.log(`Processed ${results.length} SB reports`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        processed: results.length,
        results 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.error('Fatal error in process-pending-reports-sb:', error);
    return new Response(
      JSON.stringify({ success: false, error: errMsg }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

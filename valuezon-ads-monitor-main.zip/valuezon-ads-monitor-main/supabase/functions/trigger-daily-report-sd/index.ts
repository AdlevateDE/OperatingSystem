import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface RequestBody {
  rule_id?: string;
  trigger_all?: boolean;
  account_ids?: string[];
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const body: RequestBody & { batch_id?: string } = await req.json().catch(() => ({}));
    const { rule_id, trigger_all, account_ids, batch_id } = body;

    console.log('trigger-daily-report-sd called with:', { rule_id, trigger_all, account_ids, batch_id });

    let profileIds: string[] = [];

    if (rule_id) {
      // Manual trigger for specific rule - only fetch for that rule's accounts
      const { data: rule, error: ruleError } = await supabase
        .from('alert_rules')
        .select('account_ids, campaign_types')
        .eq('id', rule_id)
        .single();

      if (ruleError || !rule) {
        throw new Error(`Rule not found: ${rule_id}`);
      }

      // Check if rule includes SD
      const campaignTypes = rule.campaign_types || ['sp'];
      if (!campaignTypes.includes('sd')) {
        console.log(`Rule ${rule_id} does not include SD campaign type, skipping`);
        return new Response(
          JSON.stringify({ success: true, message: 'Rule does not include SD campaign type', skipped: true }),
          { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
        );
      }

      const ruleAccountIds = rule.account_ids || [];
      if (ruleAccountIds.length === 0) {
        throw new Error('Rule has no account_ids');
      }

      // Get profile_ids for rule's accounts
      const { data: accounts, error: accountsError } = await supabase
        .from('amazon_accounts')
        .select('profile_id')
        .in('id', ruleAccountIds)
        .eq('is_active', true);

      if (accountsError) {
        throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
      }

      profileIds = accounts?.map(a => a.profile_id) || [];
      
    } else if (account_ids && account_ids.length > 0) {
      // Specific accounts provided
      const { data: accounts, error: accountsError } = await supabase
        .from('amazon_accounts')
        .select('profile_id')
        .in('id', account_ids)
        .eq('is_active', true);

      if (accountsError) {
        throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
      }

      profileIds = accounts?.map(a => a.profile_id) || [];
      
    } else if (trigger_all) {
      // Batch trigger - fetch all active accounts
      const { data: accounts, error: accountsError } = await supabase
        .from('amazon_accounts')
        .select('profile_id')
        .eq('is_active', true);

      if (accountsError) {
        throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
      }

      profileIds = [...new Set(accounts?.map(a => a.profile_id) || [])];
    } else {
      throw new Error('Must provide rule_id, account_ids, or trigger_all');
    }

    if (profileIds.length === 0) {
      console.log('No active profiles found for SD data fetch');
      return new Response(
        JSON.stringify({ success: true, message: 'No active profiles found', profileIds: [] }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Triggering SD data fetch for ${profileIds.length} profiles:`, profileIds);

    // Call fetch-amazon-data-sd
    const fetchResponse = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sd`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        profileIds,
        triggerAlertCheck: true,
        batch_id: batch_id || null,
      }),
    });

    if (!fetchResponse.ok) {
      const errorText = await fetchResponse.text();
      throw new Error(`fetch-amazon-data-sd failed: ${fetchResponse.status} - ${errorText}`);
    }

    const fetchResult = await fetchResponse.json();
    console.log('fetch-amazon-data-sd response:', fetchResult);

    return new Response(
      JSON.stringify({
        success: true,
        message: `SD data fetch triggered for ${profileIds.length} profiles`,
        profileIds,
        fetchResult,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in trigger-daily-report-sd:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

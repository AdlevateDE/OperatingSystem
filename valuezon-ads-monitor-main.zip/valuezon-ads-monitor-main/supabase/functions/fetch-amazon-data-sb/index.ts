import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_TOKEN_URL = 'https://api.amazon.com/auth/o2/token';
const AMAZON_ADS_API_URL = 'https://advertising-api-eu.amazon.com';

// Delay helper for rate limiting
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Sponsored Brands specific metrics - only the relevant ones
const SB_COLUMNS = [
  "date",
  "campaignId",
  "campaignName",
  "campaignStatus",
  "campaignBudgetAmount",
  "campaignBudgetCurrencyCode",
  "campaignBudgetType",
  "costType",
  "impressions",
  "clicks",
  "cost",
  "purchases",
  "sales",
  "unitsSold",
  "topOfSearchImpressionShare",
  "detailPageViews",
  "addToCart",
  "newToBrandPurchases",
  "newToBrandSales",
  "newToBrandUnitsSold",
  "videoCompleteViews",
  "video5SecondViews"
];

// Refresh OAuth token - now accepts dynamic refresh token key
async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');
  
  // Use custom refresh token key if provided, otherwise default
  const tokenEnvKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenEnvKey);

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error(`Missing Amazon API credentials (token key: ${tokenEnvKey})`);
  }

  console.log(`Refreshing Amazon access token for SB using ${tokenEnvKey}...`);
  
  const response = await fetch(AMAZON_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      client_id: clientId,
      client_secret: clientSecret,
      refresh_token: refreshToken,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Token refresh failed:', errorText);
    throw new Error(`${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('Token refreshed successfully for SB');
  return data.access_token;
}

async function createSBReport(accessToken: string, profileId: string, startDate: string, endDate: string): Promise<string> {
  console.log(`Creating SB report for profile ${profileId}, dates: ${startDate} to ${endDate}`);
  
  const reportConfig = {
    name: `SB Campaign Report ${startDate} to ${endDate}`,
    startDate: startDate,
    endDate: endDate,
    configuration: {
      adProduct: "SPONSORED_BRANDS",
      groupBy: ["campaign"],
      columns: SB_COLUMNS,
      reportTypeId: "sbCampaigns",
      timeUnit: "DAILY",
      format: "GZIP_JSON"
    }
  };

  console.log('SB Report config:', JSON.stringify(reportConfig, null, 2));

  const response = await fetch(`${AMAZON_ADS_API_URL}/reporting/reports`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Content-Type': 'application/vnd.createasyncreportrequest.v3+json',
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
    body: JSON.stringify(reportConfig),
  });

  const responseText = await response.text();
  console.log(`SB Report creation response status: ${response.status}`);
  console.log(`SB Report creation response: ${responseText}`);

  if (!response.ok) {
    // Check if report already exists
    if (response.status === 422 && responseText.includes('already exists')) {
      console.log('SB Report already exists, extracting report ID...');
      const match = responseText.match(/reportId['":\s]+([a-zA-Z0-9-]+)/);
      if (match) {
        return match[1];
      }
    }
    throw new Error(`${response.status} - ${responseText}`);
  }

  const data = JSON.parse(responseText);
  console.log(`SB Report created with ID: ${data.reportId}`);
  return data.reportId;
}

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== fetch-amazon-data-sb started ===');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Parse request body
    const body = await req.json();
    const { profileIds, startDate, endDate, triggerAlertCheck = false, batch_id } = body;

    console.log(`Received request for SB profiles: ${JSON.stringify(profileIds)}`);
    console.log(`Date range: ${startDate} to ${endDate}`);
    console.log(`Trigger alert check: ${triggerAlertCheck}`);
    console.log(`Batch ID: ${batch_id}`);

    if (!profileIds || profileIds.length === 0) {
      throw new Error('No profile IDs provided');
    }

    // Get refresh_token_key mapping for all profiles
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    if (accountsError) {
      console.error('Error fetching accounts:', accountsError);
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    // Create a map of profile_id -> refresh_token_key
    const tokenKeyMap = new Map<string, string | null>();
    for (const account of accounts || []) {
      tokenKeyMap.set(account.profile_id, account.refresh_token_key);
    }

    console.log('Token key mapping:', Object.fromEntries(tokenKeyMap));

    const results: { profileId: string; success: boolean; reportId?: string; error?: string }[] = [];

    // Group profiles by refresh_token_key to minimize token refreshes
    const profilesByToken = new Map<string, string[]>();
    for (const profileId of profileIds) {
      const tokenKey = tokenKeyMap.get(profileId) || 'AMAZON_REFRESH_TOKEN';
      if (!profilesByToken.has(tokenKey)) {
        profilesByToken.set(tokenKey, []);
      }
      profilesByToken.get(tokenKey)!.push(profileId);
    }

    // Process each token group
    for (const [tokenKey, groupProfileIds] of profilesByToken) {
      let accessToken: string;
      try {
        accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
      } catch (tokenError) {
        const errorMsg = tokenError instanceof Error ? tokenError.message : String(tokenError);
        console.error(`Token refresh failed for ${tokenKey}:`, errorMsg);
        
        // Insert creation_failed for all profiles in this token group
        for (const profileId of groupProfileIds) {
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: startDate,
            end_date: endDate,
            status: 'creation_failed',
            error_message: `Token-Aktualisierung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sb',
            batch_id: batch_id || null,
          });
          results.push({ profileId, success: false, error: errorMsg });
        }
        continue;
      }

      let isFirstProfile = true;
      for (const profileId of groupProfileIds) {
        // Rate limiting: wait 3 seconds between API calls (skip first)
        if (!isFirstProfile) {
          console.log(`[RATE LIMIT] Waiting 3s before next SB request...`);
          await delay(3000);
        }
        isFirstProfile = false;

        try {
          console.log(`Processing SB profile: ${profileId} (token: ${tokenKey})`);
          
          const reportId = await createSBReport(accessToken, profileId, startDate, endDate);
          
          // Save to pending_reports with report_type = 'sb'
          const { error: insertError } = await supabase
            .from('pending_reports')
            .insert({
              profile_id: profileId,
              report_id: reportId,
              start_date: startDate,
              end_date: endDate,
              status: 'pending',
              trigger_alert_check: triggerAlertCheck,
              report_type: 'sb',
              batch_id: batch_id || null,
            });

          if (insertError) {
            console.error(`Error saving SB pending report for ${profileId}:`, insertError);
            results.push({ profileId, success: false, error: insertError.message });
          } else {
            console.log(`SB Pending report saved for profile ${profileId}, report ${reportId}`);
            results.push({ profileId, success: true, reportId });
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error(`Error processing SB profile ${profileId}:`, errorMsg);
          
          // Insert with creation_failed status so it's visible in the UI
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: startDate,
            end_date: endDate,
            status: 'creation_failed',
            error_message: `Report-Erstellung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sb',
            batch_id: batch_id || null,
          });

          results.push({ profileId, success: false, error: errorMsg });
        }
      }
    }

    console.log('=== fetch-amazon-data-sb completed ===');
    console.log(`Results: ${JSON.stringify(results)}`);

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Created ${results.filter(r => r.success).length} SB report jobs`,
        results 
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.error('Fatal error in fetch-amazon-data-sb:', error);
    return new Response(
      JSON.stringify({ success: false, error: errMsg }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

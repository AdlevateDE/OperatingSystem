import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

interface RunAlertChecksRequest {
  user_id: string
  profile_ids: string[]
  run_type: 'manual' | 'scheduled'
  rule_id?: string
}

// Metric column mapping for SP table
const SP_METRIC_COLUMN_MAP: Record<string, string> = {
  'cost': 'cost',
  'clicks': 'clicks',
  'impressions': 'impressions',
  'cpc': 'cost_per_click',
  'ctr': 'click_through_rate',
  'acos': 'acos_clicks_14d',
  'roas': 'roas_clicks_14d',
  'cost_no_conversions': 'cost',
  'purchases': 'purchases_14d',
  'sales': 'sales_14d',
}

// Metric column mapping for SB table (different column names!)
const SB_METRIC_COLUMN_MAP: Record<string, string> = {
  'cost': 'cost',
  'clicks': 'clicks',
  'impressions': 'impressions',
  'cpc': 'cost', // Calculate: cost / clicks
  'ctr': 'clicks', // Calculate: clicks / impressions * 100
  'acos': 'cost', // Calculate: cost / sales * 100
  'roas': 'sales', // Calculate: sales / cost
  'cost_no_conversions': 'cost',
  'purchases': 'purchases',
  'sales': 'sales',
}

// Metric column mapping for SD table (click-attributed metrics!)
const SD_METRIC_COLUMN_MAP: Record<string, string> = {
  'cost': 'cost',
  'clicks': 'clicks',
  'impressions': 'impressions',
  'cpc': 'cost', // Calculate: cost / clicks
  'ctr': 'clicks', // Calculate: clicks / impressions * 100
  'acos': 'cost', // Calculate: cost / sales_clicks * 100
  'roas': 'sales_clicks', // Calculate: sales_clicks / cost
  'cost_no_conversions': 'cost',
  'purchases': 'purchases_clicks',
  'sales': 'sales_clicks',
}

Deno.serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  const startTime = Date.now()
  let supabaseAdmin: any = null
  let runId: string | null = null

  // Initialize Supabase client FIRST
  try {
    supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? ''
    )
  } catch (initError: any) {
    console.error('[CRITICAL] Failed to initialize Supabase:', initError.message)
    return new Response(JSON.stringify({ success: false, error: 'DB init failed' }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  // Parse request
  let requestData: RunAlertChecksRequest
  try {
    requestData = await req.json() as RunAlertChecksRequest
  } catch (parseError: any) {
    console.error('[ERROR] Failed to parse request:', parseError.message)
    return new Response(JSON.stringify({ success: false, error: 'Invalid request body' }), {
      status: 400,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }

  const { user_id, profile_ids, run_type, rule_id } = requestData

  // Create run log entry IMMEDIATELY
  try {
    const { data: runData } = await supabaseAdmin
      .from('function_runs')
      .insert({
        function_name: 'run-alert-checks',
        status: 'running',
        trigger_source: run_type,
        metadata: {
          user_id,
          profile_ids,
          rule_id,
          started_at_iso: new Date().toISOString(),
        },
      })
      .select('id')
      .single()
    
    runId = runData?.id
    console.log(`=== RUN-ALERT-CHECKS STARTED (run_id: ${runId}) ===`)
  } catch (logError: any) {
    console.error('[WARN] Failed to create run log:', logError.message)
  }

  // Helper to update run status
  const updateRunStatus = async (status: string, errorMessage?: string, metadata?: object) => {
    if (!runId || !supabaseAdmin) return
    const duration = Date.now() - startTime
    try {
      await supabaseAdmin
        .from('function_runs')
        .update({
          status,
          finished_at: new Date().toISOString(),
          duration_ms: duration,
          error_message: errorMessage?.substring(0, 2000),
          metadata: { ...(metadata || {}), duration_ms: duration },
        })
        .eq('id', runId)
    } catch (e) {
      console.error('[WARN] Failed to update run log:', e)
    }
  }

  console.log('run-alert-checks:', { user_id, profile_ids, run_type, rule_id })

  try {
    // Delete duplicates from campaign_metrics_sp before running checks
    console.log('Cleaning up duplicates in campaign_metrics_sp...')
    const { error: cleanupError } = await supabaseAdmin.rpc('delete_duplicates_spcampaigns')
    if (cleanupError) {
      console.error('Error cleaning up duplicates:', cleanupError)
    } else {
      console.log('Duplicate cleanup completed successfully')
    }

    // User validation - fetch email for tracking who triggered manual alerts
    const { data: userData } = await supabaseAdmin
      .from('users')
      .select('id, email')
      .eq('id', user_id)
      .single()

    if (!userData) {
      throw new Error('User not found')
    }

    // Fetch rules (now includes campaign selection fields, account_ids, and campaign_types)
    let rulesQuery = supabaseAdmin
      .from('alert_rules')
      .select(`
        *,
        amazon_accounts!inner (
          id,
          account_name,
          profile_id
        )
      `)
      .eq('is_active', true)

    if (run_type === 'manual' && rule_id) {
      rulesQuery = rulesQuery.eq('id', rule_id)
    } else {
      rulesQuery = rulesQuery.in('amazon_accounts.profile_id', profile_ids)
    }

    const { data: rawRules, error: rulesError } = await rulesQuery

    if (rulesError) throw rulesError
    if (!rawRules || rawRules.length === 0) {
      throw new Error('No active rules found')
    }

    // Expand rules that have multiple account_ids into separate rule-account combinations
    const rules: any[] = []
    for (const rule of rawRules) {
      const accountIds: string[] = (rule as any).account_ids || [(rule as any).account_id]
      
      if (accountIds.length > 1) {
        const { data: multiAccounts } = await supabaseAdmin
          .from('amazon_accounts')
          .select('id, account_name, profile_id')
          .in('id', accountIds)
        
        if (multiAccounts) {
          for (const acc of multiAccounts) {
            if (run_type === 'manual' && rule_id) {
              rules.push({ ...rule, amazon_accounts: acc })
            } else if (profile_ids.includes(acc.profile_id)) {
              rules.push({ ...rule, amazon_accounts: acc })
            }
          }
        }
      } else {
        rules.push(rule)
      }
    }

    if (rules.length === 0) {
      throw new Error('No active rules found for the specified profiles')
    }

    console.log(`Checking ${rules.length} rule-account combinations (from ${rawRules.length} rules)`)

    const today = new Date()
    today.setHours(0, 0, 0, 0)
    const todayStr = today.toISOString().split('T')[0]

    // ========== DATEN-VERFÜGBARKEITS-CHECK ==========
    // Prüfen ob ÜBERHAUPT Daten für heute existieren (übergreifend)
    console.log(`Checking data availability for ${todayStr}...`)
    
    const [spDataCheck, sbDataCheck, sdDataCheck] = await Promise.all([
      supabaseAdmin.from('campaign_metrics_sp').select('id').eq('date', todayStr).limit(1),
      supabaseAdmin.from('campaign_metrics_sb').select('id').eq('date', todayStr).limit(1),
      supabaseAdmin.from('campaign_metrics_sd').select('id').eq('date', todayStr).limit(1),
    ])

    const hasAnyDataToday = 
      (spDataCheck.data?.length || 0) > 0 || 
      (sbDataCheck.data?.length || 0) > 0 || 
      (sdDataCheck.data?.length || 0) > 0

    console.log(`Data availability: SP=${spDataCheck.data?.length || 0}, SB=${sbDataCheck.data?.length || 0}, SD=${sdDataCheck.data?.length || 0}`)

    if (!hasAnyDataToday) {
      console.log('⚠️ WARNUNG: Keine Kampagnen-Daten für heute gefunden!')
      
      // Collect all account names that would have been checked
      const allAccountsChecked = [...new Set(rules.map(r => r.amazon_accounts.account_name))]
      
      // Create a "no_data" alert entry
      const { data: noDataAlert, error: noDataError } = await supabaseAdmin
        .from('alerts')
        .insert({
          account_id: rules[0]?.amazon_accounts?.id,
          rule_id: run_type === 'manual' ? rule_id : null,
          run_type: run_type,
          triggered_by_email: run_type === 'manual' ? userData?.email : null,
          is_all_clear: false,
          is_no_data: true,
          alert_date: todayStr,
          total_items: 0,
        })
        .select()
        .single()

      if (noDataError) {
        console.error('Error creating no_data alert:', noDataError)
      }

      // Send Slack notification about missing data
      if (noDataAlert?.id) {
        try {
          await supabaseAdmin.functions.invoke('send-slack-alert', {
            body: {
              alert_id: noDataAlert.id,
              user_id,
              run_type,
              rule_id,
              has_alerts: false,
              is_no_data: true,
              summary: {
                total_rules_checked: rules.length,
                rules_triggered: [],
                accounts_affected: [],
                accounts_checked: allAccountsChecked,
              },
            },
          })
        } catch (err) {
          console.error('Failed to send no_data Slack alert:', err)
        }
      }

      return new Response(JSON.stringify({
        success: true,
        alert_id: noDataAlert?.id,
        has_alerts: false,
        is_no_data: true,
        total_campaigns: 0,
        message: 'Keine Daten für heute verfügbar',
        summary: {
          total_rules_checked: rules.length,
          rules_triggered: [],
          accounts_affected: [],
          accounts_checked: allAccountsChecked,
        },
      }), {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' }
      })
    }

    // ========== REGEL-HIERARCHIE LOGIK ==========
    const campaignsCoveredBySpecificRules = new Map<string, Set<string>>()
    
    for (const rule of rules) {
      const mode = (rule as any).campaign_selection_mode || 'all'
      const selectedCampaigns: string[] = (rule as any).selected_campaigns || []
      const accountId = (rule as any).amazon_accounts.id
      const metricName = rule.metric_name
      
      if (mode === 'include' && selectedCampaigns.length > 0) {
        const key = `${accountId}|${metricName}`
        if (!campaignsCoveredBySpecificRules.has(key)) {
          campaignsCoveredBySpecificRules.set(key, new Set())
        }
        selectedCampaigns.forEach(name => campaignsCoveredBySpecificRules.get(key)!.add(name))
      }
    }
    
    console.log('Campaigns covered by specific rules:', 
      Object.fromEntries(
        Array.from(campaignsCoveredBySpecificRules.entries()).map(([k, v]) => [k, Array.from(v)])
      )
    )

    // Helper function to get date range for comparison period
    const getBaselineDates = (comparison_period: string) => {
      if (comparison_period === 'same_day_last_week') {
        const targetDate = new Date(today)
        targetDate.setDate(targetDate.getDate() - 7)
        return { startDate: targetDate, endDate: targetDate, days: 1 }
      }

      const periods: Record<string, number> = {
        yesterday: 1,
        last_7_days: 7,
        last_14_days: 14,
        last_30_days: 30,
      }
      const days = periods[comparison_period] || 7

      const endDate = new Date(today)
      endDate.setDate(endDate.getDate() - 1)

      const startDate = new Date(endDate)
      startDate.setDate(startDate.getDate() - days + 1)

      return { startDate, endDate, days }
    }

    // Helper function to get metrics table name based on campaign type
    const getMetricsTable = (campaignType: string) => {
      switch (campaignType) {
        case 'sb': return 'campaign_metrics_sb'
        case 'sd': return 'campaign_metrics_sd'
        default: return 'campaign_metrics_sp'
      }
    }

    // Helper function to get column name based on metric and campaign type
    const getMetricColumn = (metricName: string, campaignType: string) => {
      let map: Record<string, string>
      switch (campaignType) {
        case 'sb': map = SB_METRIC_COLUMN_MAP; break
        case 'sd': map = SD_METRIC_COLUMN_MAP; break
        default: map = SP_METRIC_COLUMN_MAP
      }
      return map[metricName] || metricName
    }

    // Helper function to extract metric value from row (handles calculated metrics for SB)
    const extractMetricValue = (row: any, metricName: string, campaignType: string): number => {
      if (campaignType === 'sb') {
        // SB needs calculated metrics
        switch (metricName) {
          case 'cpc':
            const sbClicks = parseFloat(row.clicks || '0')
            return sbClicks > 0 ? parseFloat(row.cost || '0') / sbClicks : 0
          case 'ctr':
            const sbImpressions = parseFloat(row.impressions || '0')
            return sbImpressions > 0 ? (parseFloat(row.clicks || '0') / sbImpressions) * 100 : 0
          case 'acos':
            const sbSales = parseFloat(row.sales || '0')
            return sbSales > 0 ? (parseFloat(row.cost || '0') / sbSales) * 100 : 0
          case 'roas':
            const sbCost = parseFloat(row.cost || '0')
            return sbCost > 0 ? parseFloat(row.sales || '0') / sbCost : 0
          default:
            return parseFloat(row[getMetricColumn(metricName, 'sb')] || '0')
        }
      } else if (campaignType === 'sd') {
        // SD needs calculated metrics with click-attributed values
        switch (metricName) {
          case 'cpc':
            const sdClicks = parseFloat(row.clicks || '0')
            return sdClicks > 0 ? parseFloat(row.cost || '0') / sdClicks : 0
          case 'ctr':
            const sdImpressions = parseFloat(row.impressions || '0')
            return sdImpressions > 0 ? (parseFloat(row.clicks || '0') / sdImpressions) * 100 : 0
          case 'acos':
            const sdSales = parseFloat(row.sales_clicks || '0')
            return sdSales > 0 ? (parseFloat(row.cost || '0') / sdSales) * 100 : 0
          case 'roas':
            const sdCost = parseFloat(row.cost || '0')
            return sdCost > 0 ? parseFloat(row.sales_clicks || '0') / sdCost : 0
          default:
            return parseFloat(row[getMetricColumn(metricName, 'sd')] || '0')
        }
      } else {
        // SP direct mapping
        return parseFloat(row[getMetricColumn(metricName, 'sp')] || '0')
      }
    }

    const affectedCampaigns: any[] = []

    // Check each rule
    for (const rule of rules) {
      const profileId = (rule as any).amazon_accounts.profile_id
      const accountName = (rule as any).amazon_accounts.account_name
      const accountId = (rule as any).amazon_accounts.id
      
      // Get campaign types from rule (default to ['sp'])
      const campaignTypes: string[] = (rule as any).campaign_types || ['sp']
      
      // Get campaign selection settings from rule
      const campaignSelectionMode = (rule as any).campaign_selection_mode || 'all'
      const selectedCampaigns: string[] = (rule as any).selected_campaigns || []
      
      // Get campaign pre-filters from rule
      const campaignFilters: Array<{metric: string, operator: string, value: number, period_days: number}> = (rule as any).campaign_filters || []
      const campaignFiltersLogic: 'AND' | 'OR' = (rule as any).campaign_filters_logic || 'AND'

      // Get alert conditions - normalize field names from different formats
      const rawConditions = (rule as any).alert_conditions
      const alertConditions: Array<{metric_name: string, threshold_value: number, threshold_type: string, alert_direction: string, comparison_period: string}> = 
        rawConditions && Array.isArray(rawConditions) && rawConditions.length > 0
          ? rawConditions.map((c: any) => ({
              // Support both old format (metric, threshold, direction) and new format (metric_name, threshold_value, etc.)
              metric_name: c.metric_name || c.metric,
              threshold_value: c.threshold_value ?? c.threshold ?? 0,
              threshold_type: c.threshold_type || c.thresholdType || 'percentage',
              alert_direction: c.alert_direction || c.direction || 'both',
              comparison_period: c.comparison_period || rule.comparison_period,
            }))
          : [{
              metric_name: rule.metric_name,
              threshold_value: rule.threshold_percent,
              threshold_type: rule.threshold_type || 'percentage',
              alert_direction: rule.alert_direction || 'both',
              comparison_period: rule.comparison_period,
            }]
      const alertConditionsLogic: 'AND' | 'OR' = (rule as any).alert_conditions_logic || 'AND'

      console.log(`✅ Checking rule: ${rule.rule_name} for profile ${profileId}`)
      console.log(`Campaign types: ${campaignTypes.join(', ')}, selection mode: ${campaignSelectionMode}`)
      console.log(`Alert conditions: ${alertConditions.length} conditions with ${alertConditionsLogic} logic`)

      // Process each campaign type separately
      for (const campaignType of campaignTypes) {
        const metricsTable = getMetricsTable(campaignType)
        console.log(`Processing ${campaignType.toUpperCase()} campaigns from ${metricsTable}`)

        // Build query for today's campaigns
        let todayCampaignsQuery = supabaseAdmin
          .from(metricsTable)
          .select('campaign_id, campaign_name')
          .eq('profile_id', profileId)
          .eq('date', todayStr)

        // Apply campaign name filtering based on selection mode
        if (campaignSelectionMode === 'include' && selectedCampaigns.length > 0) {
          todayCampaignsQuery = todayCampaignsQuery.in('campaign_name', selectedCampaigns)
          console.log(`Filtering to include only: ${selectedCampaigns.length} campaigns`)
        }

        const { data: todayCampaigns, error: todayError } = await todayCampaignsQuery

        if (todayError) {
          console.error(`Error fetching ${campaignType} campaigns:`, todayError)
          continue
        }

        if (!todayCampaigns || todayCampaigns.length === 0) {
          console.log(`No ${campaignType.toUpperCase()} campaigns with data for today (${todayStr})`)
          continue
        }
        
        // For exclude mode, filter out excluded campaigns
        let filteredCampaigns: Array<{campaign_id: number, campaign_name: string | null}> = todayCampaigns
        if (campaignSelectionMode === 'exclude' && selectedCampaigns.length > 0) {
          filteredCampaigns = todayCampaigns.filter((c: any) => !selectedCampaigns.includes(c.campaign_name || ''))
          console.log(`Excluding ${selectedCampaigns.length} campaigns, remaining: ${filteredCampaigns.length}`)
        }
        
        // Hierarchy: Skip campaigns covered by specific rules
        if (campaignSelectionMode === 'all' || campaignSelectionMode === 'exclude') {
          const hierarchyKey = `${accountId}|${rule.metric_name}`
          const coveredCampaigns = campaignsCoveredBySpecificRules.get(hierarchyKey)
          
          if (coveredCampaigns && coveredCampaigns.size > 0) {
            const beforeCount = filteredCampaigns.length
            filteredCampaigns = filteredCampaigns.filter((c: any) => !coveredCampaigns.has(c.campaign_name || ''))
            const skippedCount = beforeCount - filteredCampaigns.length
            if (skippedCount > 0) {
              console.log(`Hierarchie: ${skippedCount} Kampagnen übersprungen`)
            }
          }
        }
        
        // ========== BATCH PRE-FILTER OPTIMIZATION ==========
        if (campaignSelectionMode === 'all' && campaignFilters.length > 0) {
          const campaignsBeforeFilter = filteredCampaigns.length
          const allCampaignIds = filteredCampaigns.map((c: any) => c.campaign_id)
          
          // Calculate the maximum date range needed for all filters
          let maxPeriodDays = 7
          for (const filter of campaignFilters) {
            const periodDays = filter.period_days || 7
            if (periodDays > maxPeriodDays) maxPeriodDays = periodDays
          }
          
          const filterEndDate = new Date(today)
          filterEndDate.setDate(filterEndDate.getDate() - 1)
          const filterStartDate = new Date(filterEndDate)
          filterStartDate.setDate(filterStartDate.getDate() - maxPeriodDays + 1)
          const filterStartStr = filterStartDate.toISOString().split('T')[0]
          const filterEndStr = filterEndDate.toISOString().split('T')[0]
          
          // BATCH: Fetch all filter metrics in ONE query
          const { data: allFilterMetrics } = await supabaseAdmin
            .from(metricsTable)
            .select('campaign_id, date, cost, clicks, impressions, sales, sales_clicks, purchases, purchases_clicks, purchases_14d, sales_14d')
            .eq('profile_id', profileId)
            .in('campaign_id', allCampaignIds)
            .gte('date', filterStartStr)
            .lte('date', filterEndStr)
          
          // Group metrics by campaign_id
          const filterMetricsByCampaign = new Map<number, any[]>()
          if (allFilterMetrics) {
            for (const m of allFilterMetrics) {
              if (!filterMetricsByCampaign.has(m.campaign_id)) {
                filterMetricsByCampaign.set(m.campaign_id, [])
              }
              filterMetricsByCampaign.get(m.campaign_id)!.push(m)
            }
          }
          
          const campaignsToKeep: typeof filteredCampaigns = []
          
          for (const campaign of filteredCampaigns) {
            const campaignMetrics = filterMetricsByCampaign.get(campaign.campaign_id) || []
            const filterResults: boolean[] = []
            
            for (const filter of campaignFilters) {
              const periodDays = filter.period_days || 7
              const filterPeriodEnd = new Date(today)
              filterPeriodEnd.setDate(filterPeriodEnd.getDate() - 1)
              const filterPeriodStart = new Date(filterPeriodEnd)
              filterPeriodStart.setDate(filterPeriodStart.getDate() - periodDays + 1)
              const periodStartStr = filterPeriodStart.toISOString().split('T')[0]
              const periodEndStr = filterPeriodEnd.toISOString().split('T')[0]
              
              // Filter metrics for this specific period
              const periodMetrics = campaignMetrics.filter(m => 
                m.date >= periodStartStr && m.date <= periodEndStr
              )
              
              if (periodMetrics.length === 0) {
                filterResults.push(false)
                continue
              }
              
              const sum = periodMetrics.reduce((acc, m: any) => acc + extractMetricValue(m, filter.metric, campaignType), 0)
              const avgValue = sum / periodMetrics.length
              
              let passes = false
              switch (filter.operator) {
                case '<': passes = avgValue < filter.value; break
                case '<=': passes = avgValue <= filter.value; break
                case '>': passes = avgValue > filter.value; break
                case '>=': passes = avgValue >= filter.value; break
                case '=': passes = Math.abs(avgValue - filter.value) < 0.001; break
              }
              
              filterResults.push(passes)
            }
            
            const campaignPasses = campaignFiltersLogic === 'AND'
              ? filterResults.every(r => r)
              : filterResults.some(r => r)
            
            if (campaignPasses) {
              campaignsToKeep.push(campaign)
            }
          }
          
          filteredCampaigns = campaignsToKeep
          const filteredOutCount = campaignsBeforeFilter - filteredCampaigns.length
          if (filteredOutCount > 0) {
            console.log(`Vorfilter: ${filteredOutCount} Kampagnen herausgefiltert (${filteredCampaigns.length} verbleibend)`)
          }
        }
        
        console.log(`Found ${filteredCampaigns.length} ${campaignType.toUpperCase()} campaigns with data for today`)

        const uniqueCampaignIds: number[] = [...new Set(filteredCampaigns.map((c: any) => c.campaign_id as number))]
        console.log(`Checking ${uniqueCampaignIds.length} unique ${campaignType.toUpperCase()} campaigns`)

        if (uniqueCampaignIds.length === 0) continue

        // ========== BATCH TODAY'S METRICS OPTIMIZATION ==========
        const selectColumns = campaignType === 'sb' 
          ? '*, campaign_name, campaign_status, campaign_budget_type, campaign_budget_amount, campaign_budget_currency_code, purchases, sales'
          : campaignType === 'sd'
            ? '*, campaign_name, campaign_status, campaign_budget_type, campaign_budget_amount, campaign_budget_currency_code, purchases_clicks, sales_clicks'
            : '*, campaign_name, campaign_status, campaign_budget_type, campaign_budget_amount, campaign_budget_currency_code, purchases_14d, sales_14d'

        // BATCH: Fetch all today's metrics in ONE query
        const { data: allTodayMetrics } = await supabaseAdmin
          .from(metricsTable)
          .select(selectColumns)
          .eq('profile_id', profileId)
          .eq('date', todayStr)
          .in('campaign_id', uniqueCampaignIds)

        // Create lookup map for quick access
        const todayMetricsMap = new Map<number, any>()
        if (allTodayMetrics) {
          for (const m of allTodayMetrics) {
            todayMetricsMap.set(m.campaign_id, m)
          }
        }

        // ========== BATCH BASELINE METRICS OPTIMIZATION ==========
        // Collect all unique comparison periods needed
        const uniqueComparisonPeriods = [...new Set(alertConditions.map(c => c.comparison_period).filter(p => p !== 'none'))]
        
        // Pre-fetch baseline metrics for all campaigns and all comparison periods
        const baselineMetricsByPeriod = new Map<string, Map<number, any[]>>()
        
        for (const compPeriod of uniqueComparisonPeriods) {
          const { startDate, endDate } = getBaselineDates(compPeriod)
          const startStr = startDate.toISOString().split('T')[0]
          const endStr = endDate.toISOString().split('T')[0]
          
          // BATCH: Fetch all baseline metrics in ONE query per period (use * for simplicity)
          const { data: allBaselineMetrics } = await supabaseAdmin
            .from(metricsTable)
            .select('*')
            .eq('profile_id', profileId)
            .in('campaign_id', uniqueCampaignIds)
            .gte('date', startStr)
            .lte('date', endStr)
          
          // Group by campaign_id
          const metricsByCampaign = new Map<number, any[]>()
          if (allBaselineMetrics) {
            for (const m of allBaselineMetrics as any[]) {
              if (!metricsByCampaign.has(m.campaign_id)) {
                metricsByCampaign.set(m.campaign_id, [])
              }
              metricsByCampaign.get(m.campaign_id)!.push(m)
            }
          }
          
          baselineMetricsByPeriod.set(compPeriod, metricsByCampaign)
        }

        console.log(`Batch-loaded: ${allTodayMetrics?.length || 0} today metrics, ${uniqueComparisonPeriods.length} baseline periods`)

        let campaignsChecked = 0
        let campaignsBelowThreshold = 0

        for (const campaignId of uniqueCampaignIds) {
          campaignsChecked++
          
          // Get today's metrics from map (no DB call)
          const todayMetrics = todayMetricsMap.get(campaignId)
          if (!todayMetrics) continue

          // Evaluate conditions
          const conditionResults: Array<{
            condition: typeof alertConditions[0],
            passed: boolean,
            currentValue: number,
            referenceValue: number,
            deviation: number,
            isAbsolute: boolean,
          }> = []

          for (const condition of alertConditions) {
            const currentValue = extractMetricValue(todayMetrics, condition.metric_name, campaignType)
            
            // Special handling for cost_no_conversions metric
            if (condition.metric_name === 'cost_no_conversions') {
              const cost = parseFloat(todayMetrics.cost || '0')
              const conversions = campaignType === 'sb' 
                ? parseInt(todayMetrics.purchases || '0')
                : campaignType === 'sd'
                  ? parseInt(todayMetrics.purchases_clicks || '0')
                  : parseInt(todayMetrics.purchases_14d || '0')
              const passes = cost > condition.threshold_value && conversions === 0
              
              conditionResults.push({
                condition,
                passed: passes,
                currentValue: cost,
                referenceValue: condition.threshold_value,
                deviation: 0,
                isAbsolute: true,
              })
              continue
            }

            // Handle absolute threshold type WITHOUT comparison period
            if (condition.threshold_type === 'absolute' && condition.comparison_period === 'none') {
              const direction = condition.alert_direction || 'increases'
              let passes = false
              if (direction === 'increases') {
                passes = currentValue > condition.threshold_value
              } else if (direction === 'decreases') {
                passes = currentValue < condition.threshold_value
              }
              
              conditionResults.push({
                condition,
                passed: passes,
                currentValue,
                referenceValue: condition.threshold_value,
                deviation: 0,
                isAbsolute: true,
              })
              continue
            }

            // Get baseline metrics from pre-fetched map (no DB call)
            const baselineByCampaign = baselineMetricsByPeriod.get(condition.comparison_period)
            const baselineMetrics = baselineByCampaign?.get(campaignId) || []

            if (baselineMetrics.length === 0) {
              conditionResults.push({
                condition,
                passed: false,
                currentValue,
                referenceValue: 0,
                deviation: 0,
                isAbsolute: false,
              })
              continue
            }

            // Calculate baseline (average)
            const sum = baselineMetrics.reduce((acc, m: any) => acc + extractMetricValue(m, condition.metric_name, campaignType), 0)
            const actualDays = baselineMetrics.length
            const referenceValue = sum / actualDays

            // Calculate deviation
            const isAbsoluteWithComparison = condition.threshold_type === 'absolute' && condition.comparison_period !== 'none'
            const deviationPercent = referenceValue !== 0 
              ? ((currentValue - referenceValue) / referenceValue) * 100 
              : 0
            const absoluteDeviation = currentValue - referenceValue

            // Check if condition passes
            const direction = condition.alert_direction || 'both'
            let passes = false
            
            if (isAbsoluteWithComparison) {
              if (direction === 'decreases') {
                passes = absoluteDeviation <= -condition.threshold_value
              } else if (direction === 'increases') {
                passes = absoluteDeviation >= condition.threshold_value
              } else {
                passes = Math.abs(absoluteDeviation) >= condition.threshold_value
              }
            } else {
              if (direction === 'decreases') {
                passes = deviationPercent <= -condition.threshold_value
              } else if (direction === 'increases') {
                passes = deviationPercent >= condition.threshold_value
              } else {
                passes = Math.abs(deviationPercent) >= condition.threshold_value
              }
            }

            conditionResults.push({
              condition,
              passed: passes,
              currentValue,
              referenceValue,
              deviation: isAbsoluteWithComparison ? absoluteDeviation : deviationPercent,
              isAbsolute: isAbsoluteWithComparison,
            })
          }

          // Apply AND/OR logic
          const alertShouldTrigger = alertConditionsLogic === 'AND'
            ? conditionResults.every(r => r.passed)
            : conditionResults.some(r => r.passed)

          if (alertShouldTrigger && conditionResults.length > 0) {
            const triggeredCondition = conditionResults.find(r => r.passed) || conditionResults[0]
            const { condition, currentValue, referenceValue, deviation, isAbsolute } = triggeredCondition

            const passedConditions = conditionResults.filter(r => r.passed).map(r => r.condition.metric_name)
            console.log(`Alert triggered for ${campaignType.toUpperCase()} campaign ${campaignId}: ${deviation.toFixed(2)}${isAbsolute ? '' : '%'} (conditions: ${passedConditions.join(', ')})`)

            // Get historical data from pre-fetched baseline (no additional DB call)
            const baselineByCampaign = baselineMetricsByPeriod.get(condition.comparison_period)
            const histMetrics = baselineByCampaign?.get(campaignId) || []

            const historicalData = [
              { date: todayStr, value: currentValue, is_today: true },
              ...histMetrics.map((m: any) => ({
                date: m.date,
                value: extractMetricValue(m, condition.metric_name, campaignType),
                is_today: false
              }))
            ]

            affectedCampaigns.push({
              campaign_id: campaignId,
              campaign_external_id: campaignId,
              campaign_name: todayMetrics.campaign_name || `Campaign ${campaignId}`,
              campaign_type: campaignType.toUpperCase(),
              campaign_status: todayMetrics.campaign_status,
              campaign_budget_type: todayMetrics.campaign_budget_type,
              campaign_budget_amount: todayMetrics.campaign_budget_amount,
              campaign_budget_currency_code: todayMetrics.campaign_budget_currency_code,
              rule_name: rule.rule_name,
              rule_id: rule.id,
              account_name: accountName,
              account_id: accountId,
              metric_name: condition.metric_name,
              current_value: currentValue,
              reference_value: referenceValue,
              deviation_percent: deviation,
              threshold_percent: condition.threshold_value,
              comparison_period: condition.comparison_period,
              alert_direction: condition.alert_direction || 'both',
              threshold_type: condition.threshold_type || 'percentage',
              historical_data: historicalData,
              impressions: todayMetrics.impressions,
              clicks: todayMetrics.clicks,
              click_through_rate: campaignType === 'sb' ? extractMetricValue(todayMetrics, 'ctr', 'sb') : todayMetrics.click_through_rate,
              cost: todayMetrics.cost,
              cost_per_click: campaignType === 'sb' ? extractMetricValue(todayMetrics, 'cpc', 'sb') : todayMetrics.cost_per_click,
              purchases_14d: campaignType === 'sb' ? todayMetrics.purchases : todayMetrics.purchases_14d,
              sales_14d: campaignType === 'sb' ? todayMetrics.sales : todayMetrics.sales_14d,
              units_sold_clicks_14d: campaignType === 'sb' ? todayMetrics.units_sold : todayMetrics.units_sold_clicks_14d,
              acos_clicks_14d: campaignType === 'sb' ? extractMetricValue(todayMetrics, 'acos', 'sb') : todayMetrics.acos_clicks_14d,
              roas_clicks_14d: campaignType === 'sb' ? extractMetricValue(todayMetrics, 'roas', 'sb') : todayMetrics.roas_clicks_14d,
              top_of_search_impression_share: todayMetrics.top_of_search_impression_share,
              conditions_evaluated: conditionResults.map(r => ({
                metric: r.condition.metric_name,
                passed: r.passed,
                current: r.currentValue,
                reference: r.referenceValue,
                deviation: r.deviation,
              })),
            })
          } else {
            const conditionSummary = conditionResults.map(r => 
              `${r.condition.metric_name}: ${r.passed ? 'PASS' : 'FAIL'} (${r.isAbsolute ? r.deviation.toFixed(2) : r.deviation.toFixed(2) + '%'} vs ${r.condition.threshold_value}${r.isAbsolute ? '' : '%'})`
            ).join(', ')
            console.log(`${campaignType.toUpperCase()} Campaign ${campaignId}: Below threshold - ${conditionSummary}`)
            campaignsBelowThreshold++
          }
        }
        
        console.log(`${campaignType.toUpperCase()} Rule summary - Checked: ${campaignsChecked}, Below threshold: ${campaignsBelowThreshold}`)
      }
    }

    const hasAlerts = affectedCampaigns.length > 0

    // Create alerts entry
    const { data: alert } = await supabaseAdmin
      .from('alerts')
      .insert({
        account_id: affectedCampaigns[0]?.account_id || rules[0].amazon_accounts.id,
        rule_id: run_type === 'manual' ? rule_id : null,
        run_type: run_type,
        triggered_by_email: run_type === 'manual' ? userData?.email : null,
        is_all_clear: !hasAlerts,
        sheets_url: null,
        alert_date: todayStr,
        total_items: affectedCampaigns.length,
      })
      .select()
      .single()

    // Create alert_items
    if (hasAlerts && alert) {
      const alertItems = affectedCampaigns.map(campaign => ({
        alert_id: alert.id,
        external_campaign_id: campaign.campaign_id ? parseInt(String(campaign.campaign_id), 10) : null,
        campaign_id: null,
        campaign_name: campaign.campaign_name,
        rule_name: campaign.rule_name,
        account_name: campaign.account_name,
        metric_name: campaign.metric_name,
        date: todayStr,
        current_value: campaign.current_value,
        reference_value: campaign.reference_value,
        deviation_percent: isFinite(campaign.deviation_percent) ? campaign.deviation_percent : 0,
        threshold_percent: campaign.threshold_percent,
        comparison_period: campaign.comparison_period,
        alert_direction: campaign.alert_direction,
      }))

      const { data: insertedItems, error: insertError } = await supabaseAdmin.from('alert_items').insert(alertItems).select()
      if (insertError) {
        console.error('Error inserting alert_items:', insertError)
      } else {
        console.log(`Created ${insertedItems?.length || 0} alert items`)
      }
    }

    // Build summary - include ALL accounts that were checked (for consolidated Slack message)
    const allAccountsChecked = [...new Set(rules.map(r => r.amazon_accounts.account_name))]
    const summary = {
      total_rules_checked: rules.length,
      rules_triggered: [...new Set(affectedCampaigns.map(c => c.rule_name))],
      accounts_affected: [...new Set(affectedCampaigns.map(c => c.account_name))],
      accounts_checked: allAccountsChecked,
    }
    
    console.log(`Summary: ${rules.length} rules checked across ${allAccountsChecked.length} accounts: ${allAccountsChecked.join(', ')}`)

    // Send Slack notification with retry logic (3 attempts)
    if (alert?.id) {
      let slackSuccess = false
      let lastError: string | null = null
      
      for (let attempt = 1; attempt <= 3; attempt++) {
        try {
          console.log(`Sending Slack alert (attempt ${attempt}/3) for alert ${alert.id}...`)
          
          const { data: slackResult, error: slackError } = await supabaseAdmin.functions.invoke('send-slack-alert', {
            body: {
              alert_id: alert.id,
              user_id,
              run_type,
              rule_id,
              has_alerts: hasAlerts,
              summary,
            },
          })
          
          if (slackError) {
            lastError = slackError.message || JSON.stringify(slackError)
            console.error(`Slack attempt ${attempt}/3 failed:`, lastError)
            if (attempt < 3) {
              console.log(`Waiting 2 seconds before retry...`)
              await new Promise(r => setTimeout(r, 2000))
            }
          } else {
            slackSuccess = true
            console.log(`Slack notification sent successfully on attempt ${attempt}`)
            break
          }
        } catch (err: any) {
          lastError = err?.message || String(err)
          console.error(`Slack attempt ${attempt}/3 exception:`, lastError)
          if (attempt < 3) {
            console.log(`Waiting 2 seconds before retry...`)
            await new Promise(r => setTimeout(r, 2000))
          }
        }
      }
      
      // If all attempts failed, store the error in the database
      if (!slackSuccess && lastError) {
        console.error(`All 3 Slack attempts failed. Last error: ${lastError}`)
        await supabaseAdmin
          .from('alerts')
          .update({ slack_error: lastError })
          .eq('id', alert.id)
      }
    }

    const duration = Date.now() - startTime
    console.log(`=== RUN-ALERT-CHECKS COMPLETED in ${duration}ms ===`)
    
    // Update run status to success
    await updateRunStatus('success', undefined, {
      alert_id: alert?.id,
      has_alerts: hasAlerts,
      total_campaigns: affectedCampaigns.length,
      rules_checked: rules.length,
    })

    return new Response(JSON.stringify({
      success: true,
      alert_id: alert?.id,
      has_alerts: hasAlerts,
      total_campaigns: affectedCampaigns.length,
      summary,
      run_id: runId,
      duration_ms: duration,
    }), {
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })

  } catch (error: any) {
    const duration = Date.now() - startTime
    console.error(`=== RUN-ALERT-CHECKS FAILED after ${duration}ms ===`)
    console.error('Error in run-alert-checks:', error.message)
    console.error('Stack:', error.stack)
    
    // Update run status to failed
    await updateRunStatus('failed', error.message, { 
      stack: error.stack?.substring(0, 1000),
      user_id,
      profile_ids,
    })
    
    return new Response(JSON.stringify({ 
      success: false, 
      error: error.message,
      run_id: runId,
      duration_ms: duration,
    }), {
      status: 500,
      headers: { ...corsHeaders, 'Content-Type': 'application/json' }
    })
  }
})

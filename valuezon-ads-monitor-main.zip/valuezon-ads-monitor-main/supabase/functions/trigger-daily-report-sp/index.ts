import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    // Get authenticated user
    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { rule_id, trigger_all, batch_id } = await req.json();
    const run_type = rule_id ? 'manual' : 'scheduled';
    
    console.log(`trigger-daily-report-sp: batch_id=${batch_id}, rule_id=${rule_id}, trigger_all=${trigger_all}`);

    let profileIds: string[] = [];
    let campaignTypes: string[] = ['sp']; // Default to SP

    if (rule_id) {
      // Single rule trigger - get profile_id(s) and campaign_types
      const { data: rule, error } = await supabase
        .from('alert_rules')
        .select(`
          id,
          account_id,
          account_ids,
          campaign_types,
          amazon_accounts!inner(profile_id)
        `)
        .eq('id', rule_id)
        .single();

      if (error) throw error;
      if (!rule) throw new Error('Rule not found');

      // Get campaign_types from rule (default to ['sp'] if not set)
      campaignTypes = (rule as any).campaign_types || ['sp'];
      console.log(`Rule ${rule_id} campaign_types:`, campaignTypes);

      // Get all account_ids from the rule (support both single and multi-account)
      const accountIds: string[] = (rule as any).account_ids || [(rule as any).account_id];

      // Verify user has access to at least one of these accounts via account_users
      const { data: access, error: accessError } = await supabase
        .from('account_users')
        .select('account_id')
        .in('account_id', accountIds)
        .eq('user_id', user.id);

      if (accessError || !access || access.length === 0) {
        throw new Error('Unauthorized - no access to accounts for this rule');
      }

      // Get profile_ids for all accounts the user has access to
      const accessibleAccountIds = access.map(a => a.account_id);
      const { data: accountsWithProfiles } = await supabase
        .from('amazon_accounts')
        .select('profile_id')
        .in('id', accessibleAccountIds);

      profileIds = accountsWithProfiles?.map(a => a.profile_id) || [];
      console.log(`Single rule ${rule_id}: Using ${profileIds.length} profile_ids from ${accessibleAccountIds.length} accounts`);
    } else if (trigger_all) {
      // Batch trigger - get all unique profile_ids and collect all campaign_types
      const { data: userAccounts, error: accountError } = await supabase
        .from('account_users')
        .select('account_id')
        .eq('user_id', user.id);

      if (accountError) throw accountError;

      const accountIds = userAccounts?.map(a => a.account_id) || [];

      if (accountIds.length === 0) {
        throw new Error('No accounts found for user');
      }

      const { data: rules, error } = await supabase
        .from('alert_rules')
        .select(`
          id,
          account_id,
          campaign_types,
          amazon_accounts!inner(profile_id)
        `)
        .eq('is_active', true)
        .in('account_id', accountIds);

      if (error) throw error;

      // Get unique profile_ids
      profileIds = [...new Set(rules?.map((r: any) => r.amazon_accounts.profile_id) || [])];
      
      // Collect all unique campaign_types from all rules
      const allCampaignTypes = new Set<string>();
      rules?.forEach((r: any) => {
        const types = r.campaign_types || ['sp'];
        types.forEach((t: string) => allCampaignTypes.add(t));
      });
      campaignTypes = Array.from(allCampaignTypes);
      
      console.log(`Batch trigger: Found ${profileIds.length} unique profile_ids, campaign_types: ${campaignTypes.join(', ')}`);
    } else {
      throw new Error('Either rule_id or trigger_all must be provided');
    }

    if (profileIds.length === 0) {
      throw new Error('No profile IDs found');
    }

    // Get today's date in YYYY-MM-DD format
    const today = new Date();
    const todayString = today.toISOString().split('T')[0];

    console.log(`Triggering fetch for profile_ids: ${profileIds.join(', ')}, date: ${todayString}, campaign_types: ${campaignTypes.join(', ')}`);

    const fetchResults: Record<string, any> = {};

    // Call fetch-amazon-data-sp if SP is in campaign_types
    if (campaignTypes.includes('sp')) {
      console.log('Calling fetch-amazon-data-sp...');
      const spResponse = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sp`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          profileIds: profileIds,
          startDate: todayString,
          endDate: todayString,
          triggerAlertCheck: true,
          run_type: run_type,
          rule_id: rule_id || null,
          batch_id: batch_id || null,
        }),
      });

      if (!spResponse.ok) {
        const errorText = await spResponse.text();
        console.error(`fetch-amazon-data-sp failed: ${spResponse.status} - ${errorText}`);
        fetchResults.sp = { error: errorText };
      } else {
        fetchResults.sp = await spResponse.json();
        console.log('fetch-amazon-data-sp response:', fetchResults.sp);
      }
    }

    // Call fetch-amazon-data-sb if SB is in campaign_types
    if (campaignTypes.includes('sb')) {
      console.log('Calling fetch-amazon-data-sb...');
      const sbResponse = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sb`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          profileIds: profileIds,
          startDate: todayString,
          endDate: todayString,
          triggerAlertCheck: true,
          run_type: run_type,
          rule_id: rule_id || null,
          batch_id: batch_id || null,
        }),
      });

      if (!sbResponse.ok) {
        const errorText = await sbResponse.text();
        console.error(`fetch-amazon-data-sb failed: ${sbResponse.status} - ${errorText}`);
        fetchResults.sb = { error: errorText };
      } else {
      fetchResults.sb = await sbResponse.json();
        console.log('fetch-amazon-data-sb response:', fetchResults.sb);
      }
    }

    // Call fetch-amazon-data-sd if SD is in campaign_types
    if (campaignTypes.includes('sd')) {
      console.log('Calling fetch-amazon-data-sd...');
      const sdResponse = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sd`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${supabaseKey}`,
        },
        body: JSON.stringify({
          profileIds: profileIds,
          startDate: todayString,
          endDate: todayString,
          triggerAlertCheck: true,
          run_type: run_type,
          rule_id: rule_id || null,
          batch_id: batch_id || null,
        }),
      });

      if (!sdResponse.ok) {
        const errorText = await sdResponse.text();
        console.error(`fetch-amazon-data-sd failed: ${sdResponse.status} - ${errorText}`);
        fetchResults.sd = { error: errorText };
      } else {
        fetchResults.sd = await sdResponse.json();
        console.log('fetch-amazon-data-sd response:', fetchResults.sd);
      }
    }

    return new Response(
      JSON.stringify({ 
        success: true, 
        profile_ids: profileIds,
        campaign_types: campaignTypes,
        run_type: run_type,
        date: todayString,
        message: 'Data sync started. Reports will be processed automatically.',
        fetch_results: fetchResults
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error: any) {
    console.error('Error in trigger-daily-report:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

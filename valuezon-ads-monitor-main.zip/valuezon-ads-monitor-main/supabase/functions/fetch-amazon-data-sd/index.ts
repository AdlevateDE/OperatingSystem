import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_API_BASE = 'https://advertising-api-eu.amazon.com';

// Delay helper for rate limiting
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Curated SD columns (20 metrics - validated against Amazon API)
const SD_COLUMNS = [
  "date",
  "campaignId",
  "campaignName",
  "campaignStatus",
  "campaignBudgetAmount",
  "campaignBudgetCurrencyCode",
  "costType",
  "impressions",
  "clicks",
  "cost",
  "purchasesClicks",
  "salesClicks",
  "unitsSoldClicks",
  "detailPageViewsClicks",
  "addToCartClicks",
  "newToBrandPurchasesClicks",
  "newToBrandSalesClicks",
  "newToBrandUnitsSoldClicks",
  "videoCompleteViews"
];

interface RequestBody {
  profileIds?: string[];
  startDate?: string;
  endDate?: string;
  triggerAlertCheck?: boolean;
}

async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const tokenKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenKey);
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');

  if (!refreshToken || !clientId || !clientSecret) {
    throw new Error(`Missing Amazon credentials. Token key: ${tokenKey}`);
  }

  const response = await fetch('https://api.amazon.com/auth/o2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`${response.status} - ${errorText}`);
  }

  const data = await response.json();
  return data.access_token;
}

async function createSDReport(
  accessToken: string,
  profileId: string,
  startDate: string,
  endDate: string
): Promise<{ reportId: string }> {
  const reportConfig = {
    name: `SD Campaign Report ${startDate} to ${endDate}`,
    startDate,
    endDate,
    configuration: {
      adProduct: "SPONSORED_DISPLAY",
      groupBy: ["campaign"],
      columns: SD_COLUMNS,
      reportTypeId: "sdCampaigns",
      timeUnit: "DAILY",
      format: "GZIP_JSON"
    }
  };

  console.log(`Creating SD report for profile ${profileId}:`, JSON.stringify(reportConfig));

  const response = await fetch(`${AMAZON_API_BASE}/reporting/reports`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Content-Type': 'application/vnd.createasyncreportrequest.v3+json',
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
    body: JSON.stringify(reportConfig),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error(`SD Report creation failed for profile ${profileId}: ${response.status} - ${errorText}`);
    throw new Error(`${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log(`SD Report created for profile ${profileId}: ${data.reportId}`);
  return { reportId: data.reportId };
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const body: RequestBody & { batch_id?: string } = await req.json();
    const { profileIds, startDate, endDate, triggerAlertCheck = true, batch_id } = body;

    if (!profileIds || profileIds.length === 0) {
      throw new Error('profileIds required');
    }

    // Calculate dates if not provided
    const yesterday = new Date();
    yesterday.setUTCDate(yesterday.getUTCDate() - 1);
    const reportStartDate = startDate || yesterday.toISOString().split('T')[0];
    const reportEndDate = endDate || yesterday.toISOString().split('T')[0];

    console.log(`Fetching SD data for ${profileIds.length} profiles from ${reportStartDate} to ${reportEndDate}`);
    console.log(`Batch ID: ${batch_id}`);

    // Get refresh token keys for each profile
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    if (accountsError) {
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    const profileTokenMap = new Map<string, string | null>();
    accounts?.forEach(acc => {
      profileTokenMap.set(acc.profile_id, acc.refresh_token_key);
    });

    const results: { profileId: string; reportId?: string; error?: string }[] = [];

    // Group profiles by refresh token key for efficiency
    const tokenGroups = new Map<string, string[]>();
    for (const profileId of profileIds) {
      const tokenKey = profileTokenMap.get(profileId) || 'AMAZON_REFRESH_TOKEN';
      if (!tokenGroups.has(tokenKey)) {
        tokenGroups.set(tokenKey, []);
      }
      tokenGroups.get(tokenKey)!.push(profileId);
    }

    // Process each token group
    for (const [tokenKey, groupProfileIds] of tokenGroups) {
      let accessToken: string;
      try {
        accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
      } catch (tokenError) {
        const errorMsg = tokenError instanceof Error ? tokenError.message : String(tokenError);
        console.error(`Token refresh failed for key ${tokenKey}:`, errorMsg);
        
        // Insert creation_failed for all profiles in this token group
        for (const profileId of groupProfileIds) {
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: reportStartDate,
            end_date: reportEndDate,
            status: 'creation_failed',
            error_message: `Token-Aktualisierung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sd',
            batch_id: batch_id || null,
          });
          results.push({ profileId, error: errorMsg });
        }
        continue;
      }

      let isFirstProfile = true;
      for (const profileId of groupProfileIds) {
        // Rate limiting: wait 3 seconds between API calls (skip first)
        if (!isFirstProfile) {
          console.log(`[RATE LIMIT] Waiting 3s before next SD request...`);
          await delay(3000);
        }
        isFirstProfile = false;

        try {
          const { reportId } = await createSDReport(accessToken, profileId, reportStartDate, reportEndDate);

          // Store in pending_reports with report_type = 'sd'
          const { error: insertError } = await supabase
            .from('pending_reports')
            .insert({
              profile_id: profileId,
              report_id: reportId,
              report_type: 'sd',
              start_date: reportStartDate,
              end_date: reportEndDate,
              status: 'pending',
              trigger_alert_check: triggerAlertCheck,
              batch_id: batch_id || null,
            });

          if (insertError) {
            console.error(`Failed to insert pending SD report for ${profileId}:`, insertError);
            results.push({ profileId, error: insertError.message });
          } else {
            results.push({ profileId, reportId });
          }
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error(`Error creating SD report for profile ${profileId}:`, errorMsg);
          
          // Insert with creation_failed status so it's visible in the UI
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: reportStartDate,
            end_date: reportEndDate,
            status: 'creation_failed',
            error_message: `Report-Erstellung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sd',
            batch_id: batch_id || null,
          });

          results.push({ profileId, error: errorMsg });
        }
      }
    }

    const successful = results.filter(r => r.reportId).length;
    const failed = results.filter(r => r.error).length;

    console.log(`SD fetch complete: ${successful} successful, ${failed} failed`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `SD reports created. ${successful} successful, ${failed} failed.`,
        results,
        startDate: reportStartDate,
        endDate: reportEndDate
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in fetch-amazon-data-sd:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

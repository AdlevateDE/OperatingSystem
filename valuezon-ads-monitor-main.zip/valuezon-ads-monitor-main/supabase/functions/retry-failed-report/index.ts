import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== retry-failed-report started ===');
    
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    const { report_id } = await req.json();

    if (!report_id) {
      throw new Error('report_id is required');
    }

    console.log(`Retrying report: ${report_id}`);

    // Get the failed report details
    const { data: report, error: fetchError } = await supabase
      .from('pending_reports')
      .select('*')
      .eq('id', report_id)
      .maybeSingle();

    if (fetchError) {
      throw new Error(`Failed to fetch report: ${fetchError.message}`);
    }

    if (!report) {
      throw new Error(`Report not found: ${report_id}`);
    }

    console.log(`Found report: profile=${report.profile_id}, type=${report.report_type}, status=${report.status}`);

    // Delete the old failed entry
    const { error: deleteError } = await supabase
      .from('pending_reports')
      .delete()
      .eq('id', report_id);

    if (deleteError) {
      console.error('Failed to delete old report entry:', deleteError);
      // Continue anyway - we'll create a new one
    }

    // Determine which fetch function to call based on report_type
    const fetchFunctionName = `fetch-amazon-data-${report.report_type || 'sp'}`;
    console.log(`Invoking ${fetchFunctionName} for profile ${report.profile_id}`);

    // Trigger the appropriate fetch function
    const { data: fetchResult, error: fetchFuncError } = await supabase.functions.invoke(fetchFunctionName, {
      body: {
        profileIds: [report.profile_id],
        startDate: report.start_date,
        endDate: report.end_date,
        triggerAlertCheck: report.trigger_alert_check || false,
      },
    });

    if (fetchFuncError) {
      console.error(`${fetchFunctionName} failed:`, fetchFuncError);
      throw new Error(`${fetchFunctionName} failed: ${fetchFuncError.message}`);
    }

    console.log(`${fetchFunctionName} result:`, JSON.stringify(fetchResult));

    console.log('=== retry-failed-report completed ===');

    return new Response(
      JSON.stringify({
        success: true,
        message: `Report retry triggered for ${report.profile_id} (${report.report_type})`,
        fetch_result: fetchResult,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    const errMsg = error instanceof Error ? error.message : String(error);
    console.error('Error in retry-failed-report:', errMsg);
    return new Response(
      JSON.stringify({ success: false, error: errMsg }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

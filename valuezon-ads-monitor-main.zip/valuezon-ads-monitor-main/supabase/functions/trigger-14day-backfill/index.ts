import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

// Delay helper to prevent rate limiting (429 errors)
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Starting nightly 14-day backfill...');

    // Get all unique profile_ids from active amazon_accounts
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id')
      .eq('is_active', true);

    if (accountsError) {
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    if (!accounts || accounts.length === 0) {
      console.log('No active accounts found');
      return new Response(
        JSON.stringify({ success: true, message: 'No active accounts to backfill' }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    const profileIds = [...new Set(accounts.map(a => a.profile_id))];
    console.log(`Found ${profileIds.length} unique profile_ids for backfill:`, profileIds);

    // Calculate date range: yesterday and 13 days before = 14 days total
    const yesterday = new Date();
    yesterday.setUTCDate(yesterday.getUTCDate() - 1);
    const endDate = yesterday.toISOString().split('T')[0];

    const startDate = new Date(yesterday);
    startDate.setUTCDate(startDate.getUTCDate() - 13);
    const startDateStr = startDate.toISOString().split('T')[0];

    console.log(`14-day backfill date range: ${startDateStr} to ${endDate}`);

    // Call fetch-amazon-data-sp with the 14-day range
    const fetchResponseSP = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sp`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        profileIds: profileIds,
        startDate: startDateStr,
        endDate: endDate,
        triggerAlertCheck: false, // No alert checks for historical backfill
      }),
    });

    if (!fetchResponseSP.ok) {
      const errorText = await fetchResponseSP.text();
      console.error(`fetch-amazon-data-sp failed: ${fetchResponseSP.status} - ${errorText}`);
    }

    const fetchResultSP = await fetchResponseSP.json().catch(() => ({}));
    console.log('fetch-amazon-data-sp response:', fetchResultSP);

    // Wait 10 seconds before calling SB to prevent rate limiting
    console.log('[RATE LIMIT] Waiting 10s before SB fetch to prevent 429 errors...');
    await delay(10000);

    // Call fetch-amazon-data-sb with the 14-day range
    const fetchResponseSB = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sb`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        profileIds: profileIds,
        startDate: startDateStr,
        endDate: endDate,
        triggerAlertCheck: false,
      }),
    });

    if (!fetchResponseSB.ok) {
      const errorText = await fetchResponseSB.text();
      console.error(`fetch-amazon-data-sb failed: ${fetchResponseSB.status} - ${errorText}`);
    }

    const fetchResultSB = await fetchResponseSB.json().catch(() => ({}));
    console.log('fetch-amazon-data-sb response:', fetchResultSB);

    // Wait 10 seconds before calling SD to prevent rate limiting
    console.log('[RATE LIMIT] Waiting 10s before SD fetch to prevent 429 errors...');
    await delay(10000);

    // Call fetch-amazon-data-sd with the 14-day range
    const fetchResponseSD = await fetch(`${supabaseUrl}/functions/v1/fetch-amazon-data-sd`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
        'Authorization': `Bearer ${supabaseKey}`,
      },
      body: JSON.stringify({
        profileIds: profileIds,
        startDate: startDateStr,
        endDate: endDate,
        triggerAlertCheck: false,
      }),
    });

    if (!fetchResponseSD.ok) {
      const errorText = await fetchResponseSD.text();
      console.error(`fetch-amazon-data-sd failed: ${fetchResponseSD.status} - ${errorText}`);
    }

    const fetchResultSD = await fetchResponseSD.json().catch(() => ({}));
    console.log('fetch-amazon-data-sd response:', fetchResultSD);

    return new Response(
      JSON.stringify({ 
        success: true, 
        profile_ids: profileIds,
        start_date: startDateStr,
        end_date: endDate,
        days: 14,
        message: '14-day backfill started for SP, SB, and SD. Reports will be processed automatically.',
        fetch_result_sp: fetchResultSP,
        fetch_result_sb: fetchResultSB,
        fetch_result_sd: fetchResultSD
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in trigger-14day-backfill:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

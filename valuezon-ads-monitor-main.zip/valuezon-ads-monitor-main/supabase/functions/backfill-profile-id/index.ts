import { createClient } from 'https://esm.sh/@supabase/supabase-js@2.81.1'

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
}

Deno.serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders })
  }

  try {
    const supabaseAdmin = createClient(
      Deno.env.get('SUPABASE_URL') ?? '',
      Deno.env.get('SUPABASE_SERVICE_ROLE_KEY') ?? '',
      {
        auth: {
          autoRefreshToken: false,
          persistSession: false
        }
      }
    )

    const { profile_id } = await req.json()
    
    if (!profile_id) {
      throw new Error('profile_id is required')
    }

    console.log(`Starting backfill for profile_id: ${profile_id}`)

    // First, get all campaign_ids and their names from recent data
    const { data: recentCampaigns, error: recentError } = await supabaseAdmin
      .from('campaign_metrics_sp')
      .select('campaign_id, campaign_name')
      .eq('profile_id', profile_id)
      .gte('date', '2025-11-15')
      .not('campaign_name', 'is', null)
      .limit(1000)

    if (recentError) {
      throw new Error(`Failed to fetch recent campaigns: ${recentError.message}`)
    }

    // Create a map of campaign_id -> campaign_name
    const campaignMap = new Map<number, string>()
    recentCampaigns?.forEach(c => {
      if (c.campaign_id && c.campaign_name) {
        campaignMap.set(c.campaign_id, c.campaign_name)
      }
    })
    
    const campaignIds = Array.from(campaignMap.keys())
    console.log(`Found ${campaignIds.length} campaign_ids to backfill`)
    console.log(`Campaign mappings:`, Array.from(campaignMap.entries()).map(([id, name]) => `${id}: ${name}`))

    if (campaignIds.length === 0) {
      return new Response(
        JSON.stringify({ 
          success: true, 
          message: 'No campaigns found to backfill',
          updated: 0 
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      )
    }

    // Check how many rows need updating
    const { count: nullCount, error: countError } = await supabaseAdmin
      .from('campaign_metrics_sp')
      .select('*', { count: 'exact', head: true })
      .is('profile_id', null)
      .in('campaign_id', campaignIds)
      .lt('date', '2025-11-15')

    console.log(`Found ${nullCount} rows with NULL profile_id to update`)

    // Update rows for each campaign individually to include campaign_name
    let totalUpdated = 0
    const errors = []
    
    for (const [campaignId, campaignName] of campaignMap.entries()) {
      const { error: updateError } = await supabaseAdmin
        .from('campaign_metrics_sp')
        .update({ 
          profile_id,
          campaign_name: campaignName 
        })
        .is('profile_id', null)
        .eq('campaign_id', campaignId)
        .lt('date', '2025-11-15')

      if (updateError) {
        errors.push(`Campaign ${campaignId}: ${updateError.message}`)
        console.error(`Failed to update campaign ${campaignId}:`, updateError)
      } else {
        totalUpdated++
        console.log(`Updated campaign ${campaignId} (${campaignName})`)
      }
    }

    if (errors.length > 0) {
      console.warn(`Completed with ${errors.length} errors:`, errors)
    }

    console.log(`Successfully updated ${totalUpdated} campaigns with profile_id and campaign_name`)

    return new Response(
      JSON.stringify({ 
        success: true, 
        message: `Successfully backfilled ${totalUpdated} campaigns with profile_id and campaign_name`,
        profile_id,
        campaigns_updated: totalUpdated,
        campaigns_found: campaignIds.length,
        rows_affected: nullCount,
        errors: errors.length > 0 ? errors : undefined
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    )

  } catch (error) {
    console.error('Error in backfill-profile-id:', error)
    const errorMessage = error instanceof Error ? error.message : 'Unknown error'
    return new Response(
      JSON.stringify({ 
        success: false, 
        error: errorMessage 
      }),
      { 
        status: 500,
        headers: { ...corsHeaders, 'Content-Type': 'application/json' } 
      }
    )
  }
})

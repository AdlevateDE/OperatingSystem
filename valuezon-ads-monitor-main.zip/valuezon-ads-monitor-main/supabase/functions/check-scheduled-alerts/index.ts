import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  // Handle CORS preflight requests
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  const startTime = Date.now();
  let supabase: any = null;
  let runId: string | null = null;
  let triggerSource = 'unknown';

  // Initialize Supabase client FIRST for logging
  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    supabase = createClient(supabaseUrl, supabaseKey);
  } catch (initError: any) {
    console.error('[CRITICAL] Failed to initialize Supabase client:', initError.message);
    return new Response(
      JSON.stringify({ error: 'Failed to initialize database connection' }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' }, status: 500 }
    );
  }

  // Determine trigger source from request body
  try {
    const body = await req.json().catch(() => ({}));
    triggerSource = body?.schedule || body?.trigger || 'manual';
  } catch {
    triggerSource = 'manual';
  }

  // Create run log entry IMMEDIATELY
  try {
    const { data: runData } = await supabase
      .from('function_runs')
      .insert({
        function_name: 'check-scheduled-alerts',
        status: 'running',
        trigger_source: triggerSource,
        metadata: { started_at_iso: new Date().toISOString() },
      })
      .select('id')
      .single();
    
    runId = runData?.id;
    console.log(`=== CHECK-SCHEDULED-ALERTS STARTED (run_id: ${runId}) ===`);
  } catch (logError: any) {
    console.error('[WARN] Failed to create run log:', logError.message);
  }

  // Helper to update run status
  const updateRunStatus = async (status: string, errorMessage?: string, metadata?: object) => {
    if (!runId || !supabase) return;
    const duration = Date.now() - startTime;
    try {
      await supabase
        .from('function_runs')
        .update({
          status,
          finished_at: new Date().toISOString(),
          duration_ms: duration,
          error_message: errorMessage?.substring(0, 2000),
          metadata: { ...(metadata || {}), duration_ms: duration },
        })
        .eq('id', runId);
    } catch (e) {
      console.error('[WARN] Failed to update run log:', e);
    }
  };

  try {
    // Determine time of day based on UTC hour
    const now = new Date();
    const currentHour = now.getUTCHours();
    const timeOfDay = currentHour >= 14 ? 'evening' : 'morning';

    console.log(`[INFO] Time check: ${timeOfDay} at ${now.toISOString()} (UTC hour: ${currentHour})`);

    // Find all active rules with check_frequency = 'daily' and matching schedule
    const { data: rules, error } = await supabase
      .from('alert_rules')
      .select(`
        id,
        rule_name,
        check_frequency,
        check_schedule,
        account_id,
        account_ids
      `)
      .eq('is_active', true)
      .eq('check_frequency', 'daily')
      .or(`check_schedule.eq.${timeOfDay},check_schedule.eq.both`);

    if (error) {
      console.error('[ERROR] Failed to fetch alert rules:', error);
      await updateRunStatus('failed', `Failed to fetch rules: ${error.message}`, { step: 'fetch_rules' });
      throw error;
    }

    if (!rules || rules.length === 0) {
      console.log(`[INFO] No active daily rules found for ${timeOfDay} check`);
      await updateRunStatus('success', undefined, { result: 'no_rules', time_of_day: timeOfDay });
      return new Response(
        JSON.stringify({ 
          message: 'No rules to trigger',
          time_of_day: timeOfDay,
          triggered_at: now.toISOString(),
          run_id: runId,
        }),
        {
          headers: { ...corsHeaders, 'Content-Type': 'application/json' },
          status: 200,
        }
      );
    }

    console.log(`[INFO] Found ${rules.length} active daily rules:`);
    rules.forEach((r: any) => console.log(`  - Rule: "${r.rule_name}" (ID: ${r.id})`));

    // Get all account_ids from rules
    const allAccountIds = new Set<string>();
    for (const rule of rules) {
      const accountIds: string[] = (rule as any).account_ids || [(rule as any).account_id];
      accountIds.forEach(id => allAccountIds.add(id));
    }
    console.log(`[INFO] Total unique accounts: ${allAccountIds.size}`);

    // Get all account_users relationships
    const { data: accountUsers, error: accountUsersError } = await supabase
      .from('account_users')
      .select('account_id, user_id')
      .in('account_id', Array.from(allAccountIds));

    if (accountUsersError) {
      console.error('[ERROR] Failed to fetch account_users:', accountUsersError);
      await updateRunStatus('failed', `Failed to fetch account_users: ${accountUsersError.message}`, { step: 'fetch_account_users' });
      throw accountUsersError;
    }

    // Get profile_ids for all accounts
    const { data: accountsData, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('id, profile_id, account_name')
      .in('id', Array.from(allAccountIds));

    if (accountsError) {
      console.error('[ERROR] Failed to fetch amazon_accounts:', accountsError);
      await updateRunStatus('failed', `Failed to fetch accounts: ${accountsError.message}`, { step: 'fetch_accounts' });
      throw accountsError;
    }

    const accountToProfile = new Map<string, string>();
    const accountToName = new Map<string, string>();
    accountsData?.forEach((a: any) => {
      accountToProfile.set(a.id, a.profile_id);
      accountToName.set(a.id, a.account_name);
    });

    console.log(`[INFO] Account mappings:`);
    accountsData?.forEach((a: any) => console.log(`  - ${a.account_name}: profile_id=${a.profile_id}`));

    // Group profile_ids by user
    const userProfileMap = new Map<string, Set<string>>();
    
    for (const rule of rules) {
      const accountIds: string[] = (rule as any).account_ids || [(rule as any).account_id];
      
      for (const accountId of accountIds) {
        const profileId = accountToProfile.get(accountId);
        if (!profileId) {
          console.warn(`[WARN] No profile_id found for account ${accountId}`);
          continue;
        }
        
        const usersForAccount = accountUsers?.filter((au: any) => au.account_id === accountId) || [];
        
        for (const accountUser of usersForAccount) {
          const userId = accountUser.user_id;
          if (!userProfileMap.has(userId)) {
            userProfileMap.set(userId, new Set());
          }
          userProfileMap.get(userId)!.add(profileId);
        }
      }
    }

    console.log(`[INFO] Processing for ${userProfileMap.size} users`);

    // Collect all unique profile IDs
    const allProfileIds = new Set<string>();
    for (const profileIdsSet of userProfileMap.values()) {
      profileIdsSet.forEach(id => allProfileIds.add(id));
    }
    const profileIdsArray = Array.from(allProfileIds);

    console.log(`[INFO] Total unique profile IDs: ${profileIdsArray.length}`);
    console.log(`[INFO] Profile IDs: ${profileIdsArray.join(', ')}`);

    // Check if today's data is available
    const today = new Date().toISOString().split('T')[0];
    console.log(`[CHECK] Verifying data availability for ${today}...`);
    
    const [spDataCheck, sbDataCheck, sdDataCheck] = await Promise.all([
      supabase.from('campaign_metrics_sp').select('id', { count: 'exact', head: true }).in('profile_id', profileIdsArray).eq('date', today),
      supabase.from('campaign_metrics_sb').select('id', { count: 'exact', head: true }).in('profile_id', profileIdsArray).eq('date', today),
      supabase.from('campaign_metrics_sd').select('id', { count: 'exact', head: true }).in('profile_id', profileIdsArray).eq('date', today),
    ]);

    const spCount = spDataCheck.error ? 0 : (spDataCheck as any)?.count || 0;
    const sbCount = sbDataCheck.error ? 0 : (sbDataCheck as any)?.count || 0;
    const sdCount = sdDataCheck.error ? 0 : (sdDataCheck as any)?.count || 0;

    console.log(`[CHECK] Data available for ${today}: SP=${spCount}, SB=${sbCount}, SD=${sdCount} rows`);

    if (spCount === 0 && sbCount === 0 && sdCount === 0) {
      console.warn('[WARN] NO DATA available for today! Data may not have been synced yet.');
    }

    // Find owner for Slack webhook access
    const { data: ownerData } = await supabase
      .from('account_users')
      .select('user_id')
      .in('account_id', Array.from(allAccountIds))
      .eq('role', 'owner')
      .limit(1)
      .single();

    const userIds = Array.from(userProfileMap.keys());
    const ownerId = ownerData?.user_id || userIds[0];

    console.log(`[INFO] Using owner user ${ownerId} for consolidated alert check`);
    
    // Update run metadata before invoking run-alert-checks
    await updateRunStatus('running', undefined, {
      step: 'invoking_run_alert_checks',
      rules_count: rules.length,
      profiles_count: profileIdsArray.length,
      owner_id: ownerId,
    });

    // Run alert checks with timeout protection
    console.log('[ALERT] Starting alert check with all profiles...');
    
    let alertResponse: any = null;
    let alertError: string | null = null;
    
    try {
      // Create AbortController for timeout (25 seconds to leave buffer)
      const controller = new AbortController();
      const timeoutId = setTimeout(() => controller.abort(), 25000);
      
      const response = await supabase.functions.invoke('run-alert-checks', {
        body: {
          user_id: ownerId,
          profile_ids: profileIdsArray,
          run_type: 'scheduled',
        },
      });
      
      clearTimeout(timeoutId);
      alertResponse = response;
      
      if (response.error) {
        alertError = response.error.message || JSON.stringify(response.error);
        console.error('[ALERT] ERROR:', alertError);
      } else {
        console.log('[ALERT] SUCCESS:', JSON.stringify(response.data));
      }
    } catch (invokeError: any) {
      alertError = invokeError?.message || String(invokeError);
      console.error('[ALERT] INVOKE EXCEPTION:', alertError);
      
      // If run-alert-checks completely fails, try to send error notification
      try {
        await supabase.functions.invoke('send-slack-alert', {
          body: {
            is_system_error: true,
            error_message: `run-alert-checks failed: ${alertError}`,
            user_id: ownerId,
            run_type: 'scheduled',
          },
        });
        console.log('[ALERT] Error notification sent to Slack');
      } catch (slackError) {
        console.error('[ALERT] Failed to send error notification:', slackError);
      }
    }

    const alertResults = [];
    if (alertError) {
      alertResults.push({ userId: ownerId, success: false, error: alertError });
    } else {
      alertResults.push({ userId: ownerId, success: true, data: alertResponse?.data });
    }

    const duration = Date.now() - startTime;
    console.log(`=== CHECK-SCHEDULED-ALERTS COMPLETED in ${duration}ms ===`);

    // Update run status to success
    await updateRunStatus('success', undefined, {
      time_of_day: timeOfDay,
      rules_count: rules.length,
      profiles_count: profileIdsArray.length,
      data_available: { sp: spCount, sb: sbCount, sd: sdCount },
      alert_success: !alertError,
    });

    return new Response(
      JSON.stringify({ 
        success: true,
        time_of_day: timeOfDay,
        triggered_at: now.toISOString(),
        duration_ms: duration,
        rules_count: rules.length,
        users_count: userProfileMap.size,
        profile_ids: profileIdsArray,
        data_available: { sp: spCount, sb: sbCount, sd: sdCount },
        alert_results: alertResults,
        run_id: runId,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 200,
      }
    );
  } catch (error: any) {
    const duration = Date.now() - startTime;
    console.error(`=== CHECK-SCHEDULED-ALERTS FAILED after ${duration}ms ===`);
    console.error('[ERROR] Unhandled exception:', error.message);
    console.error('[ERROR] Stack:', error.stack);
    
    // Update run status to failed
    await updateRunStatus('failed', error.message, { stack: error.stack?.substring(0, 1000) });
    
    // Try to send error notification to Slack
    if (supabase) {
      try {
        await supabase.functions.invoke('send-slack-alert', {
          body: {
            is_system_error: true,
            error_message: `check-scheduled-alerts crashed: ${error.message}`,
            run_type: 'scheduled',
          },
        });
      } catch (slackError) {
        console.error('[ERROR] Failed to send crash notification:', slackError);
      }
    }
    
    return new Response(
      JSON.stringify({ 
        error: error.message,
        duration_ms: duration,
        run_id: runId,
      }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

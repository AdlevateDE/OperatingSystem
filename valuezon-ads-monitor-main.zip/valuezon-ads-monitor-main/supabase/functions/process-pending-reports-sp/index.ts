import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";
import { gunzip } from "https://deno.land/x/compress@v0.4.5/gzip/mod.ts";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_API_BASE = 'https://advertising-api-eu.amazon.com';
const AMAZON_TOKEN_URL = 'https://api.amazon.com/auth/o2/token';
const MAX_ATTEMPTS = 100; // Max polling attempts before marking as failed

interface ReportMetric {
  date: string;
  campaignName: string;
  campaignId: string;
  campaignStatus: string;
  campaignBudgetAmount: number;
  campaignBudgetType: string;
  campaignBudgetCurrencyCode: string;
  topOfSearchImpressionShare: number;
  impressions: number;
  clicks: number;
  clickThroughRate: number;
  cost: number;
  costPerClick: number;
  purchases14d: number;
  sales14d: number;
  unitsSoldClicks14d: number;
  acosClicks14d: number;
  roasClicks14d: number;
}

// Refresh OAuth token - now accepts dynamic refresh token key
async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');
  
  // Use custom refresh token key if provided, otherwise default
  const tokenEnvKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenEnvKey);

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error(`Missing Amazon API credentials (token key: ${tokenEnvKey})`);
  }

  console.log(`Refreshing Amazon access token using ${tokenEnvKey}...`);

  const response = await fetch(AMAZON_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Token refresh failed:', errorText);
    throw new Error(`Token refresh failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('Access token refreshed successfully');
  return data.access_token;
}

// Check report status at Amazon
async function checkReportStatus(accessToken: string, profileId: string, reportId: string): Promise<{ status: string; url?: string; error?: string }> {
  const response = await fetch(`${AMAZON_API_BASE}/reporting/reports/${reportId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Check report status failed:', errorText);
    throw new Error(`Check report status failed: ${response.status}`);
  }

  const data = await response.json();
  return {
    status: data.status,
    url: data.url,
    error: data.statusDetails,
  };
}

// Download and decompress report
async function downloadReport(downloadUrl: string): Promise<ReportMetric[]> {
  console.log('Downloading report...');

  const response = await fetch(downloadUrl);
  if (!response.ok) {
    throw new Error(`Download failed: ${response.status}`);
  }

  const compressedData = new Uint8Array(await response.arrayBuffer());
  console.log(`Downloaded ${compressedData.length} bytes`);

  const decompressedData = gunzip(compressedData);
  const jsonString = new TextDecoder().decode(decompressedData);
  
  const reportData = JSON.parse(jsonString);
  console.log(`Parsed ${reportData.length} campaign records`);
  
  return reportData;
}

// Save metrics to database
async function saveMetrics(supabase: any, profileId: string, metrics: ReportMetric[]): Promise<number> {
  console.log(`Saving ${metrics.length} metrics for profile ${profileId}...`);

  let savedCount = 0;
  const batchSize = 100;

  for (let i = 0; i < metrics.length; i += batchSize) {
    const batch = metrics.slice(i, i + batchSize);
    
    const records = batch.map(metric => {
      // CRITICAL: Use campaignId as string to generate unique_key consistently
      // JavaScript loses precision with numbers > 2^53-1 (9007199254740991)
      // Amazon campaign IDs can exceed this limit
      const campaignIdStr = String(metric.campaignId);
      return {
        profile_id: profileId,
        date: metric.date,
        campaign_id: campaignIdStr, // PostgreSQL bigint can handle the string conversion
        campaign_name: metric.campaignName,
        campaign_status: metric.campaignStatus,
        campaign_budget_amount: metric.campaignBudgetAmount,
        campaign_budget_type: metric.campaignBudgetType,
        campaign_budget_currency_code: metric.campaignBudgetCurrencyCode,
        top_of_search_impression_share: metric.topOfSearchImpressionShare,
        impressions: metric.impressions,
        clicks: metric.clicks,
        click_through_rate: metric.clickThroughRate,
        cost: metric.cost,
        cost_per_click: metric.costPerClick,
        purchases_14d: metric.purchases14d,
        sales_14d: metric.sales14d,
        units_sold_clicks_14d: metric.unitsSoldClicks14d,
        acos_clicks_14d: metric.acosClicks14d,
        roas_clicks_14d: metric.roasClicks14d,
        unique_key: `${profileId}_${campaignIdStr}_${metric.date}`,
      };
    });

    const { error } = await supabase
      .from('campaign_metrics_sp')
      .upsert(records, { 
        onConflict: 'unique_key',
        ignoreDuplicates: false 
      });

    if (error) {
      console.error(`Error saving batch ${i / batchSize + 1}:`, error);
      throw error;
    }

    savedCount += records.length;
    console.log(`Saved batch ${i / batchSize + 1}, total: ${savedCount}`);
  }

  return savedCount;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    console.log('=== process-pending-reports-sp started ===');

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Fetch all pending SP reports (report_type is null or 'sp')
    const { data: pendingReports, error: fetchError } = await supabase
      .from('pending_reports')
      .select('*')
      .eq('status', 'pending')
      .or('report_type.is.null,report_type.eq.sp')
      .order('created_at', { ascending: true });

    if (fetchError) {
      throw fetchError;
    }

    if (!pendingReports || pendingReports.length === 0) {
      console.log('No pending SP reports to process');
      return new Response(
        JSON.stringify({ success: true, message: 'No pending SP reports', processed: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${pendingReports.length} pending SP reports to process`);

    // Get all unique profile_ids and their refresh_token_keys
    const profileIds = [...new Set(pendingReports.map(r => r.profile_id))];
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    if (accountsError) {
      console.error('Error fetching accounts:', accountsError);
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    // Create a map of profile_id -> refresh_token_key
    const tokenKeyMap = new Map<string, string | null>();
    for (const account of accounts || []) {
      tokenKeyMap.set(account.profile_id, account.refresh_token_key);
    }

    console.log('Token key mapping:', Object.fromEntries(tokenKeyMap));

    // Cache access tokens by refresh_token_key
    const accessTokenCache = new Map<string, string>();

    const results: { reportId: string; status: string; recordsCount?: number; error?: string }[] = [];

    for (const report of pendingReports) {
      try {
        console.log(`\n--- Processing report: ${report.report_id} (attempt ${report.attempts + 1}) ---`);

        // Get the appropriate access token
        const tokenKey = tokenKeyMap.get(report.profile_id) || 'AMAZON_REFRESH_TOKEN';
        let accessToken = accessTokenCache.get(tokenKey);
        
        if (!accessToken) {
          accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
          accessTokenCache.set(tokenKey, accessToken);
        }

        // Check report status
        const statusResult = await checkReportStatus(accessToken, report.profile_id, report.report_id);
        console.log(`Report status: ${statusResult.status}`);

        if (statusResult.status === 'COMPLETED') {
          // Download and save data
          const metrics = await downloadReport(statusResult.url!);
          const savedCount = await saveMetrics(supabase, report.profile_id, metrics);

          // Update amazon_accounts last_sync_at
          await supabase
            .from('amazon_accounts')
            .update({ last_sync_at: new Date().toISOString() })
            .eq('profile_id', report.profile_id);

          // Mark report as completed
          await supabase
            .from('pending_reports')
            .update({
              status: 'completed',
              completed_at: new Date().toISOString(),
              download_url: statusResult.url,
              attempts: report.attempts + 1,
              last_attempt_at: new Date().toISOString(),
            })
            .eq('id', report.id);

          // Trigger alert checks if requested - but only if ALL reports in batch are done
          if (report.trigger_alert_check) {
            let shouldTriggerAlert = true;
            
            // If this report has a batch_id, check if all reports in the batch are completed
            if (report.batch_id) {
              const { data: batchReports, error: batchError } = await supabase
                .from('pending_reports')
                .select('id, status, report_type')
                .eq('batch_id', report.batch_id);
              
              if (!batchError && batchReports) {
                const stillPending = batchReports.filter(r => r.status === 'pending');
                if (stillPending.length > 0) {
                  shouldTriggerAlert = false;
                  console.log(`⏳ Waiting for ${stillPending.length} more reports in batch ${report.batch_id}: ${stillPending.map(r => r.report_type).join(', ')}`);
                } else {
                  console.log(`✅ All ${batchReports.length} reports in batch ${report.batch_id} completed - triggering alert checks`);
                }
              }
            }
            
            if (shouldTriggerAlert) {
              console.log('Triggering alert checks for all profiles in batch...');
              
              // Collect ALL unique profile_ids from the batch
              const { data: batchProfileData } = await supabase
                .from('pending_reports')
                .select('profile_id')
                .eq('batch_id', report.batch_id);
              
              const allProfileIds = [...new Set((batchProfileData || []).map(r => r.profile_id))];
              console.log(`Found ${allProfileIds.length} unique profiles in batch: ${allProfileIds.join(', ')}`);
              
              // Get user_id from amazon_accounts via account_users (using first profile)
              const { data: accountUser } = await supabase
                .from('amazon_accounts')
                .select('id, account_users!inner(user_id)')
                .eq('profile_id', report.profile_id)
                .limit(1)
                .single();
              
              if (accountUser?.account_users?.[0]?.user_id) {
                const userId = accountUser.account_users[0].user_id;
                console.log(`Triggering run-alert-checks for user ${userId}, profiles: ${allProfileIds.join(', ')}`);
                
                await supabase.functions.invoke('run-alert-checks', {
                  body: { 
                    user_id: userId,
                    profile_ids: allProfileIds,  // ALL profile IDs in batch
                    run_type: 'scheduled'
                  },
                });
              } else {
                console.log(`No user found for profile ${report.profile_id}, skipping alert check`);
              }
            }
          }

          results.push({
            reportId: report.report_id,
            status: 'completed',
            recordsCount: savedCount,
          });

          console.log(`Report completed: ${savedCount} records saved`);

        } else if (statusResult.status === 'FAILED') {
          // Mark as failed
          await supabase
            .from('pending_reports')
            .update({
              status: 'failed',
              error_message: statusResult.error || 'Unknown error',
              attempts: report.attempts + 1,
              last_attempt_at: new Date().toISOString(),
            })
            .eq('id', report.id);

          results.push({
            reportId: report.report_id,
            status: 'failed',
            error: statusResult.error,
          });

          console.log(`Report failed: ${statusResult.error}`);

        } else {
          // Still pending - update attempt count
          const newAttempts = report.attempts + 1;
          
          if (newAttempts >= MAX_ATTEMPTS) {
            // Max attempts reached - mark as failed
            await supabase
              .from('pending_reports')
              .update({
                status: 'failed',
                error_message: `Timed out after ${MAX_ATTEMPTS} attempts`,
                attempts: newAttempts,
                last_attempt_at: new Date().toISOString(),
              })
              .eq('id', report.id);

            results.push({
              reportId: report.report_id,
              status: 'timeout',
              error: `Timed out after ${MAX_ATTEMPTS} attempts`,
            });
          } else {
            // Update attempt count
            await supabase
              .from('pending_reports')
              .update({
                attempts: newAttempts,
                last_attempt_at: new Date().toISOString(),
              })
              .eq('id', report.id);

            results.push({
              reportId: report.report_id,
              status: 'pending',
            });

            console.log(`Report still pending (attempt ${newAttempts}/${MAX_ATTEMPTS})`);
          }
        }

      } catch (error) {
        console.error(`Error processing report ${report.report_id}:`, error);
        
        // Update with error
        await supabase
          .from('pending_reports')
          .update({
            attempts: report.attempts + 1,
            last_attempt_at: new Date().toISOString(),
            error_message: error instanceof Error ? error.message : String(error),
          })
          .eq('id', report.id);

        results.push({
          reportId: report.report_id,
          status: 'error',
          error: error instanceof Error ? error.message : String(error),
        });
      }
    }

    console.log('=== process-pending-reports-sp completed ===');
    console.log('Results:', JSON.stringify(results, null, 2));

    const summary = {
      total: results.length,
      completed: results.filter(r => r.status === 'completed').length,
      pending: results.filter(r => r.status === 'pending').length,
      failed: results.filter(r => r.status === 'failed' || r.status === 'error' || r.status === 'timeout').length,
    };

    return new Response(
      JSON.stringify({ success: true, results, summary }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Fatal error in process-pending-reports-sp:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : String(error) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

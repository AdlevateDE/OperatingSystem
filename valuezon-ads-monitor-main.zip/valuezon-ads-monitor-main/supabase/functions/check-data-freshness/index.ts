import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

interface AccountFreshness {
  profile_id: string;
  account_name: string;
  campaign_type: 'sp' | 'sb' | 'sd';
  is_fresh: boolean;
  last_sync_minutes_ago: number;
  last_sync_at: string;
  latest_data_date: string;
}

interface FreshnessResponse {
  is_fresh: boolean;
  details_by_account: AccountFreshness[];
  stale_items: AccountFreshness[];
  // Legacy fields for backward compatibility
  last_sync_minutes_ago?: number;
  last_sync_at?: string;
}

const FRESHNESS_THRESHOLD_MINUTES = 60;

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const authHeader = req.headers.get('Authorization')!;
    const token = authHeader.replace('Bearer ', '');
    const { data: { user }, error: authError } = await supabase.auth.getUser(token);

    if (authError || !user) {
      throw new Error('Unauthorized');
    }

    const { profile_ids, campaign_types = ['sp'] } = await req.json();

    if (!profile_ids || profile_ids.length === 0) {
      return new Response(
        JSON.stringify({ 
          is_fresh: false,
          details_by_account: [],
          stale_items: [],
          reason: 'no_profile_ids'
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log('Checking data freshness for profile_ids:', profile_ids, 'campaign_types:', campaign_types);

    // Get account names for profile_ids
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, account_name')
      .in('profile_id', profile_ids);

    if (accountsError) {
      console.error('Error fetching accounts:', accountsError);
      throw accountsError;
    }

    const accountNameMap: Record<string, string> = {};
    accounts?.forEach(acc => {
      accountNameMap[acc.profile_id] = acc.account_name;
    });

    const now = new Date();
    const details_by_account: AccountFreshness[] = [];

    // Check each profile_id and campaign_type combination
    for (const profile_id of profile_ids) {
      for (const campaign_type of campaign_types) {
        const tableName = `campaign_metrics_${campaign_type}`;
        
        // Get the LATEST data for this profile, no date filter
        const { data: metrics, error: metricsError } = await supabase
          .from(tableName)
          .select('profile_id, date, updated_at')
          .eq('profile_id', profile_id)
          .order('date', { ascending: false })
          .order('updated_at', { ascending: false })
          .limit(1);

        if (metricsError) {
          console.error(`Error checking ${campaign_type} freshness for ${profile_id}:`, metricsError);
          // Skip this combination but continue with others
          continue;
        }

        if (!metrics || metrics.length === 0) {
          console.log(`No ${campaign_type} data found for profile ${profile_id}`);
          // No data at all for this combination - still add to results
          details_by_account.push({
            profile_id,
            account_name: accountNameMap[profile_id] || profile_id,
            campaign_type: campaign_type as 'sp' | 'sb' | 'sd',
            is_fresh: false,
            last_sync_minutes_ago: -1, // -1 indicates no data
            last_sync_at: '',
            latest_data_date: ''
          });
          continue;
        }

        const lastUpdate = new Date(metrics[0].updated_at);
        const minutesAgo = Math.floor((now.getTime() - lastUpdate.getTime()) / 1000 / 60);
        const isFresh = minutesAgo < FRESHNESS_THRESHOLD_MINUTES;
        const latestDate = metrics[0].date;

        details_by_account.push({
          profile_id,
          account_name: accountNameMap[profile_id] || profile_id,
          campaign_type: campaign_type as 'sp' | 'sb' | 'sd',
          is_fresh: isFresh,
          last_sync_minutes_ago: minutesAgo,
          last_sync_at: lastUpdate.toISOString(),
          latest_data_date: latestDate
        });

        console.log(`${campaign_type} for ${accountNameMap[profile_id] || profile_id}: ${minutesAgo} min ago, date: ${latestDate}, fresh: ${isFresh}`);
      }
    }

    // Filter stale items (not fresh or no data)
    const stale_items = details_by_account.filter(item => !item.is_fresh);
    
    // Overall freshness: all items must be fresh
    const is_fresh = details_by_account.length > 0 && stale_items.length === 0;

    // Legacy: find oldest sync for backward compatibility
    const validItems = details_by_account.filter(item => item.last_sync_minutes_ago >= 0);
    let oldestSyncMinutes: number | undefined;
    let oldestSyncAt: string | undefined;
    
    if (validItems.length > 0) {
      const oldest = validItems.reduce((prev, curr) => 
        curr.last_sync_minutes_ago > prev.last_sync_minutes_ago ? curr : prev
      );
      oldestSyncMinutes = oldest.last_sync_minutes_ago;
      oldestSyncAt = oldest.last_sync_at;
    }

    console.log('Freshness check result:', { 
      is_fresh, 
      total_items: details_by_account.length,
      stale_count: stale_items.length,
      stale_items: stale_items.map(s => `${s.account_name} ${s.campaign_type.toUpperCase()}`)
    });

    const response: FreshnessResponse = {
      is_fresh,
      details_by_account,
      stale_items,
      last_sync_minutes_ago: oldestSyncMinutes,
      last_sync_at: oldestSyncAt,
    };

    return new Response(
      JSON.stringify(response),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('Error in check-data-freshness:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

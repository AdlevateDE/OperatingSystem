import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_API_BASE = 'https://advertising-api-eu.amazon.com';
const MAX_ATTEMPTS = 10;

interface SDReportMetric {
  date: string;
  campaignId: number;
  campaignName: string;
  campaignStatus?: string;
  campaignBudgetAmount?: number;
  campaignBudgetCurrencyCode?: string;
  costType?: string;
  impressions?: number;
  clicks?: number;
  cost?: number;
  purchasesClicks?: number;
  salesClicks?: number;
  unitsSoldClicks?: number;
  detailPageViewsClicks?: number;
  addToCartClicks?: number;
  newToBrandPurchasesClicks?: number;
  newToBrandSalesClicks?: number;
  newToBrandUnitsSoldClicks?: number;
  videoCompleteViews?: number;
}

async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const tokenKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenKey);
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');

  if (!refreshToken || !clientId || !clientSecret) {
    throw new Error(`Missing Amazon credentials. Token key: ${tokenKey}`);
  }

  const response = await fetch('https://api.amazon.com/auth/o2/token', {
    method: 'POST',
    headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    throw new Error(`Token refresh failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  return data.access_token;
}

async function checkReportStatus(accessToken: string, profileId: string, reportId: string) {
  const response = await fetch(`${AMAZON_API_BASE}/reporting/reports/${reportId}`, {
    method: 'GET',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
  });

  if (!response.ok) {
    const errorText = await response.text();
    return { status: 'error', error: `${response.status} - ${errorText}` };
  }

  const data = await response.json();
  return {
    status: data.status,
    url: data.url,
  };
}

async function downloadReport(url: string): Promise<SDReportMetric[]> {
  const response = await fetch(url);
  if (!response.ok) {
    throw new Error(`Failed to download report: ${response.status}`);
  }

  const compressedData = await response.arrayBuffer();
  const decompressed = new TextDecoder().decode(
    new Uint8Array(await new Response(
      new Blob([compressedData]).stream().pipeThrough(new DecompressionStream('gzip'))
    ).arrayBuffer())
  );

  return JSON.parse(decompressed);
}

async function saveSDMetrics(supabase: any, profileId: string, metrics: SDReportMetric[]): Promise<number> {
  if (metrics.length === 0) return 0;

  const records = metrics.map(m => {
    // CRITICAL: Use campaignId as string to generate unique_key consistently
    // JavaScript loses precision with numbers > 2^53-1 (9007199254740991)
    const campaignIdStr = String(m.campaignId);
    return {
      profile_id: profileId,
      date: m.date,
      campaign_id: campaignIdStr, // PostgreSQL bigint can handle the string conversion
      campaign_name: m.campaignName,
      campaign_status: m.campaignStatus || null,
      campaign_budget_amount: m.campaignBudgetAmount || null,
      campaign_budget_currency_code: m.campaignBudgetCurrencyCode || null,
      cost_type: m.costType || null,
      impressions: m.impressions || null,
      clicks: m.clicks || null,
      cost: m.cost || null,
      purchases_clicks: m.purchasesClicks || null,
      sales_clicks: m.salesClicks || null,
      units_sold_clicks: m.unitsSoldClicks || null,
      detail_page_views_clicks: m.detailPageViewsClicks || null,
      add_to_cart_clicks: m.addToCartClicks || null,
      new_to_brand_purchases_clicks: m.newToBrandPurchasesClicks || null,
      new_to_brand_sales_clicks: m.newToBrandSalesClicks || null,
      new_to_brand_units_sold_clicks: m.newToBrandUnitsSoldClicks || null,
      video_complete_views: m.videoCompleteViews || null,
      unique_key: `${profileId}_${campaignIdStr}_${m.date}`,
      updated_at: new Date().toISOString(),
    };
  });

  // Batch upsert in chunks of 500
  const batchSize = 500;
  let savedCount = 0;

  for (let i = 0; i < records.length; i += batchSize) {
    const batch = records.slice(i, i + batchSize);
    const { error } = await supabase
      .from('campaign_metrics_sd')
      .upsert(batch, { onConflict: 'unique_key' });

    if (error) {
      console.error(`Error upserting SD metrics batch:`, error);
      throw error;
    }
    savedCount += batch.length;
  }

  return savedCount;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    console.log('Processing pending SD reports...');

    // Fetch pending SD reports
    const { data: pendingReports, error: fetchError } = await supabase
      .from('pending_reports')
      .select('*')
      .eq('status', 'pending')
      .eq('report_type', 'sd')
      .order('created_at', { ascending: true })
      .limit(20);

    if (fetchError) {
      throw new Error(`Failed to fetch pending SD reports: ${fetchError.message}`);
    }

    if (!pendingReports || pendingReports.length === 0) {
      console.log('No pending SD reports to process');
      return new Response(
        JSON.stringify({ success: true, message: 'No pending SD reports', processed: 0 }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    console.log(`Found ${pendingReports.length} pending SD reports`);

    // Get refresh token keys for profiles
    const profileIds = [...new Set(pendingReports.map(r => r.profile_id))];
    const { data: accounts } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    const profileTokenMap = new Map<string, string | null>();
    accounts?.forEach(acc => {
      profileTokenMap.set(acc.profile_id, acc.refresh_token_key);
    });

    const results: { reportId: string; status: string; metrics?: number; error?: string }[] = [];

    // Group by token key
    const tokenGroups = new Map<string, typeof pendingReports>();
    for (const report of pendingReports) {
      const tokenKey = profileTokenMap.get(report.profile_id) || 'AMAZON_REFRESH_TOKEN';
      if (!tokenGroups.has(tokenKey)) {
        tokenGroups.set(tokenKey, []);
      }
      tokenGroups.get(tokenKey)!.push(report);
    }

    for (const [tokenKey, reports] of tokenGroups) {
      let accessToken: string;
      try {
        accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
      } catch (error) {
        const errorMessage = error instanceof Error ? error.message : 'Unknown error';
        console.error(`Token refresh failed for ${tokenKey}:`, errorMessage);
        for (const report of reports) {
          results.push({ reportId: report.report_id, status: 'token_error', error: errorMessage });
        }
        continue;
      }

      for (const report of reports) {
        try {
          const statusResult = await checkReportStatus(accessToken, report.profile_id, report.report_id);

          if (statusResult.status === 'COMPLETED' && statusResult.url) {
            console.log(`SD Report ${report.report_id} completed, downloading...`);

            const metrics = await downloadReport(statusResult.url);
            const savedCount = await saveSDMetrics(supabase, report.profile_id, metrics);

            console.log(`Saved ${savedCount} SD metrics for profile ${report.profile_id}`);

            // Update amazon_accounts.last_sync_at
            await supabase
              .from('amazon_accounts')
              .update({ last_sync_at: new Date().toISOString() })
              .eq('profile_id', report.profile_id);

            // Mark report as completed
            await supabase
              .from('pending_reports')
              .update({
                status: 'completed',
                completed_at: new Date().toISOString(),
                last_attempt_at: new Date().toISOString(),
              })
              .eq('id', report.id);

            results.push({ reportId: report.report_id, status: 'completed', metrics: savedCount });

            // Trigger alert checks if requested - but only if ALL reports in batch are done
            if (report.trigger_alert_check) {
              let shouldTriggerAlert = true;
              
              // If this report has a batch_id, check if all reports in the batch are completed
              if (report.batch_id) {
                const { data: batchReports, error: batchError } = await supabase
                  .from('pending_reports')
                  .select('id, status, report_type')
                  .eq('batch_id', report.batch_id);
                
                if (!batchError && batchReports) {
                  const stillPending = batchReports.filter(r => r.status === 'pending');
                  if (stillPending.length > 0) {
                    shouldTriggerAlert = false;
                    console.log(`⏳ SD: Waiting for ${stillPending.length} more reports in batch ${report.batch_id}: ${stillPending.map(r => r.report_type).join(', ')}`);
                  } else {
                    console.log(`✅ SD: All ${batchReports.length} reports in batch ${report.batch_id} completed - triggering alert checks`);
                  }
                }
              }
              
              if (shouldTriggerAlert) {
                console.log('SD: Triggering alert checks for all profiles in batch...');
                
                // Collect ALL unique profile_ids from the batch
                const { data: batchProfileData } = await supabase
                  .from('pending_reports')
                  .select('profile_id')
                  .eq('batch_id', report.batch_id);
                
                const allProfileIds = [...new Set((batchProfileData || []).map(r => r.profile_id))];
                console.log(`SD: Found ${allProfileIds.length} unique profiles in batch: ${allProfileIds.join(', ')}`);
                
                // Get user_id from amazon_accounts via account_users (using first profile)
                const { data: accountUser } = await supabase
                  .from('amazon_accounts')
                  .select('id, account_users!inner(user_id)')
                  .eq('profile_id', report.profile_id)
                  .limit(1)
                  .single();
                
                if (accountUser?.account_users?.[0]?.user_id) {
                  const userId = accountUser.account_users[0].user_id;
                  console.log(`SD: Triggering run-alert-checks for user ${userId}, profiles: ${allProfileIds.join(', ')}`);
                  
                  await supabase.functions.invoke('run-alert-checks', {
                    body: { 
                      user_id: userId,
                      profile_ids: allProfileIds,  // ALL profile IDs in batch
                      run_type: 'scheduled'
                    },
                  });
                } else {
                  console.log(`SD: No user found for profile ${report.profile_id}, skipping alert check`);
                }
              }
            }

          } else if (statusResult.status === 'FAILED' || statusResult.status === 'error') {
            console.error(`SD Report ${report.report_id} failed:`, statusResult.error);

            await supabase
              .from('pending_reports')
              .update({
                status: 'failed',
                error_message: statusResult.error || 'Report failed',
                last_attempt_at: new Date().toISOString(),
              })
              .eq('id', report.id);

            results.push({ reportId: report.report_id, status: 'failed', error: statusResult.error });

          } else {
            // Still pending
            const newAttempts = report.attempts + 1;
            if (newAttempts >= MAX_ATTEMPTS) {
              console.log(`SD Report ${report.report_id} exceeded max attempts`);
              await supabase
                .from('pending_reports')
                .update({
                  status: 'failed',
                  error_message: 'Max attempts exceeded',
                  attempts: newAttempts,
                  last_attempt_at: new Date().toISOString(),
                })
                .eq('id', report.id);

              results.push({ reportId: report.report_id, status: 'max_attempts' });
            } else {
              await supabase
                .from('pending_reports')
                .update({
                  attempts: newAttempts,
                  last_attempt_at: new Date().toISOString(),
                })
                .eq('id', report.id);

              results.push({ reportId: report.report_id, status: 'pending' });
            }
          }
        } catch (error) {
          const errorMessage = error instanceof Error ? error.message : 'Unknown error';
          console.error(`Error processing SD report ${report.report_id}:`, errorMessage);
          results.push({ reportId: report.report_id, status: 'error', error: errorMessage });
        }
      }
    }

    const completed = results.filter(r => r.status === 'completed').length;
    const pending = results.filter(r => r.status === 'pending').length;
    const failed = results.filter(r => ['failed', 'error', 'max_attempts', 'token_error'].includes(r.status)).length;

    console.log(`SD report processing complete: ${completed} completed, ${pending} pending, ${failed} failed`);

    return new Response(
      JSON.stringify({
        success: true,
        message: `Processed ${results.length} SD reports`,
        completed,
        pending,
        failed,
        results
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error: unknown) {
    const errorMessage = error instanceof Error ? error.message : 'Unknown error';
    console.error('Error in process-pending-reports-sd:', errorMessage);
    return new Response(
      JSON.stringify({ error: errorMessage }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});

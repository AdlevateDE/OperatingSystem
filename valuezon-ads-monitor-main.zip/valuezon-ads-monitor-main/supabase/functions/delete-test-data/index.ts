import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseKey);

    const { deleteAll } = await req.json().catch(() => ({ deleteAll: false }));

    console.log('=== delete-test-data started ===');
    console.log('Delete all mode:', deleteAll);

    if (deleteAll) {
      // Delete ALL records from campaign_metrics_sp
      const { error: metricsError, count: metricsCount } = await supabase
        .from('campaign_metrics_sp')
        .delete({ count: 'exact' })
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all (workaround)

      if (metricsError) throw metricsError;
      console.log(`Deleted ${metricsCount} records from campaign_metrics_sp`);

      // Delete ALL records from pending_reports
      const { error: reportsError, count: reportsCount } = await supabase
        .from('pending_reports')
        .delete({ count: 'exact' })
        .neq('id', '00000000-0000-0000-0000-000000000000'); // Delete all (workaround)

      if (reportsError) throw reportsError;
      console.log(`Deleted ${reportsCount} records from pending_reports`);

      return new Response(
        JSON.stringify({
          success: true,
          deleted_metrics: metricsCount,
          deleted_reports: reportsCount,
        }),
        { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
      );
    }

    // Original behavior: delete records created after today 22:00
    console.log('Deleting test data inserted after today 22:00');

    const today = new Date();
    const cutoffDate = new Date(today.getFullYear(), today.getMonth(), today.getDate(), 22, 0, 0);
    
    console.log('Cutoff datetime:', cutoffDate.toISOString());

    const { error: deleteError, count } = await supabase
      .from('campaign_metrics_sp')
      .delete({ count: 'exact' })
      .gte('created_at', cutoffDate.toISOString());

    if (deleteError) throw deleteError;

    console.log(`Successfully deleted ${count} records`);

    return new Response(
      JSON.stringify({
        success: true,
        deleted_count: count,
        cutoff_datetime: cutoffDate.toISOString(),
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  } catch (error: any) {
    console.error('Error in delete-test-data:', error);
    return new Response(
      JSON.stringify({ error: error.message }),
      {
        headers: { ...corsHeaders, 'Content-Type': 'application/json' },
        status: 500,
      }
    );
  }
});

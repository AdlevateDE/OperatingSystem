import { serve } from "https://deno.land/std@0.168.0/http/server.ts";
import { createClient } from "https://esm.sh/@supabase/supabase-js@2";

const corsHeaders = {
  'Access-Control-Allow-Origin': '*',
  'Access-Control-Allow-Headers': 'authorization, x-client-info, apikey, content-type',
};

const AMAZON_API_BASE = 'https://advertising-api-eu.amazon.com';
const AMAZON_TOKEN_URL = 'https://api.amazon.com/auth/o2/token';

// Delay helper for rate limiting
const delay = (ms: number) => new Promise(resolve => setTimeout(resolve, ms));

// Refresh OAuth token - now accepts dynamic refresh token key
async function refreshAccessToken(refreshTokenKey?: string | null): Promise<string> {
  const clientId = Deno.env.get('AMAZON_CLIENT_ID');
  const clientSecret = Deno.env.get('AMAZON_CLIENT_SECRET');
  
  // Use custom refresh token key if provided, otherwise default
  const tokenEnvKey = refreshTokenKey || 'AMAZON_REFRESH_TOKEN';
  const refreshToken = Deno.env.get(tokenEnvKey);

  if (!clientId || !clientSecret || !refreshToken) {
    throw new Error(`Missing Amazon API credentials (token key: ${tokenEnvKey})`);
  }

  console.log(`Refreshing Amazon access token using ${tokenEnvKey}...`);

  const response = await fetch(AMAZON_TOKEN_URL, {
    method: 'POST',
    headers: {
      'Content-Type': 'application/x-www-form-urlencoded',
    },
    body: new URLSearchParams({
      grant_type: 'refresh_token',
      refresh_token: refreshToken,
      client_id: clientId,
      client_secret: clientSecret,
    }),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Token refresh failed:', errorText);
    throw new Error(`Token refresh failed: ${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('Access token refreshed successfully');
  return data.access_token;
}

// Create a report request - returns report ID
async function createReport(accessToken: string, profileId: string, startDate: string, endDate: string): Promise<string> {
  console.log(`Creating report for profile ${profileId}, dates: ${startDate} to ${endDate}`);

  const reportConfig = {
    name: `${new Date().toISOString()}_SP Campaigns Daily Report`,
    startDate: startDate,
    endDate: endDate,
    configuration: {
      adProduct: 'SPONSORED_PRODUCTS',
      groupBy: ['campaign'],
      columns: [
        'date',
        'campaignName',
        'campaignId',
        'campaignStatus',
        'campaignBudgetAmount',
        'campaignBudgetType',
        'campaignBudgetCurrencyCode',
        'topOfSearchImpressionShare',
        'impressions',
        'clicks',
        'clickThroughRate',
        'cost',
        'costPerClick',
        'purchases14d',
        'sales14d',
        'unitsSoldClicks14d',
        'acosClicks14d',
        'roasClicks14d',
      ],
      filters: [
        { field: 'campaignStatus', values: ['ENABLED'] }
      ],
      reportTypeId: 'spCampaigns',
      timeUnit: 'DAILY',
      format: 'GZIP_JSON',
    },
  };

  const response = await fetch(`${AMAZON_API_BASE}/reporting/reports`, {
    method: 'POST',
    headers: {
      'Authorization': `Bearer ${accessToken}`,
      'Amazon-Advertising-API-ClientId': Deno.env.get('AMAZON_CLIENT_ID')!,
      'Amazon-Advertising-API-Scope': profileId,
      'Content-Type': 'application/vnd.createasyncreportrequest.v3+json',
      'Accept': 'application/vnd.createasyncreportrequest.v3+json',
    },
    body: JSON.stringify(reportConfig),
  });

  if (!response.ok) {
    const errorText = await response.text();
    console.error('Create report failed:', errorText);
    
    // Handle duplicate report - extract existing report ID
    if (response.status === 425) {
      const match = errorText.match(/duplicate of\s*:\s*([a-f0-9-]+)/i);
      if (match) {
        console.log('Report already exists, using existing ID:', match[1]);
        return match[1];
      }
    }
    
    throw new Error(`${response.status} - ${errorText}`);
  }

  const data = await response.json();
  console.log('Report created with ID:', data.reportId);
  return data.reportId;
}

serve(async (req) => {
  if (req.method === 'OPTIONS') {
    return new Response(null, { headers: corsHeaders });
  }

  try {
    const { profileIds, startDate, endDate, triggerAlertCheck, batch_id } = await req.json();

    console.log('=== fetch-amazon-data-sp: Creating report jobs ===');
    console.log('Profile IDs:', profileIds);
    console.log('Date range:', startDate, 'to', endDate);
    console.log('Trigger alert check:', triggerAlertCheck);
    console.log('Batch ID:', batch_id);

    if (!profileIds || !Array.isArray(profileIds) || profileIds.length === 0) {
      throw new Error('profileIds array is required');
    }
    if (!startDate || !endDate) {
      throw new Error('startDate and endDate are required');
    }

    const supabaseUrl = Deno.env.get('SUPABASE_URL')!;
    const supabaseServiceKey = Deno.env.get('SUPABASE_SERVICE_ROLE_KEY')!;
    const supabase = createClient(supabaseUrl, supabaseServiceKey);

    // Get refresh_token_key mapping for all profiles
    const { data: accounts, error: accountsError } = await supabase
      .from('amazon_accounts')
      .select('profile_id, refresh_token_key')
      .in('profile_id', profileIds);

    if (accountsError) {
      console.error('Error fetching accounts:', accountsError);
      throw new Error(`Failed to fetch accounts: ${accountsError.message}`);
    }

    // Create a map of profile_id -> refresh_token_key
    const tokenKeyMap = new Map<string, string | null>();
    for (const account of accounts || []) {
      tokenKeyMap.set(account.profile_id, account.refresh_token_key);
    }

    console.log('Token key mapping:', Object.fromEntries(tokenKeyMap));

    const results: { profileId: string; status: string; reportId?: string; error?: string }[] = [];

    // Group profiles by refresh_token_key to minimize token refreshes
    const profilesByToken = new Map<string, string[]>();
    for (const profileId of profileIds) {
      const tokenKey = tokenKeyMap.get(profileId) || 'AMAZON_REFRESH_TOKEN';
      if (!profilesByToken.has(tokenKey)) {
        profilesByToken.set(tokenKey, []);
      }
      profilesByToken.get(tokenKey)!.push(profileId);
    }

    // Process each token group
    for (const [tokenKey, groupProfileIds] of profilesByToken) {
      let accessToken: string;
      try {
        accessToken = await refreshAccessToken(tokenKey === 'AMAZON_REFRESH_TOKEN' ? null : tokenKey);
      } catch (tokenError) {
        const errorMsg = tokenError instanceof Error ? tokenError.message : String(tokenError);
        console.error(`Token refresh failed for ${tokenKey}:`, errorMsg);
        
        // Insert creation_failed for all profiles in this token group
        for (const profileId of groupProfileIds) {
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: startDate,
            end_date: endDate,
            status: 'creation_failed',
            error_message: `Token-Aktualisierung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sp',
            batch_id: batch_id || null,
          });
          results.push({ profileId, status: 'creation_failed', error: errorMsg });
        }
        continue;
      }

      let isFirstProfile = true;
      for (const profileId of groupProfileIds) {
        // Rate limiting: wait 3 seconds between API calls (skip first)
        if (!isFirstProfile) {
          console.log(`[RATE LIMIT] Waiting 3s before next SP request...`);
          await delay(3000);
        }
        isFirstProfile = false;

        try {
          console.log(`\n--- Creating SP report for profile: ${profileId} (token: ${tokenKey}) ---`);

          // 1. Create report at Amazon
          const reportId = await createReport(accessToken, profileId, startDate, endDate);

          // 2. Store in pending_reports table
          const { error: insertError } = await supabase
            .from('pending_reports')
            .insert({
              profile_id: profileId,
              report_id: reportId,
              start_date: startDate,
              end_date: endDate,
              status: 'pending',
              trigger_alert_check: triggerAlertCheck ?? false,
              batch_id: batch_id || null,
              report_type: 'sp',
            });

          if (insertError) {
            // Check if it's a duplicate
            if (insertError.code === '23505') {
              console.log('Report job already exists, skipping');
            } else {
              throw insertError;
            }
          }

          results.push({
            profileId,
            status: 'queued',
            reportId,
          });

          console.log(`SP Report job queued: ${reportId}`);
        } catch (error) {
          const errorMsg = error instanceof Error ? error.message : String(error);
          console.error(`Error creating SP report for profile ${profileId}:`, errorMsg);
          
          // Insert with creation_failed status so it's visible in the UI
          await supabase.from('pending_reports').insert({
            profile_id: profileId,
            report_id: `failed-${Date.now()}-${profileId}`,
            start_date: startDate,
            end_date: endDate,
            status: 'creation_failed',
            error_message: `Report-Erstellung fehlgeschlagen: ${errorMsg}`,
            report_type: 'sp',
            batch_id: batch_id || null,
          });

          results.push({
            profileId,
            status: 'creation_failed',
            error: errorMsg,
          });
        }
      }
    }

    console.log('=== fetch-amazon-data-sp completed ===');
    console.log('Results:', JSON.stringify(results, null, 2));

    return new Response(
      JSON.stringify({
        success: true,
        message: 'Report jobs created. Use process-pending-reports to poll and download.',
        results,
      }),
      { headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );

  } catch (error) {
    console.error('Fatal error in fetch-amazon-data-sp:', error);
    return new Response(
      JSON.stringify({ success: false, error: error instanceof Error ? error.message : String(error) }),
      { status: 500, headers: { ...corsHeaders, 'Content-Type': 'application/json' } }
    );
  }
});
